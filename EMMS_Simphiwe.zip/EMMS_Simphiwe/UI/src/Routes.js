import { Switch } from 'react-router-dom';
import DefaultLayout from './pages/layouts/Default';
import LoginLayout from './pages/layouts/Login';

import Login from './pages/Login';
import Dashboard from './pages/dashboard';

import AssetCats from './pages/cmaster/AssetCats';
import StationPoint from './pages/cmaster/StationPoint';
import Manufacturer from './pages/cmaster/Manufacturer';
import ServiceProvider from './pages/cmaster/ServiceProvider';
import Vendor from './pages/cmaster/Vendor';
import Uom from './pages/cmaster/Uom';
import Model from './pages/cmaster/Model';
import Items from './pages/cmaster/Items';

import Facilities from './pages/Facilities';

import User from './pages/user/User';
import Role from './pages/user/Role';

import Assets from './pages/assets/Assets';
import TransferOut from './pages/assets/TransferOut';
import TransferIn from './pages/assets/TransferIn';
import StockRequest from './pages/assets/StockRequest';
import Ticket from './pages/ticket/Ticket';

import StockTransactions from './pages/reports/StockTransactions';

import Profile from './pages/user/Profile';

export default function Routes() {
    return (
        <Switch>
            <LoginLayout path="/" exact component={Login} />

            <DefaultLayout path="/dashboard" component={Dashboard} />
            <DefaultLayout path="/profile" component={Profile} />
            <DefaultLayout path="/users" component={User} />
            <DefaultLayout path="/roles" component={Role} />

            <DefaultLayout path="/facilities" component={Facilities} />
            <DefaultLayout path="/asset-cats" component={AssetCats} />
            <DefaultLayout path="/station-points" component={StationPoint} />
            <DefaultLayout path="/manufacturers" component={Manufacturer} />
            <DefaultLayout path="/service-providers" component={ServiceProvider} />
            <DefaultLayout path="/vendors" component={Vendor} />
            <DefaultLayout path="/items" component={Items} />
            <DefaultLayout path="/uoms" component={Uom} />
            <DefaultLayout path="/models" component={Model} />

            <DefaultLayout path="/assets-list" component={Assets} />
            <DefaultLayout path="/transfer-out" component={TransferOut} />
            <DefaultLayout path="/transfer-in" component={TransferIn} />
            <DefaultLayout path="/stock-request" component={StockRequest} />
            <DefaultLayout path="/job-cards" component={Ticket} />

            <DefaultLayout path="/stock-transactions-report" component={StockTransactions} />

            <LoginLayout component={Login} /> {/** Not found page */}
        </Switch>
    );
}