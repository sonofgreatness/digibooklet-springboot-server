import axios from "axios";
import util from "./util";

let axiosBaseUrl = '/';
if (window.location.href.indexOf("localhost") >= 0) {
    axiosBaseUrl = window.location.protocol + "//" + window.location.hostname + ":8780/assets/api/";
} else if (window.location.href.indexOf("3.233.104.86") >= 0) {//testing
    axiosBaseUrl = window.location.origin + "/assets/api/";
} else if (window.location.href.indexOf("102.222.132.153") >= 0) {//production //port 8085 for public access
    axiosBaseUrl = window.location.origin + "/assets/api/";
} 

else {
    //102.222.132.97
    axiosBaseUrl = window.location.origin + '/assets/api/';
}
const axiosInstance = axios.create({
    baseURL: axiosBaseUrl
});

axiosInstance.interceptors.request.use(
    (config) => {
        config.headers.authorization = util.getToken();
        config.headers.timezoneoffset = util.getTimezoneOffset();
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

axiosInstance.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        if (typeof error.response === "undefined") {
            error.response = {};
        } else {
            if (typeof error.response.data === "object") {
                if (typeof error.response.data?.message !== "undefined") {
                    error.message = error.response.data?.message;
                }
            }
        }
        return Promise.reject(error);
    }
);

export default axiosInstance;