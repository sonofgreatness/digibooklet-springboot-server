/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import NotificationService from '../../services/NotificationService';
import util from "../../utils/util";
import { RawHTML } from "../../utils/Controls";
import {
    Button,
    Modal,
    message,
    Alert
} from 'antd';

export default function Index() {
    const [notifications, setNotifications] = useState([]);
    const [dtl, setDtl] = useState(null);

    const list = () => {
        util.showLoader();
        NotificationService.all().then(({ data }) => {
            setNotifications(data.result);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const read = (rob, i) => {
        setDtl({ ...rob });

        if (!rob.isread) {
            NotificationService.read(rob.id).then(({ data }) => {
                notifications[i].isread = 1;
                setNotifications([...notifications]);
            }).catch(e => {
                message.error(e.message);
            }).finally(() => {
            });
        }
    }

    useEffect(() => {
        list();
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto"><h2>Notifications <span className="badge badge-primary">{notifications.filter(v => !v.isread).length}</span></h2></div>
                <div className="my-auto ml-auto">
                </div>
            </div>

            <div className="page-pad">
                <div className="m-auto w-75">
                    {notifications.map((v, i) => (
                        <div key={i} className={"mb10 " + (v.isread ? 'border' : '')}>
                            <Alert
                                message={<div className={"cpointer " + (v.isread ? '' : 'bold600')} onClick={() => read(v, i)}>{v.subject}</div>}
                                description={<div>@ {v.created}</div>}
                                type={v.isread ? "" : "info"}
                                action={
                                    <Button size="small" type="primary" onClick={() => read(v, i)}>
                                        View
                                    </Button>
                                }
                            />
                        </div>
                    ))}
                </div>
            </div>

            <Modal
                title="Notification Detail"
                open={dtl !== null}
                okText="Go There"
                cancelText="Close"
                onOk={() => {
                    let url = '/assets/web/build';
                    if (dtl.type === "StockRequest") {
                        url = `${url}/stock-request?ids=${dtl.type_ids}`;
                    }
                    if (dtl.type === "StockTransfer") {
                        url = `${url}/transfer-out?ids=${dtl.type_ids}`;
                    }
                    if (dtl.type === "StockReceive") {
                        url = `${url}/transfer-in?ids=${dtl.type_ids}`;
                    }
                    if (dtl.type === "Ticket") {
                        url = `${url}/job-cards?ids=${dtl.type_ids}`;
                    }
                    if (url) {
                        window.open(url, "_blank");
                    }
                    setDtl(null);
                }}
                onCancel={() => setDtl(null)}
                destroyOnClose
                maskClosable={false}
                width={800}
            >
                {dtl !== null &&
                    <div>
                        <div className="bold600 mb5">{dtl.subject}</div>
                        <div>
                            <RawHTML html={dtl.msg} />
                        </div>
                        <div className="pt20">Notification Datetime: {dtl.created}</div>
                    </div>}
            </Modal>
        </div>
    )
}