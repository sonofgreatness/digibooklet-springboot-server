/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';
import util from "../../../utils/util";
//import {If} from '../Controls';
import { Dropdown, Avatar } from 'antd';
import {
    DownOutlined, UserOutlined, LogoutOutlined
} from '@ant-design/icons';
let $ = window.$;

export default function Header() {
    const history = useHistory();
    const toggleSidebarCollapse = (e) => {
        e.preventDefault();
        if ($("body").hasClass("page-sidebar-closed")) {
            $("body").removeClass("page-sidebar-closed");
        } else {
            $("body").addClass("page-sidebar-closed");
        }
    }

    const toggleResponsiveSidebarCollapse = (e) => {
        e.preventDefault();
        if ($("body").hasClass("page-sidebar-mobile-offcanvas-open")) {
            $("body").removeClass("page-sidebar-mobile-offcanvas-open");
            $(".page-sidebar-cover").hide();
        } else {
            $("body").addClass("page-sidebar-mobile-offcanvas-open");
            $(".page-sidebar-cover").show();
        }
    }

    useEffect(() => {
        // eslint-disable-next-line
    }, []);

    const userDDItems = [
        { label: <Link to="/profile"><UserOutlined /> My Profile</Link>, key: '1' },
        { label: <div className="cpointer" onClick={(e) => util.logout(e, history)}><LogoutOutlined /> Logout</div>, key: '3', visible: 'Y' },
    ];

    return (
        <div className="page-header navbar navbar-fixed-top d-print-none">
            <div className="d-flex h-100">
                <div className="page-logo my-auto">
                    <Link to="/dashboard">
                        <img src="assets/img/elogo.png" alt="logo" width="80" className="logo-default" style={{ marginTop: '-8px' }} />
                    </Link>

                    {/* <span className="m-0 font-green-sharp inblock pt10 fs18 bold600">ASSETS MANAGEMENT</span> */}
                    <div className="menu-toggler sidebar-toggler" onClick={toggleSidebarCollapse}> <span></span> </div>
                </div>

                <div className="my-auto font-green uc">
                    Eswatini Asset Management System
                </div>

                <div className="my-auto ml-auto h-100 pt-3">
                    <Dropdown
                        placement="bottomRight"
                        trigger={["click"]}
                        menu={{ items: userDDItems }}
                    >
                        <div className="cpointer d-flex align-items-center">
                            <div className="">
                                {/* <Avatar icon={<UserOutlined />} style={{ color: "#ffffff" }} /> */}
                                <i className="fa fa-user-circle fs20 text-white"></i>
                            </div>
                            <div className="ml-auto d-flex align-items-center pl10">
                                <div className="ellipsis pr10" style={{ maxWidth: 100, color: '#fff' }}>
                                    {/* <Tooltip title={util.getLoggedName()}> */}
                                    {util.getLoggedName()}
                                    {/* </Tooltip> */}
                                </div>
                                <div>
                                    <DownOutlined className="fs13" style={{ color: '#fff' }} />
                                </div>
                            </div>
                        </div>
                    </Dropdown>
                </div>
                <div className="my-auto pl20">
                    <a href="/" className="my-auto menu-toggler responsive-toggler" data-toggle1="collapse" data-target1=".navbar-collapse" onClick={toggleResponsiveSidebarCollapse}>
                        <span></span>
                    </a>
                </div>
            </div>
        </div>
    )
}