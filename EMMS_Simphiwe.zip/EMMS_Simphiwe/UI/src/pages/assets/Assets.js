/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import AssetService from "../../services/AssetService";
import FacilityService from "../../services/FacilityService";
//import VendorService from "../../services/VendorService";
import { If } from "../../utils/Controls";
import { AntdPaging, AntdSelect, AntdDatepicker } from "../../utils/Antd";
import util from "../../utils/util";
import {
    Input,
    Button,
    message,
    Modal,
    Divider,
    Tabs
} from 'antd';

/* import {
    ExclamationCircleOutlined,
} from '@ant-design/icons';
const { confirm } = Modal; */


export default function Assets() {
    const [clients, setClients] = useState([]);
    //const [vendors, setVendors]=useState([]);
    const [items, setItems] = useState([]);
    const [stationPoints, setStationPoints] = useState([]);
    const [functionalStatus, setFunctionalStatus] = useState([]);
    const [tab, setTab] = useState('Med/NonMed');

    const onTabChange = (key) => {
        setTab(key);
    }

    useEffect(() => {
        FacilityService.all({ status: 1, include_me: 'Y' }).then(res => {
            let allClients = res.data.result.data.map(v => { return { id: v.id, name: v.business_name, is_national: v.is_national, is_me: v.is_me } });
            setClients(allClients);
        });

        /* VendorService.all({status:1}).then(res => {
            setVendors([...res.data.result.data]);
        }); */

        AssetService.allItems({ status: 1 }).then(res => {
            let allItems = [];
            allItems = res.data.result.data.map((v) => {
                if (v.cat_type === 'Med/NonMed') {
                    v.item_full_name = v.item_full_name + ' [' + v.cat + ']';
                } else {
                    v.item_full_name = v.item_full_name + ' [' + v.subcat + ']';
                }
                return v;
            });
            setItems(allItems);
        });

        FacilityService.allStationPoints({ status: 1 }).then(res => {
            setStationPoints([...res.data.result.data]);
        });
        AssetService.allFunctionalStatus().then(res => {
            setFunctionalStatus([...res.data.data]);
        })
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Assets</h2>
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                <Tabs
                    activeKey={tab}
                    destroyInactiveTabPane
                    onChange={onTabChange}
                    items={[{ k: 'Med/NonMed', v: 'Med/NonMed Assets' }, { k: 'Infrastructure', v: 'Infrastructure' }].map(rw => ({
                        key: rw.k,
                        label: rw.v,
                        children: (
                            <List
                                //vendors={vendors}
                                items={items}
                                stationPoints={stationPoints}
                                functionalStatus={functionalStatus}
                                cat_type={rw.k}
                                clients={clients}
                            />
                        )
                    }))}
                />

                {/* {[{ k: 'Med/NonMed', v: 'Med/NonMed Assets' }, { k: 'Infrastructure', v: 'Infrastructure' }].map(rw => (
                    <div key={rw.k}>
                        {rw.k === tab &&
                            <List
                                //vendors={vendors}
                                items={items}
                                stationPoints={stationPoints}
                                functionalStatus={functionalStatus}
                                cat_type={rw.k}
                                clients={clients}
                            />
                        }
                    </div>
                ))} */}
            </div>
        </div>
    )
}

function List(props) {
    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25 });
    const formRef = useRef();
    const transferFormRef = useRef();
    const [clients, setClients] = useState([]);
    //const [vendors, setVendors] = useState([]);
    const [items, setItems] = useState([]);
    const [stationPoints, setStationPoints] = useState([]);
    const [functionalStatus, setFunctionalStatus] = useState([]);
    const [checkbox, setCheckbox] = useState([]);
    const isNational = util.isNational();
    const modules = util.getModules();

    const list = (p, ps) => {
        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        sdataRef.current.cat_type = props.cat_type;
        util.showLoader();
        AssetService.lists(sdataRef.current).then(({ data }) => {
            setResult({ ...data.result });
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    /* const deleteRecord=(id)=>{
        message.destroy();
        confirm({
            title: 'Do you Want to delete this asset?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                AssetService.delete(id).then(({ data }) => {
                    message.success(data.message || 'Deleted');
                    list();
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    } */

    const handleCheckbox = (e, id, allSelect = false) => {
        let dt = checkbox;
        if (!allSelect) {
            if (e.target.checked) {
                dt = [...new Set(dt)];  // removes all duplicates
                dt.push(id)
            } else {
                dt.splice(dt.indexOf(id), 1);
                dt = [...new Set(dt)];  // removes all duplicates
            }
        } else {
            dt = [];
            if (e.target.checked) {
                result.data.map(v => dt.push(v.id));
            }
        }
        setCheckbox([...dt])
    }

    useEffect(() => {
        setClients(props.clients);
    }, [props.clients]);

    /* useEffect(()=>{
        setVendors(props.vendors);
    }, [props.vendors]); */

    useEffect(() => {
        setItems(props.items.filter(v => v.cat_type === props.cat_type));
    }, [props.items, props.cat_type]);

    useEffect(() => {
        setStationPoints(props.stationPoints);
    }, [props.stationPoints]);

    useEffect(() => {
        setFunctionalStatus(props.functionalStatus);
    }, [props.functionalStatus]);

    useEffect(() => {
        list();

        return () => { message.destroy() }
    }, []);

    return (
        <div className="">
            <div className="">
                <div className="d-flex mb8">
                    <div className="text-secondary my-auto">
                        {result.data.length > 0 &&
                            <div>
                                Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                            </div>
                        }
                    </div>
                    <div className="ml-auto my-auto">
                        {modules['transfer_asset'] === 1 &&
                            <Button size="small" type="danger" className="mr-2" onClick={() => transferFormRef.current.openForm()} disabled={!checkbox.length}>
                                <i className="fa fa-share mr5"></i> Transfer
                            </Button>
                        }
                        {modules['add_asset'] === 1 &&
                            <Button size="small" type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i>
                                Add
                            </Button>
                        }
                    </div>
                </div>

                <div className="tbl-search-head">
                    <SearchForm
                        dataRef={sdataRef}
                        onSearch={list}
                        clients={clients}
                        functionalStatus={functionalStatus}
                        stationPoints={stationPoints}
                        cat_type={props.cat_type}
                        isNational={isNational}
                    />
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm font-xs table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                <tr>
                                    <th className="w20">
                                        <input type="checkbox" checked={(() => {
                                            let flag = true;
                                            result.data.forEach(v => {
                                                if (!checkbox.includes(v.id)) {
                                                    flag = false
                                                }
                                            })
                                            return flag;
                                        })()}

                                            onChange={(e) => handleCheckbox(e, 0, true)}
                                        />
                                    </th>
                                    {isNational === 1 && <th className="w100">Facility</th>}
                                    <th className="w100">Asset Code</th>
                                    <th>Item</th>
                                    <th className="w100">Model</th>
                                    {props.cat_type === 'Med/NonMed' &&
                                        <th className="w100">Serial No</th>
                                    }

                                    {props.cat_type === 'Med/NonMed' &&
                                        <>
                                            <th className="w100 nowrap">Procurement Date</th>
                                            <th className="w100">Install Date</th>
                                        </>
                                    }

                                    <th className="w100 text-right">Cost (SZL)</th>
                                    {props.cat_type !== 'Med/NonMed' &&
                                        <th className="w100 text-right">Stock QTY</th>
                                    }
                                    {props.cat_type === 'Med/NonMed' &&
                                        <>
                                            <th className="w100">Station Point</th>
                                            <th className="w130">Functional Status</th>
                                        </>
                                    }

                                    {/* <th className="w60">Status</th> */}

                                    <th className="w20"></th>
                                </tr>
                            </thead>
                            <tbody className="table-text-top font-sm">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>
                                            <input type="checkbox" checked={checkbox.includes(v.id) ? true : false} onChange={(e) => handleCheckbox(e, v.id)} />
                                        </td>
                                        {isNational === 1 && <td>{v.client}</td>}
                                        <td>
                                            {v.code}
                                            {v.isdonated === 1 &&
                                                <div style={{ marginTop: '4px', color: 'purple', fontWeight: 700 }}>Donated</div>
                                            }
                                        </td>
                                        <td>
                                            <div className="uc bold600">{v.item}</div>
                                            <div className="pt3 note-text">
                                                <div className="d-flex"><div className="w90">Category</div> : <div className="bold600 pl5">{v.cat}</div></div>
                                                {v.subcat &&
                                                    <div className="d-flex"><div className="w90">Sub-Category</div> : <div className="bold600 pl5">{v.subcat}</div></div>
                                                }
                                                <div className="d-flex mt4 pt2" style={{ borderTop: '1px solid #ccc' }}><div className="w90">Manufacturer</div> : <div className="bold600 pl5">{v.manufacturer || 'N/A'}</div></div>
                                                <div className="d-flex"><div className="w90">Service Provider</div> : <div className="bold600 pl5">{v.service_provider || 'N/A'}</div></div>
                                                <div className="d-flex"><div className="w90">Vendor</div> : <div className="bold600 pl5">{v.vendor || 'N/A'}</div></div>
                                            </div>
                                        </td>
                                        <td>{v.model}</td>
                                        {props.cat_type === 'Med/NonMed' &&
                                            <td>{v.serial_no}</td>
                                        }

                                        {props.cat_type === 'Med/NonMed' &&
                                            <>
                                                <td>{v.procurement_date}</td>
                                                <td>{v.installation_date}</td>
                                            </>
                                        }
                                        <td className="text-right">{v.cost}</td>
                                        {props.cat_type !== 'Med/NonMed' &&
                                            <td className="text-right">{v.stock} <div>({v.uom})</div></td>
                                        }

                                        {props.cat_type === 'Med/NonMed' &&
                                            <>
                                                <td>
                                                    {v.station_points.map((s, j) => (
                                                        <div className="note-text" key={j}>
                                                            {s.station_point}
                                                        </div>
                                                    ))}
                                                </td>
                                                <td>{v.functional_status_name}</td>
                                            </>
                                        }
                                        {/* <td className="nowrap">
                                            {v.status ? (<AntdTag type="success">Active</AntdTag>) : (<AntdTag type="danger">Inactive</AntdTag>)}
                                        </td> */}
                                        <td className="text-center">
                                            <Button.Group size="small">
                                                <Button type="default" onClick={() => formRef.current.openForm(v)}><i className="fa fa-edit"></i></Button>
                                                {/* <Button type="default" onClick={() => deleteRecord(v.id)}><i className="fa fa-times-circle font-red"></i></Button> */}
                                            </Button.Group>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>

            <AddForm
                ref={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                clients={clients}
                //vendors={vendors}
                items={items}
                stationPoints={stationPoints}
                functionalStatus={functionalStatus}
                cat_type={props.cat_type}
                isNational={isNational}
            />

            <TransferForm ref={transferFormRef} {...{
                checkbox,
                clients: props.clients,
                resultData: result.data.map((v) => { return { id: v.id, item: v.item, cat: v.cat, subcat: v.subcat, serial_no: v.serial_no, stock: v.stock, client: v.client } }),
                callback: list,
                pageno: sdataRef.current.p,
                cat_type: props.cat_type,
                modules,
            }} />
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch, clients, functionalStatus, isNational, cat_type } = props;
    let [data, setData] = useState({ ...dataRef.current, station_point_ids: [], isdonated: null });
    let [stationPoints, setStationPoints] = useState([]);
    const [items, setItems] = useState([]);

    const handleChange = (v, k) => {
        data[k] = v;
        if (k === 'client_id') {
            data.station_point_ids = [];
        }
        setData({ ...data });
    }
    useEffect(() => {
        dataRef.current = { ...data };
    }, [data]);

    useEffect(() => {
        if (isNational === 1) {
            setData({ ...data, client_id: null });
        } else {
            let ob = clients.find(v => v.is_me);
            setData({ ...data, client_id: ob?.id });
        }
    }, [clients]);

    useEffect(() => {
        setStationPoints([...props.stationPoints]);
    }, [props.stationPoints]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    useEffect(() => {
        AssetService.allItems({ status: 1, cat_type, client_id: data.client_id, availableAssetsOnly: 'Y' }).then(res => {
            let allItems = [];
            allItems = res.data.result.data.map((v) => {
                if (v.cat_type === 'Med/NonMed') {
                    v.item_full_name = v.item_full_name + ' [' + v.cat + ']';
                } else {
                    v.item_full_name = v.item_full_name + ' [' + v.subcat + ']';
                }
                return v;
            });
            setItems(allItems);
        });
    }, [cat_type, data.client_id]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                {isNational === 1 &&
                    <div className="w150 mr5">
                        <div className="text-secondary fs11 mb2">Facility</div>
                        <AntdSelect
                            placeholder="All Facilities"
                            allowClear
                            showSearch
                            options={clients}
                            value={data.client_id}
                            onChange={v => {
                                data.item_id = null;
                                handleChange(v, 'client_id');
                            }}
                        />
                    </div>
                }

                {props.cat_type === 'Med/NonMed' &&
                    <div className="w170 mr5">
                        <div className="text-secondary fs11 mb2">Functional Status</div>
                        <AntdSelect
                            placeholder="All Status"
                            allowClear
                            showSearch
                            options={functionalStatus}
                            value={data.functional_status}
                            onChange={v => handleChange(v, 'functional_status')}
                        />
                    </div>
                }

                <div className="w350 mr5">
                    <div className="text-secondary fs11 mb2">Item</div>
                    <AntdSelect
                        placeholder="Item (All)"
                        allowClear
                        showSearch
                        options={items.map(v => { return { id: v.id, name: v.item_full_name } })}
                        value={data.item_id}
                        onChange={v => handleChange(v, 'item_id')}
                    />
                </div>

                {cat_type === 'Med/NonMed' &&
                    <div className="w200 mr5">
                        <div className="text-secondary fs11 mb2">Station Point</div>
                        <AntdSelect
                            showSearch
                            allowClear
                            placeholder="Station Point"
                            mode="multiple"
                            options={stationPoints.filter(v => v.client_ids.includes(data.client_id))}
                            value={data.station_point_ids}
                            onChange={v => handleChange(v, 'station_point_ids')}
                        />
                    </div>
                }

                {/* <div className="w150 mr5">
                    <AntdSelect placeholder="Station Point" allowClear showSearch options={props.stationPoints} value={data.station_point} onChange={v=>handleChange(v, 'station_point')} />
                </div> */}

                <div className="w210 mr5">
                    <div className="text-secondary fs11 mb2">Asset Code / Item Name</div>
                    <Input placeholder="Asset Code / Item Name" allowClear value={data.k} onChange={e => handleChange(e.target.value, 'k')} />
                </div>

                <div className="w210 mr5">
                    <div className="text-secondary fs11 mb2">Donated?</div>
                    <div style={{ width: 90 }}>
                        <AntdSelect
                            allowClear
                            placeholder="All"
                            options={[{ label: 'No', value: '0' }, { label: 'Yes', value: '1' }]}
                            value={data.isdonated}
                            onChange={v => handleChange(v, 'isdonated')}
                        />
                    </div>
                </div>
                <div className="pt15">
                    <Button className="mt4" type="primary" onClick={() => onSearch()}><i className="fa fa-search fs13"></i></Button>
                </div>
            </div>
        </form>
    )
}

const TransferForm = forwardRef((props, ref) => {
    let { checkbox, clients, resultData, callback, pageno, cat_type, modules } = props;
    const [showForm, setShowForm] = useState(false);
    let [assetIdQtys, setAssetIdQtys] = useState([]);
    let [clientId, setClientId] = useState(null);
    let [reason, setReason] = useState('');
    const isNational = util.isNational();
    const handleChange = (value, id) => {
        let dt = assetIdQtys;
        dt[id] = value;
        setAssetIdQtys({ ...dt });
    }

    const save = (approve) => {
        message.destroy();
        util.showLoader();
        AssetService.transferAsset({
            transfer_to: clientId,
            reason,
            approve,
            asset_ids: (() => {
                let dt = [];
                for (const [key, value] of Object.entries(assetIdQtys)) {
                    dt.push({ id: key, qty: value })
                }
                return dt;
            })()
        }).then(({ data }) => {
            message.success(data.message || 'Saved');
            callback(pageno);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const closeForm = () => {
        setShowForm(false);
    }

    useImperativeHandle(ref, () => ({
        openForm() {
            let dt = {};
            checkbox.forEach(v => {
                dt[v] = cat_type === 'Med/NonMed' ? 1 : ''
            });
            setAssetIdQtys({ ...dt });
            setClientId(null);
            setShowForm(true);
            setReason('');
        }
    }));

    return (
        <Modal
            title={`Transfer Asset`}
            open={showForm}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={1100}
            footer={[
                <Button key="1" onClick={closeForm}>Cancel</Button>,
                <Button key="2" type="primary" onClick={() => save('0')}>Transfer</Button>,
                <If cond={modules['approve_transfer_asset']}>
                    <Button key="3" type="danger" onClick={() => save('1')}>Transfer &amp; Approve</Button>
                </If>
            ]}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                <div className="">
                    <div className="row mingap">
                        <div className="col-md-12 form-group">
                            <label className="req">Transfer To</label>
                            <AntdSelect showSearch options={clients.filter(v => v.is_me === 0)} value={clientId} onChange={v => setClientId(v)} />
                        </div>
                    </div>
                    <table className="table table-bordered table-sm font-sm table-striped table-hover">
                        <thead className="thead-light text-uppercase table-text-vmid">
                            <tr>
                                {isNational === 1 && <th className="w100">Facility</th>}
                                <th className="w100">Category</th>
                                <th className="w100">Sub Category</th>
                                <th className="w80">Serial No</th>
                                <th>Item</th>
                                <th className="w120 nowrap">Transfer Quantity</th>
                            </tr>
                        </thead>

                        <tbody className="table-text-top">
                            {resultData.map(v => (
                                <React.Fragment key={v.id}>
                                    {checkbox.includes(v.id) &&
                                        <tr>
                                            {isNational === 1 && <td>{v.client}</td>}
                                            <td>{v.cat}</td>
                                            <td>{v.subcat}</td>
                                            <td>{v.serial_no}</td>
                                            <td>
                                                {v.item}
                                                <div className="note-text">
                                                    Available Stock: <strong>{v.stock}</strong>
                                                </div>
                                            </td>
                                            <td>
                                                <Input type="text" value={assetIdQtys[v.id]} onChange={(e) => handleChange(e.target.value, v.id)} disabled={cat_type === 'Med/NonMed'} />
                                            </td>
                                        </tr>
                                    }
                                </React.Fragment>
                            ))}
                        </tbody>
                    </table>

                    <div>
                        <label>Reason for Transfer</label>
                        <Input.TextArea rows={4} value={reason} onChange={(e) => setReason(e.target.value)} />
                    </div>
                </div>
            </form>
        </Modal>
    )
});


const AddForm = forwardRef((props, ref) => {
    let { callback, pageno, clients, items, stationPoints, functionalStatus, cat_type } = props;
    const [showForm, setShowForm] = useState(false);
    let [data, setData] = useState({ isdonated: 0 });
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    const save = () => {
        message.destroy();
        util.showLoader();
        AssetService.save(data).then(({ data }) => {
            message.success(data.message || 'Saved');
            callback(data.id ? pageno : 1);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }
    const closeForm = () => {
        setShowForm(false);
    }

    useImperativeHandle(ref, () => ({
        openForm(dtl) {
            let client_id = null;
            let ob = clients.find(v => v.is_me);
            client_id = ob?.id;

            setData(dtl ? { ...dtl } : { station_point_ids: [], functional_status: '1', client_id });
            setShowForm(true);
        }
    }));

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Add'} Asset`}
            open={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={800}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                <div className="">
                    <div className="">
                        <label className="req">Facility</label>
                        <AntdSelect
                            showSearch
                            options={clients}
                            value={data.client_id}
                            disabled={data.id}
                            onChange={v => {
                                data.station_point_ids = [];
                                handleChange(v, 'client_id');
                            }}
                        />
                    </div>

                    <Divider />

                    <div className="row mingap">
                        <div className="col-md-12 form-group">
                            <label className="req">Item</label>
                            <AntdSelect
                                showSearch
                                options={items.map(v => { return { id: v.id, name: v.item_full_name } })}
                                value={data.item_id}
                                disabled={data.id}
                                onChange={v => handleChange(v, 'item_id')}
                            />
                        </div>

                        {cat_type === 'Med/NonMed' &&
                            <>
                                <div className="col-md-12 form-group">
                                    <label className="">Station Points</label>
                                    <AntdSelect
                                        showSearch
                                        mode="multiple"
                                        options={stationPoints.filter(v => v.client_ids.includes(data.client_id))}
                                        value={data.station_point_ids}
                                        onChange={v => handleChange(v, 'station_point_ids')}
                                    />
                                </div>

                                <div className="col-md-4 form-group">
                                    <label className="req">Serial Number</label>
                                    <Input value={data.serial_no || ''} onChange={e => handleChange(e.target.value, 'serial_no')} />
                                </div>
                                <div className="col-md-4 form-group">
                                    <label className="req">Procurement Date</label>
                                    <div>
                                        <AntdDatepicker value={data.procurement_date} onChange={v => handleChange(v, 'procurement_date')} />
                                    </div>
                                </div>
                                <div className="col-md-4 form-group">
                                    <label className="">Installation Date</label>
                                    <div>
                                        <AntdDatepicker value={data.installation_date} onChange={v => handleChange(v, 'installation_date')} />
                                    </div>
                                </div>
                            </>
                        }

                        {cat_type !== 'Med/NonMed' && !data.id &&
                            <div className="col-md-4 form-group">
                                <label className="req">Quantity</label>
                                <div>
                                    <Input type="number" value={data.qty || ''} onChange={e => handleChange(e.target.value, 'qty')} />
                                </div>
                            </div>
                        }

                        <div className="col-md-4 form-group">
                            <label>Cost (SZL)</label>
                            <div>
                                <Input type="number" value={data.cost || ''} onChange={e => handleChange(e.target.value, 'cost')} />
                            </div>
                        </div>

                        {cat_type === 'Med/NonMed' &&
                            <div className="col-md-4 form-group">
                                <label className="req">Functional Status</label>
                                <div>
                                    <AntdSelect showSearch options={functionalStatus} value={data.functional_status} onChange={v => handleChange(v, 'functional_status')} />
                                </div>
                            </div>
                        }

                        <div className="col-md-4 form-group">
                            <label className="req">Is Donated?</label>
                            <div>
                                <AntdSelect
                                    options={[{ label: 'No', value: '0' }, { label: 'Yes', value: '1' }]}
                                    value={`${data.isdonated}`}
                                    onChange={v => handleChange(v, 'isdonated')}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </Modal>
    )
})