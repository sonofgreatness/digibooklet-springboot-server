/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import FacilityService from "../../services/FacilityService";
import StockReqService from "../../services/StockReqService";
import { If } from "../../utils/Controls";
import { AntdPaging, AntdSelect, AntdDatepicker } from "../../utils/Antd";
import util from "../../utils/util";
import StockRequestForm from "./StockRequestForm";
import TicketDetail from '../ticket/TicketDetail';
import moment from "moment";

import {
    Button,
    message,
    Tag,
    Modal,
    Menu,
    Dropdown
} from 'antd';
import {
    ExclamationCircleOutlined,
    MoreOutlined
} from '@ant-design/icons';
const { confirm } = Modal;


export default function StockRequest() {
    const [clients, setClients] = useState([]);
    const [stationPoints, setStationPoints] = useState([]);

    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25 });
    const formRef = useRef();
    const ticketDtlRef = useRef({});
    const isNational = util.isNational();
    const modules = util.getModules();

    const list = (p, ps) => {
        const ids = new URLSearchParams(window.location.search).get('ids');

        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        sdataRef.current.ids = ids || '';
        util.showLoader();
        StockReqService.lists(sdataRef.current).then(({ data }) => {
            setResult({ ...data.result });
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const cancelRequest = (rob) => {
        if (!(modules['issue_stock'] || rob.cancel_allowed) || rob.status !== 'Requested') {
            return;
        }

        message.destroy();
        confirm({
            title: 'Are you sure to cancel this stock request?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                StockReqService.cancel(rob.id).then(({ data }) => {
                    message.success(data.message || 'Cancelled');
                    Object.assign(rob, data.result);
                    setResult({ ...result });
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    const issueRequest = (rob) => {
        if (rob.status !== 'Requested') {
            return;
        }

        message.destroy();
        confirm({
            title: 'Are you sure to issue this stock?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                StockReqService.issue(rob.id).then(({ data }) => {
                    message.success(data.message || 'Issued');
                    Object.assign(rob, data.result);
                    setResult({ ...result });
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }


    useEffect(() => {
        list();

        FacilityService.all({ status: 1, include_me: 'Y' }).then(res => {
            let allClients = res.data.result.data.map(v => { return { id: v.id, name: v.business_name, is_national: v.is_national, is_me: v.is_me } });
            setClients(allClients);
        });

        FacilityService.allStationPoints({ status: 1 }).then(res => {
            setStationPoints([...res.data.result.data]);
        });

        return () => { message.destroy() }
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Stock Requests</h2>
                </div>
                <div className="my-auto ml-auto">
                    {modules['add_stock_request'] === 1 &&
                        <Button type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i>
                            Create Request
                        </Button>
                    }
                </div>
            </div>

            <div className="page-pad">
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="tbl-search-head">
                    <SearchForm
                        dataRef={sdataRef}
                        onSearch={list}
                        clients={clients}
                        stationPoints={stationPoints}
                        isNational={isNational}
                    />
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm font-sm table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                <tr>
                                    <th className="w20">SN</th>
                                    {isNational === 1 && <th className="w100">Facility</th>}
                                    <th className="w80">Ticket No</th>
                                    {isNational === 1 && <th className="w100">Request From</th>}
                                    {isNational === 0 && <th className="w80 nowrap">Request To</th>}
                                    <th className="w100">Station Point</th>
                                    <th>Item</th>
                                    <th className="w80 text-right pr10">Qty</th>
                                    <th className="w80">Req. Date</th>
                                    <th className="w80">Status</th>
                                    <th className="w30 text-center"></th>
                                </tr>
                            </thead>
                            <tbody className="table-text-top font-md">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{i + 1}.</td>
                                        {isNational === 1 && <td>{v.client}</td>}
                                        <td>
                                            <div className="link" onClick={() => ticketDtlRef.current.openDetail(v.ticket_id)}>
                                                {v.ticket_no}
                                            </div>
                                        </td>

                                        {isNational === 1 && <td>{v.client}</td>}
                                        {isNational === 0 && <td>{v.to_client_id !== v.client_id ? 'National' : 'Internal'}</td>}

                                        <td>{v.station_point}</td>
                                        <td>
                                            <div className="uc">{v.item_full_name} [{v.subcat}]</div>
                                            <div className="note-text pt2">
                                                <div>Requested by <span>{v.created_by_name} [{v.created_by_role}]</span> on <span>{util.getDate(v.created, 'DD MMM YYYY @ hh:mm A')}</span></div>

                                                {v.status !== 'Requested' &&
                                                    <div className={v.status === 'Issued' ? 'font-green-jungle' : 'font-red'}>
                                                        {v.status === 'Issued' ? 'Issued' : 'Cancelled'} by <span>{v.action_by_name} [{v.action_by_role}]</span> on <span>{util.getDate(v.action_on, 'DD MMM YYYY @ hh:mm A')}</span>
                                                    </div>
                                                }
                                            </div>
                                        </td>

                                        <td className="text-right pr10">{v.qty}</td>
                                        <td>{util.getDate(v.created, 'DD MMM YYYY')}</td>

                                        <td className="nowrap uc">
                                            <Tag color={v.status === 'Requested' ? 'blue' : (v.status === 'Issued' ? 'green' : 'red')}>
                                                {v.status}
                                            </Tag>
                                        </td>

                                        <td className="text-center">
                                            <Dropdown
                                                trigger={['click']}
                                                overlay={
                                                    <Menu>
                                                        <Menu.Item key="0" disabled={v.status !== 'Requested'}>
                                                            <span onClick={() => issueRequest(v)}>Issue</span>
                                                        </Menu.Item>
                                                        <Menu.Item key="1" disabled={!(modules['issue_stock'] || v.cancel_allowed) || v.status !== 'Requested'}>
                                                            <span onClick={() => cancelRequest(v)}>Cancel</span>
                                                        </Menu.Item>
                                                    </Menu>
                                                }
                                            >
                                                <span className="ant-dropdown-link cpointer fs18" onClick={e => e.preventDefault()} style={{ lineHeight: '18px' }}>
                                                    <MoreOutlined />
                                                </span>
                                            </Dropdown>

                                            {/* <Button.Group size="small">
                                                {modules['issue_stock']===1 && 
                                                <Button type="primary" onClick={()=>{issueRequest(v)}} disabled={v.status!=='Requested'}>
                                                    Issue
                                                </Button>}
                                                <Button type="danger" onClick={()=>cancelRequest(v)} disabled={!(modules['issue_stock'] || v.cancel_allowed) || v.status!=='Requested'}>
                                                    Cancel
                                                </Button>
                                            </Button.Group> */}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>

            <StockRequestForm
                refOb={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                stationPoints={stationPoints}
            />

            <TicketDetail
                refOb={ticketDtlRef}
                stockReqPageList={list}
                stockReqPageno={sdataRef.current.p}
            />
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch, clients, stationPoints, isNational } = props;
    let [data, setData] = useState({ ...dataRef.current, request_to: 'Internal' });
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    useEffect(() => {
        dataRef.current = { ...data };
    }, [data]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                {isNational === 1 &&
                    <div className="w150 mr5">
                        <div className="text-secondary fs11 mb2">Request From</div>
                        <AntdSelect
                            placeholder="Facility (All)"
                            allowClear
                            showSearch
                            options={clients}
                            value={data.client_id}
                            onChange={v => handleChange(v, 'client_id')}
                        />
                    </div>
                }

                {isNational === 0 &&
                    <div className="w150 mr5">
                        <div className="text-secondary fs11 mb2">Request To</div>
                        <AntdSelect
                            options={['Internal', 'National']}
                            value={data.request_to}
                            onChange={v => handleChange(v, 'request_to')}
                        />
                    </div>
                }

                <div className="w200 mr5">
                    <div className="text-secondary fs11 mb2">Station Point</div>
                    <AntdSelect
                        placeholder="Station Point (All)"
                        showSearch
                        allowClear
                        options={stationPoints.filter(v => v.is_my)}
                        value={data.station_id}
                        onChange={v => handleChange(v, 'station_id')}
                    />
                </div>

                <div className="w150 mr5">
                    <div className="text-secondary fs11 mb2">Status</div>
                    <AntdSelect
                        placeholder="Status (All)"
                        allowClear
                        options={['Requested', 'Issued', 'Cancelled']}
                        value={data.status}
                        onChange={v => handleChange(v, 'status')}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">From Date</div>
                    <AntdDatepicker
                        placeholder="From Date"
                        allowClear
                        value={data.from_date}
                        onChange={v => {
                            if (data.to_date && moment(v) > moment(data.to_date)) {
                                message.error("From date should be less than or equal to To Date");
                                v = null;
                            }
                            handleChange(v, 'from_date');
                        }}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">To Date</div>
                    <AntdDatepicker
                        placeholder="To Date"
                        allowClear
                        value={data.to_date}
                        onChange={v => {
                            if (data.from_date && moment(v) < moment(data.from_date)) {
                                message.error("To date should be greater than or equal to From Date");
                                v = null;
                            }
                            handleChange(v, 'to_date');
                        }}
                    />
                </div>


                <div className="pt15">
                    <Button className="mt3" type="primary" icon={<i className="fa fa-search fs13"></i>} onClick={() => onSearch()}></Button>
                </div>
            </div>
        </form>
    )
}