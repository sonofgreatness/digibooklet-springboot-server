/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import VendorService from "../../services/VendorService";
import CountryService from "../../services/CountryService";
import {If} from "../../utils/Controls";
import {AntdPaging, AntdSelect, AntdTag} from "../../utils/Antd";
import {PositiveNumInput} from "../../utils/Controls";
import util from "../../utils/util";
import Tabs, {PageHeading} from "./Tabs";
import{
    Input,
    Button,
    message,
    Modal,
} from 'antd';
import{
    ExclamationCircleOutlined,
} from '@ant-design/icons';
const {confirm}=Modal;

export default function Vendor(){
    const [result, setResult]=useState({data:[], page:{}});
    const [countries, setCountries]=useState([]);
    const sdataRef=useRef({p: 1, ps: 25});
    const formRef=useRef();

    const list=(p, ps)=>{
        sdataRef.current.p=p || 1;
        sdataRef.current.ps=ps || sdataRef.current.ps;
        util.showLoader();
        VendorService.list(sdataRef.current).then(({data})=>{
            setResult(data.result);
        }).catch(e => {
            message.error(e.message);
        }).finally(()=>{
            util.hideLoader();
        })
    }

    const deleteRecord=(id)=>{
        message.destroy();
        confirm({
            title: 'Do you Want to delete this vendor?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                VendorService.delete(id).then(({data})=>{
                    message.success(data.message || 'Deleted');
                    list();
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    useEffect(()=>{
        list();

        CountryService.all().then(res=>{
            setCountries([...res.data.result]);
        });

        return ()=>{message.destroy()}
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <PageHeading />
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                <div className="tabbable-custom">
                    <Tabs active="vendors" />
                    <div className="tab-content">
                        <div className="tab-pane fade1 show active">
                            {result.data.length > 0 &&
                                <div className="text-secondary mb8">
                                    Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                                </div>
                            }

                            <div className="d-flex tbl-search-head">
                                <div className="my-auto">
                                    <SearchForm dataRef={sdataRef} onSearch={list} />
                                </div>
                                <div className="ml-auto my-auto">
                                    <Button type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i> Add</Button>
                                </div>
                            </div>

                            <If cond={result.data.length}>
                                <div className="table-responsive">
                                    <table className="table table-bordered table-md table-striped table-hover m-0">
                                        <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                            <tr>
                                                <th className="w20">SN</th>
                                                <th>Vendor</th>
                                                <th className="w60">Email</th>
                                                <th className="w130">Phone</th>
                                                <th className="w60">Status</th>
                                                <th className="w70"></th>
                                            </tr>
                                        </thead>
                                        <tbody className="table-text-top font-md">
                                            {result.data.map((v, i) => (
                                                <tr key={i}>
                                                    <td>{result.page.start + i + 1}.</td>
                                                    <td>
                                                        {v.name}
                                                        <div className="note-text pt3">
                                                            <div className="d-flex"><div className="w60">Address</div>: <div className="bold600 pl5">{v.address}</div></div>
                                                            <div className="d-flex"><div className="w60">Street</div>: <div className="bold600 pl5">{v.street || 'N/A'}</div></div>
                                                            <div className="d-flex"><div className="w60">Town</div>: <div className="bold600 pl5">{v.town || 'N/A'}</div></div>
                                                            <div className="d-flex"><div className="w60">City</div>: <div className="bold600 pl5">{v.city || 'N/A'}</div></div>
                                                            <div className="d-flex"><div className="w60">Country</div>: <div className="bold600 pl5">{v.country}</div></div>
                                                        </div>
                                                    </td>
                                                    <td>{v.email}</td>
                                                    <td className="nowrap">
                                                        ({v.isd_code}) {v.phone1}
                                                        {v.phone2!=='' && 
                                                            <div>({v.isd_code}) {v.phone2}</div>
                                                        }
                                                    </td>
                                                    <td className="nowrap">
                                                        {v.status ? (<AntdTag type="success">Active</AntdTag>) : (<AntdTag type="danger">Inactive</AntdTag>)}
                                                    </td>
                                                    <td className="text-center">
                                                        <Button.Group size="small">
                                                            <Button type="default" onClick={()=>formRef.current.openForm(v)}><i className="fa fa-edit"></i></Button>
                                                            <Button type="default" onClick={()=>deleteRecord(v.id)}><i className="fa fa-times-circle font-red"></i></Button>
                                                        </Button.Group>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="d-flex tbl-foot-bx">
                                    <AntdPaging
                                        onChange={list}
                                        total={result.page.total_records}
                                        current={result.page.cur_page}
                                        pageSize={sdataRef.current.ps}
                                        showSizeChanger
                                    />
                                </div>
                            </If>
                            <If cond={!result.data.length}>
                                <div className="no-rec">No record found</div>
                            </If>
                        </div>
                    </div>
                </div>
            </div>

            <AddForm
                ref={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                countries={countries}
            />
        </div>
    )
}

const SearchForm=(props)=>{
    let {dataRef, onSearch}=props;
    let [data, setData]=useState({ ...dataRef.current });
    const handleChange=(v, k)=>{
        data[k]=v;
        setData({ ...data });
    }
    useEffect(()=>{
        dataRef.current={...data};
    }, [data]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                <div>
                    <Input placeholder="Search" allowClear value={data.k} onChange={e=>handleChange(e.target.value, 'k')} />
                </div>
                <div>
                    <Button type="primary" icon={<i className="fa fa-search fs13"></i>} onClick={()=>onSearch()}></Button>
                </div>
            </div>
        </form>
    )
}

const AddForm=forwardRef((props, ref)=>{
    let { callback, pageno } = props;
    const [showForm, setShowForm] = useState(false);
    let [data, setData] = useState({});
    const [countries, setCountries]=useState([]);
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    const save=()=>{
        message.destroy();
        util.showLoader();
        VendorService.save(data).then(({data}) => {
            message.success(data.message || 'Saved');
            callback(data.id?pageno:1);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }
    const closeForm=()=>{
        setShowForm(false);
    }

    useEffect(()=>{
        setCountries([...props.countries]);
    }, [props.countries]);

    useImperativeHandle(ref, ()=>({
        openForm(dtl){
            setData(dtl?{...dtl}:{ status:'1'});
            setShowForm(true);
        }
    }));

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Add'} Vendor`}
            visible={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={800}
        >
            <form onSubmit={e=> {e.preventDefault(); save()}} autoComplete="off" spellCheck="false">
                <div className="">
                    <div className="row mingap">
                        <div className="col-md-6 form-group">
                            <label className="req">Vendor Name</label>
                            <Input value={data.name || ''} onChange={e => handleChange(e.target.value, 'name')} />
                        </div>
                        <div className="col-md-6 form-group">
                            <label className="req">Email</label>
                            <Input value={data.email || ''} onChange={e => handleChange(e.target.value, 'email')} />
                        </div>
                        <div className="col-md-12 form-group">
                            <label className="req">Address</label>
                            <Input value={data.address || ''} onChange={e => handleChange(e.target.value, 'address')} />
                        </div>
                        <div className="col-md-4 form-group">
                            <label className="">Street</label>
                            <Input value={data.street || ''} onChange={e => handleChange(e.target.value, 'street')} />
                        </div>
                        <div className="col-md-4 form-group">
                            <label className="">Town</label>
                            <Input value={data.town || ''} onChange={e => handleChange(e.target.value, 'town')} />
                        </div>
                        <div className="col-md-4 form-group">
                            <label className="">City</label>
                            <Input value={data.city || ''} onChange={e => handleChange(e.target.value, 'city')} />
                        </div>

                        <div className="col-md-12 form-group">
                            <label className="req">Country</label>
                            <div>
                                <AntdSelect
                                    showSearch
                                    options={countries.map(v=>{return {id:v.id, title:('('+v.isd_code+') '+v.title)}})}
                                    value={data.country_id}
                                    onChange={v=>{handleChange(v, 'country_id')}}
                                />
                            </div>
                        </div>

                        <div className="col-md-4 form-group">
                            <label className="req">Phone 1</label>
                            <PositiveNumInput className="form-control" value={data.phone1 || ''} onChange={e=>handleChange(e, 'phone1')} maxLength="10" />
                        </div>
                        <div className="col-md-4 form-group">
                            <label>Phone 2</label>
                            <PositiveNumInput className="form-control" value={data.phone2 || ''} onChange={e=>handleChange(e, 'phone2')} maxLength="10" />
                        </div>
                        <div className="col-md-4 form-group">
                            <label className="req">Status</label>
                            <div>
                                <AntdSelect
                                    options={[{value:'1', label:"Active"}, {value:'0', label:"Inactive"}]}
                                    value={data.status}
                                    onChange={v=>{handleChange(v, 'status')}}
                                />
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </Modal>
    )
})