/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import AssetService from "../../services/AssetService";
import ManufacturerService from "../../services/ManufacturerService";
import ServiceProviderService from "../../services/ServiceProviderService";
import VendorService from "../../services/VendorService";
import { If } from "../../utils/Controls";
import { AntdPaging, AntdSelect, AntdTag } from "../../utils/Antd";
import util from "../../utils/util";
import BTabs, { PageHeading } from "./Tabs";

import {
    Input,
    Button,
    message,
    Modal,
    Tabs
} from 'antd';
import {
    ExclamationCircleOutlined,
} from '@ant-design/icons';
const { confirm } = Modal;

export default function Items() {
    const [assetCats, setAssetCats] = useState([]);
    const [uoms, setUoms] = useState([]);
    const [models, setModels] = useState([]);
    const [manufacturers, setManufacturers] = useState([]);
    const [serviceProviders, setServiceProviders] = useState([]);
    const [vendors, setVendors] = useState([]);
    const [tab, setTab] = useState('1');

    const onTabChange = (key) => {
        setTab(key);
    }

    useEffect(() => {
        AssetService.allCats({ status: 1 }).then(res => {
            setAssetCats(res.data.result.data);
        });
        AssetService.allModel({ status: 1 }).then(res => {
            setModels(res.data.result.data);
        });
        AssetService.allUom({ status: 1 }).then(res => {
            setUoms(res.data.result.data);
        });
        ManufacturerService.all({ status: 1 }).then(res => {
            setManufacturers(res.data.result.data);
        });
        ServiceProviderService.all({ status: 1 }).then(res => {
            setServiceProviders(res.data.result.data);
        });
        VendorService.all({ status: 1 }).then(res => {
            setVendors(res.data.result.data);
        });
        return () => { message.destroy() }
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <PageHeading />
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                <div className="tabbable-custom">
                    <BTabs active="items" />
                    <div className="tab-content">
                        <div className="tab-pane fade1 show active">
                            <Tabs
                                activeKey={tab}
                                destroyInactiveTabPane
                                onChange={onTabChange}
                                items={[
                                    {
                                        key: "1",
                                        label: "Med/NonMed Items",
                                        children: (
                                            <List
                                                assetCats={assetCats}
                                                uoms={uoms}
                                                models={models}
                                                manufacturers={manufacturers}
                                                serviceProviders={serviceProviders}
                                                vendors={vendors}
                                                cat_type="Med/NonMed"
                                            />
                                        ),
                                    },
                                    {
                                        key: "2",
                                        label: "Infrastructure",
                                        children: (
                                            <List
                                                assetCats={assetCats}
                                                uoms={uoms}
                                                models={models}
                                                manufacturers={manufacturers}
                                                cat_type="Infrastructure"
                                            />
                                        ),
                                    },
                                ]}
                            />
                            {/* <Tabs activeKey={tab} onChange={onTabChange}>
                                {['Med/NonMed', 'Infrastructure'].map(v => (
                                    <TabsTabPane tab={v + ' Items'} key={v}>
                                        {v === tab &&
                                            <List
                                                assetCats={assetCats}
                                                uoms={uoms}
                                                models={models}
                                                manufacturers={manufacturers}
                                                cat_type={v}
                                            />
                                        }
                                    </TabsTabPane>
                                ))}
                            </Tabs> */}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

function List(props) {
    const { manufacturers, serviceProviders, vendors } = props;
    const [assetCats, setAssetCats] = useState([]);
    const [uoms, setUoms] = useState([]);
    const [models, setModels] = useState([]);

    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25, cat_type: props.cat_type || '' });
    const formRef = useRef();

    const list = (p, ps) => {
        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        util.showLoader();
        AssetService.items(sdataRef.current).then(({ data }) => {
            setResult(data.result);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const deleteRecord = (id) => {
        message.destroy();
        confirm({
            title: 'Do you Want to delete this station point?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                AssetService.deleteItem(id).then(({ data }) => {
                    message.success(data.message || 'Deleted');
                    list();
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    useEffect(() => {
        setAssetCats(props.assetCats.filter(v => { return v.type === props.cat_type }));
    }, [props.assetCats, props.cat_type]);
    useEffect(() => {
        setUoms(props.uoms);
        setModels(props.models)
    }, [props.uoms, props.models]);

    useEffect(() => {
        list();
        return () => { message.destroy() }
    }, []);

    return (
        <div>
            <div>
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="d-flex tbl-search-head">
                    <div className="my-auto">
                        <SearchForm dataRef={sdataRef} onSearch={list} />
                    </div>
                    <div className="ml-auto my-auto">
                        <Button type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i> Add</Button>
                    </div>
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm table-striped table-hover font-md m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md font-sm">
                                <tr>
                                    <th className="w20">SN</th>
                                    <th className="w150">Category</th>
                                    <th className="w150">Sub Category</th>
                                    <th>Item Name</th>
                                    <th className="w200"></th>
                                    <th className="w150">Model</th>
                                    <th className="w100">UoM</th>
                                    <th className="w60">Status</th>
                                    <th className="w70"></th>
                                </tr>
                            </thead>
                            <tbody className="table-text-top">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{result.page.start + i + 1}.</td>
                                        <td>{v.cat}</td>
                                        <td>{v.subcat || 'N/A'}</td>
                                        <td>
                                            {v.name}
                                            {props.cat_type === 'Med/NonMed' &&
                                                <div className="pt3 fs11 text-secondary">
                                                    Service Period: <span className="bold600">Every {v.service_period} {v.service_period_type}</span>
                                                </div>
                                            }
                                        </td>
                                        <td>
                                            <div className='d-flex fs11' style={{ flexDirection: 'column', gap: '6px' }}>
                                                <div>
                                                    <div className='text-secondary'>Manufacturer:</div>
                                                    <div>{v.manufacturer || 'N/A'}</div>
                                                </div>
                                                <div>
                                                    <div className='text-secondary'>Service Provider:</div>
                                                    <div>{v.service_provider || 'N/A'}</div>
                                                </div>
                                                <div>
                                                    <div className='text-secondary'>Vendor:</div>
                                                    <div>{v.vendor || 'N/A'}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>{v.model}</td>
                                        <td>{v.uom}</td>
                                        <td className="nowrap">
                                            {v.status ? (<AntdTag type="success">Active</AntdTag>) : (<AntdTag type="danger">Inactive</AntdTag>)}
                                        </td>
                                        <td className="text-center">
                                            <Button.Group size="small">
                                                <Button type="default" onClick={() => formRef.current.openForm(v)}><i className="fa fa-edit"></i></Button>
                                                <Button type="default" onClick={() => deleteRecord(v.id)}><i className="fa fa-times-circle font-red"></i></Button>
                                            </Button.Group>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>

            <AddForm
                ref={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                assetCats={assetCats}
                manufacturers={manufacturers}
                serviceProviders={serviceProviders}
                vendors={vendors}
                uoms={uoms}
                models={models}
            />
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch } = props;
    let [data, setData] = useState({ ...dataRef.current });
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    useEffect(() => {
        dataRef.current = { ...data };
    }, [data]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                <div>
                    <Input placeholder="Search" allowClear value={data.k} onChange={e => handleChange(e.target.value, 'k')} />
                </div>
                <div>
                    <Button type="primary" icon={<i className="fa fa-search fs13"></i>} onClick={() => onSearch()}></Button>
                </div>
            </div>
        </form>
    )
}

const AddForm = forwardRef((props, ref) => {
    let { callback, pageno, assetCats, manufacturers, serviceProviders, vendors, uoms, models } = props;
    const [showForm, setShowForm] = useState(false);
    let [data, setData] = useState({});
    let [catDtl, setCatDtl] = useState({ subcats: [] });
    let [render, reRender] = useState(false);
    const handleChange = (v, k) => {
        data[k] = v;

        if (k === 'asset_cat_id') {
            data.asset_sub_cat_id = null;
            setCatDtl(getCatDtl(v));
        }

        setData({ ...data });
    }

    const getCatDtl = (cat_id) => {
        let dtl = { subcats: [] };
        assetCats.forEach(r => {
            if (r.id === cat_id) {
                dtl = util.copyObj(r);
            }
        });
        return dtl;
    }

    const save = () => {
        message.destroy();
        util.showLoader();
        AssetService.saveItem(data).then(({ data }) => {
            message.success(data.message || 'Saved');
            callback(data.id ? pageno : 1);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }
    const closeForm = () => {
        setShowForm(false);
    }

    useEffect(() => {
        //console.log("sat", assetCats)
        reRender(!render);
    }, [assetCats]);

    useImperativeHandle(ref, () => ({
        openForm(dtl) {
            let asset_cat_id = null;
            if (!dtl) {
                asset_cat_id = assetCats[0].id;
                setCatDtl(getCatDtl(asset_cat_id));
            }
            if (dtl) {
                setCatDtl(getCatDtl(dtl.asset_cat_id));
            }
            setData(dtl ? { ...dtl } : { asset_cat_id, service_period_type: 'Months', status: '1' });
            setShowForm(true);
        }
    }));

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Add'} Item`}
            open={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={400}
            style={{ top: 20 }}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                <div className="">
                    <div className="row mingap">
                        <div className="col-md-12 form-group">
                            <label className="req">Asset Category</label>
                            <div>
                                <AntdSelect
                                    showSearch
                                    options={assetCats}
                                    value={data.asset_cat_id}
                                    onChange={v => {
                                        handleChange(v, 'asset_cat_id');
                                    }}
                                />
                            </div>
                        </div>

                        {catDtl.subcats.length > 0 &&
                            <div className="col-md-12 form-group">
                                <label className="req">Sub Category</label>
                                <div>
                                    <AntdSelect sort showSearch options={catDtl.subcats} value={data.asset_sub_cat_id} onChange={v => { handleChange(v, 'asset_sub_cat_id') }} />
                                </div>
                            </div>
                        }

                        <div className="col-md-12 form-group">
                            <label className="req">Item Name</label>
                            <Input value={data.name || ''} onChange={e => handleChange(e.target.value, 'name')} />
                        </div>

                        <div className="col-md-12 form-group">
                            <label className="req">Description</label>
                            <Input.TextArea rows="4" value={data.description || ''} onChange={e => handleChange(e.target.value, 'description')} />
                        </div>

                        <div className="col-md-12 form-group">
                            <label className={catDtl.type === 'Med/NonMed' ? "req" : ""}>Manufacturer</label>
                            <div>
                                <AntdSelect sort showSearch allowClear options={manufacturers} value={data.manufacturer_id} onChange={v => { handleChange(v, 'manufacturer_id') }} />
                            </div>
                        </div>

                        <div className="col-md-12 form-group">
                            <label>Service Provider</label>
                            <div>
                                <AntdSelect sort showSearch allowClear options={serviceProviders} value={data.service_provider_id} onChange={v => { handleChange(v, 'service_provider_id') }} />
                            </div>
                        </div>

                        <div className="col-md-12 form-group">
                            <label>Vendor</label>
                            <div>
                                <AntdSelect sort showSearch allowClear options={vendors} value={data.vendor_id} onChange={v => { handleChange(v, 'vendor_id') }} />
                            </div>
                        </div>

                        <div className="col-md-12 form-group">
                            <label className={catDtl.type === 'Med/NonMed' ? "req" : ""}>Model</label>
                            <div>
                                <AntdSelect sort options={models} allowClear value={data.model_id} onChange={v => { handleChange(v, 'model_id') }} />
                            </div>
                        </div>

                        {catDtl.type === 'Med/NonMed' ? (
                            <>
                                <div className="col-md-6 form-group">
                                    <label className="req">Service Period</label>
                                    <div>
                                        <AntdSelect
                                            options={["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "15", "30"]}
                                            value={data.service_period}
                                            onChange={v => { handleChange(v, 'service_period') }}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-6 form-group">
                                    <label className="req">Period Type</label>
                                    <div>
                                        <AntdSelect
                                            options={["Days", "Months", "Years", "Hours"]}
                                            value={data.service_period_type}
                                            onChange={v => { handleChange(v, 'service_period_type') }}
                                        />
                                    </div>
                                </div>
                            </>) : (
                            ""
                        )}

                        <div className="col-md-6 form-group">
                            <label className="req">UoM</label>
                            <div>
                                <AntdSelect showSearch options={uoms} value={data.uom_id} onChange={v => { handleChange(v, 'uom_id') }} />
                            </div>
                        </div>

                        <div className="col-md-6 form-group">
                            <label className="req">Status</label>
                            <div>
                                <AntdSelect
                                    options={[{ value: '1', label: "Active" }, { value: '0', label: "Inactive" }]}
                                    value={data.status}
                                    onChange={v => { handleChange(v, 'status') }}
                                />
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </Modal>
    )
})