import {Link} from 'react-router-dom';

export default function Tabs(props){
    let tabs=[
        {k:'asset-cats', lbl:'Asset Category'},
        {k:'station-points', lbl:'Station Points'},
        {k:'manufacturers', lbl:'Manufacturers'},
        {k:'service-providers', lbl:'Service Providers'},
        {k:'vendors', lbl:'Vendors'},
        {k:'uoms', lbl:'UOM'},
        {k:'models', lbl:'Models'},
        {k:'items', lbl:'Items'},
    ];
    return(
        <ul className="nav nav-tabs uc tabs-sm1">
            {tabs.map((v,i)=>(
                <li key={i} className="nav-item">
                    <Link className={"nav-link "+(v.k===props.active?'active':'')} to={"/"+v.k} data-toggle="pill">
                        {v.lbl}
                    </Link>
                </li>
            ))}
        </ul>
    )
}

export function PageHeading(){
    return (
        <h2>Masters <span className="fs13"></span></h2>
    )
}