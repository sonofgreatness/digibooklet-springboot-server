/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import TicketService from "../../services/TicketService";
import AssetService from "../../services/AssetService";
import FacilityService from "../../services/FacilityService";
import UserService from "../../services/UserService";
import { If } from "../../utils/Controls";
import { AntdPaging, AntdSelect, AntdDatepicker } from "../../utils/Antd";
import util from "../../utils/util";
import moment from "moment";
import {
    Input,
    Button,
    message,
    Modal,
} from 'antd';

import TicketDetail from './TicketDetail';

export default function Ticket() {
    const [clients, setClients] = useState([]);
    const [users, setUsers] = useState([]);
    const [infrastuctureSubCats, setInfrastuctureSubCats] = useState([]);
    const [assets, setAssets] = useState([]);
    const [stationPoints, setStationPoints] = useState([]);
    const [assignedUsers, setAssignedUsers] = useState([]);

    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25 });
    const formRef = useRef();
    const dtlRef = useRef({});
    const isNational = util.isNational();
    const modules = util.getModules();
    const ticketStatusNames = [
        { id: 1, name: 'Open' },
        { id: 2, name: 'On Hold - Awaiting Spares' },
        { id: 3, name: 'On Hold - Spares Supplied' },
        { id: 4, name: 'Completed' },
        { id: 5, name: 'Closed' }
    ];

    const list = (p, ps, getAssignedToUsers) => {
        const ids = new URLSearchParams(window.location.search).get('ids');
        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        sdataRef.current.ids = ids || '';
        util.showLoader();
        TicketService.lists(sdataRef.current, getAssignedToUsers).then(({ data }) => {
            setResult({ ...data.result });
            if (data.assigned_users) {
                setAssignedUsers(data.assigned_users);
            }
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }


    useEffect(() => {
        list(0, 0, 'getAssignedToUsers');

        FacilityService.all({ status: 1, include_me: 'Y' }).then(res => {
            let allClients = res.data.result.data.map(v => { return { id: v.id, name: v.business_name, is_national: v.is_national, is_me: v.is_me } });
            setClients(allClients);
        });

        UserService.allUsers({ status: 1 }).then(res => {
            let allUsers = res.data.result.data.map(v => { return { id: v.id, name: v.name, role: v.role } });
            setUsers(allUsers);
        });

        AssetService.infrastuctureSubCats({ status: 1 }).then(res => {
            setInfrastuctureSubCats(res.data.result);
        });

        AssetService.all({ cat_type: 'Med/NonMed', my_only: 'Y' }).then(res => {
            setAssets([...res.data.result.data.map((v) => { return { id: v.id, name: ((v.serial_no ? (v.serial_no + ' - ') : '') + v.item_full_name) + ' [' + v.cat + ']' } })]);
        });

        FacilityService.allStationPoints({ status: 1 }).then(res => {
            setStationPoints([...res.data.result.data]);
        });

        return () => { message.destroy() }
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Job Cards</h2>
                </div>
                <div className="my-auto ml-auto">
                    {modules['add_ticket'] === 1 &&
                        <Button type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i>
                            Add
                        </Button>
                    }
                </div>
            </div>

            <div className="page-pad">
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="tbl-search-head">
                    <SearchForm
                        dataRef={sdataRef}
                        onSearch={list}
                        clients={clients}
                        ticketStatusNames={ticketStatusNames}
                        assignedUsers={assignedUsers}
                        isNational={isNational}
                    />
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm font-xs table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                <tr>
                                    <th className="w20">SN</th>
                                    {isNational === 1 && <th className="w100">Facility</th>}
                                    <th className="w80 nowrap">Job Card No</th>
                                    <th className="w100">Type</th>
                                    <th>Subject</th>
                                    <th className="w150">Assigned To</th>
                                    <th className="w100">Created On</th>
                                    <th className="w80">Status</th>
                                    {modules['add_ticket'] === 1 && <th className="w20"></th>}
                                </tr>
                            </thead>
                            <tbody className="table-text-top font-sm">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{i + 1}.</td>
                                        {isNational === 1 && <td>{v.client}</td>}
                                        <td>
                                            <div
                                                className="ticket-btn"
                                                onClick={() => dtlRef.current.openDetail(v.id)}
                                            >
                                                {v.ticket_no}
                                            </div>
                                        </td>
                                        <td>{v.type}</td>
                                        <td>
                                            <div className="uc bold600">{v.subject}</div>
                                            <div className="pt2 text-secondary fs11">
                                                {v.type === 'Med/NonMed' ? (
                                                    <div>
                                                        {v.serial_no ? v.serial_no + ' - ' : ''} {v.item_full_name} [{v.cat}]
                                                    </div>
                                                ) : (
                                                    <div>Infrastructure Type: <span className="bold600">{v.infrastucture_type}</span></div>
                                                )}
                                            </div>
                                            <div className="pt3 text-secondary fs11">
                                                Created By: <span className="bold600">{v.created_by_name} [{v.created_by_role}]</span>
                                            </div>
                                        </td>

                                        <td>{v.assigned_to_name || 'N/A'}  [{v.assigned_to_role}]</td>

                                        <td>
                                            <div className="nowrap">{util.getDate(v.created, 'DD MMM YYYY @ hh:mm A')}</div>
                                        </td>

                                        <td className="nowrap uc">{v.status_name}</td>

                                        {modules['add_ticket'] === 1 &&
                                            <td className="text-center">
                                                <Button.Group size="small">
                                                    <Button type="default" onClick={() => formRef.current.openForm(v)} disabled={!v.edit_allowed}>
                                                        <i className="fa fa-edit"></i>
                                                    </Button>
                                                </Button.Group>
                                            </td>
                                        }
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>

            <AddForm
                ref={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                assets={assets}
                infrastuctureSubCats={infrastuctureSubCats}
                stationPoints={stationPoints}
                isNational={isNational}
            />

            <TicketDetail
                refOb={dtlRef}
                users={users}
                ticketStatusNames={ticketStatusNames}
                callback={list}
                pageno={sdataRef.current.p}
                stationPoints={stationPoints}
            />
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch, clients, ticketStatusNames, isNational } = props;
    let [data, setData] = useState({ ...dataRef.current });
    const [assignedUsers, setAssignedUsers] = useState([]);

    const handleChange = (v, k) => {
        data[k] = v;
        if (k === 'client_id') {
            data.assigned_to = null;
        }
        setData({ ...data });
    }
    useEffect(() => {
        dataRef.current = { ...data };
    }, [data]);

    useEffect(() => {
        let ob = clients.find(v => v.is_me);
        setData({ ...data, client_id: ob?.id });
    }, [clients]);

    useEffect(() => {
        setAssignedUsers(props.assignedUsers);
    }, [props.assignedUsers]);


    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                {isNational === 1 &&
                    <div className="w150 mr5">
                        <div className="text-secondary fs11 mb2">Facility</div>
                        <AntdSelect
                            placeholder="Facility (All)"
                            showSearch
                            options={clients}
                            value={data.client_id}
                            onChange={v => handleChange(v, 'client_id')}
                        />
                    </div>
                }

                <div className="w200 mr5">
                    <div className="text-secondary fs11 mb2">Assigned To</div>
                    <AntdSelect
                        placeholder="Assigned To (All)"
                        showSearch
                        allowClear
                        options={assignedUsers.filter(v => v.client_id === data.client_id)}
                        value={data.assigned_to}
                        onChange={v => handleChange(v, 'assigned_to')}
                    />
                </div>

                <div className="w150 mr5">
                    <div className="text-secondary fs11 mb2">Type</div>
                    <AntdSelect
                        placeholder="Type"
                        allowClear
                        //options={['Med/NonMed', 'Infrastructure']}
                        options={[{ value: 'Med/NonMed', label: 'Med/NonMed' }, { value: 'Infrastructure', label: 'Infrastructure' }]}
                        value={data.type}
                        onChange={v => handleChange(v, 'type')}
                    />
                </div>

                <div className="w250 mr5">
                    <div className="text-secondary fs11 mb2">Status</div>
                    <AntdSelect
                        placeholder="Status (All)"
                        allowClear
                        showSearch
                        options={ticketStatusNames}
                        value={data.status_id}
                        onChange={v => handleChange(v, 'status_id')}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">From Date</div>
                    <AntdDatepicker
                        placeholder="From Date"
                        allowClear
                        value={data.from_date}
                        onChange={v => {
                            if (data.to_date && moment(v) > moment(data.to_date)) {
                                message.error("From date should be less than or equal to To Date");
                                v = null;
                            }
                            handleChange(v, 'from_date');
                        }}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">To Date</div>
                    <AntdDatepicker
                        placeholder="To Date"
                        allowClear
                        value={data.to_date}
                        onChange={v => {
                            if (data.from_date && moment(v) < moment(data.from_date)) {
                                message.error("To date should be greater than or equal to From Date");
                                v = null;
                            }
                            handleChange(v, 'to_date');
                        }}
                    />
                </div>

                <div className="w160 mr5">
                    <div className="text-secondary fs11 mb2">Job Card#</div>
                    <Input placeholder="Job Card Number" allowClear value={data.k} onChange={e => handleChange(e.target.value, 'k')} />
                </div>

                <div className="pt15">
                    <Button className="mt3" type="primary" onClick={() => onSearch()}><i className="fa fa-search fs13"></i></Button>
                </div>
            </div>
        </form>
    )
}

const AddForm = forwardRef((props, ref) => {
    let { callback, pageno, assets, infrastuctureSubCats, stationPoints } = props;
    const [showForm, setShowForm] = useState(false);
    let [data, setData] = useState({});
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    const save = () => {
        message.destroy();
        util.showLoader();
        TicketService.save(data).then(({ data }) => {
            message.success(data.message || 'Saved');
            callback(data.id ? pageno : 1);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }
    const closeForm = () => {
        setShowForm(false);
    }

    useImperativeHandle(ref, () => ({
        openForm(dtl) {
            setData(dtl ? { ...dtl } : { type: 'Med/NonMed' });
            setShowForm(true);
        }
    }));

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Create'} Job Card`}
            open={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={800}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                <div className="">
                    <div className="row mingap">
                        <div className="col-md-12 form-group">
                            <label className="req">Type</label>
                            <AntdSelect
                                options={[{ value: 'Med/NonMed', label: 'Med/NonMed' }, { value: 'Infrastructure', label: 'Infrastructure' }]}
                                value={data.type}
                                onChange={v => handleChange(v, 'type')}
                            />
                        </div>

                        <div className="col-md-12 form-group">
                            <label className="req">Station Point</label>
                            <AntdSelect
                                showSearch
                                options={stationPoints.filter(v => v.is_my)}
                                value={data.station_id}
                                onChange={v => handleChange(v, 'station_id')}
                            />
                        </div>

                        {data.type === 'Med/NonMed' ? (
                            <div className="col-md-12 form-group">
                                <label className="req">Asset</label>
                                <AntdSelect showSearch options={assets} value={data.asset_id} onChange={v => handleChange(v, 'asset_id')} />
                            </div>
                        ) : (
                            <div className="col-md-12 form-group">
                                <label className="req">Infrastructure type</label>
                                <AntdSelect showSearch options={infrastuctureSubCats} value={data.asset_sub_cat_id} onChange={v => handleChange(v, 'asset_sub_cat_id')} />
                            </div>
                        )}

                        <div className="col-md-12 form-group">
                            <label className="req">Subject</label>
                            <Input value={data.subject} onChange={e => handleChange(e.target.value, 'subject')} />
                        </div>

                        <div className="col-md-12 form-group">
                            <label className="">Description</label>
                            <Input.TextArea rows="6" value={data.description} onChange={e => handleChange(e.target.value, 'description')} />
                        </div>
                    </div>
                </div>

            </form>
        </Modal>
    )
})