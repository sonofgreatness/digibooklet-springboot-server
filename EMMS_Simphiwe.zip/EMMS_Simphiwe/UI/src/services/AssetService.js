import axios from "../utils/axios";

class AssetService{
    cats(params){
        return axios.get("assetCats", {params});
    }
    allCats(params){
        return axios.get("assetCats/ALL", {params});
    }
    saveCat(data){
        return axios.post("assetCatSave", data);
    }
    deleteCat(id){
        return axios.post("assetCatDelete", {id});
    }

    subCats(params){
        return axios.get("assetSubCats", {params});
    }
    allSubCats(params){
        return axios.get("assetSubCats/ALL", {params});
    }
    saveSubCat(data){
        return axios.post("assetSubCatSave", data);
    }
    deleteSubCat(id){
        return axios.post("assetSubCatDelete", {id});
    }
    infrastuctureSubCats(params){
        return axios.get("infrastuctureSubCats", {params});
    }

    items(params){
        return axios.get("items", {params});
    }
    allItems(params){
        return axios.get("items/ALL", {params});
    }
    saveItem(data){
        return axios.post("saveItem", data);
    }
    deleteItem(id){
        return axios.post("deleteItem", {id});
    }

    allFunctionalStatus(params){
        return axios.get("allFunctionalStatus", {params});
    }
    lists(params){
        return axios.get("assets", {params});
    }
    all(params){
        return axios.get("assets/ALL", {params});
    }
    save(data){
        return axios.post("saveAsset", data);
    }
    delete(id){
        return axios.post("deleteAsset", {id});
    }

    uoms(params){
        return axios.get("uoms", {params});
    }
    allUom(params){
        return axios.get("uoms/ALL", {params});
    }
    saveUom(data){
        return axios.post("saveUom", data);
    }
    deleteUom(id){
        return axios.post("deleteUom", {id});
    }

    models(params){
        return axios.get("models", {params});
    }
    allModel(params){
        return axios.get("models/ALL", {params});
    }
    saveModel(data){
        return axios.post("saveModel", data);
    }
    deleteModel(id){
        return axios.post("deleteModel", {id});
    }
    
    transferAsset(data){
        return axios.post("transferAsset", {...data});
    }
}

export default new AssetService();