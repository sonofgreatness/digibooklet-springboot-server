/* eslint-disable import/no-anonymous-default-export */
import axios from "../utils/axios";

class VendorService {
    list(params) {
        return axios.get("vendors", { params });
    }
    all(params) {
        return axios.get("vendors/ALL", { params });
    }
    save(data) {
        return axios.post("saveVendor", data);
    }
    delete(id) {
        return axios.post("deleteVendor", { id });
    }
}

export default new VendorService();