/* eslint-disable import/no-anonymous-default-export */
import axios from "../utils/axios";

class ManufacturerService {
    list(params) {
        return axios.get("manufacturers", { params });
    }
    all(params) {
        return axios.get("manufacturers/ALL", { params });
    }
    save(data) {
        return axios.post("saveManufacturer", data);
    }
    delete(id) {
        return axios.post("deleteManufacturer", { id });
    }
}

export default new ManufacturerService();