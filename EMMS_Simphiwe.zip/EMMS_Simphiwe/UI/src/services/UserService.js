/* eslint-disable import/no-anonymous-default-export */
import axios from "../utils/axios";

class UserService {
    modules(params) {
        return axios.get("modules", { params });
    }

    roles(params) {
        return axios.get("roles" + (params.all ? '/ALL' : ''), { params });
    }
    saveRole(data) {
        return axios.post("saveRole", data);
    }

    saveRoleForAllClients(data) {
        return axios.post("saveRoleForAllClients", data);
    }
    
    deleteRole(id) {
        return axios.post("deleteRole", { id });
    }

    users(params) {
        return axios.get("users", { params });
    }
    allUsers(params) {
        return axios.get("users/ALL", { params });
    }
    saveUser(data) {
        return axios.post("saveUser", data);
    }
    deleteUser(id) {
        return axios.post("deleteUser", { id });
    }

    /** */
    profileDetail() {
        return axios.get("user/profileDetail");
    }

    changePassword(payload) {
        return axios.post("user/changePassword", payload);
    }

    updateProfile(payload) {
        return axios.post("user/updateProfile", payload);
    }
}

export default new UserService();