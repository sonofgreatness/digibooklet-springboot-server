import axios from "../utils/axios";

class TransferService{
    transferOuts(params){
        return axios.get("transferOuts", {params});
    }
    transferIns(params){
        return axios.get("transferIns", {params});
    }
    receiveTransfer(transfer_id){
        return axios.post("receiveTransfer", {transfer_id});
    }
    cancelTransfer(transfer_id){
        return axios.post("cancelTransfer", {transfer_id});
    }
    approveTransfer(transfer_id){
        return axios.post("approveTransfer", {transfer_id});
    }
}

export default new TransferService();