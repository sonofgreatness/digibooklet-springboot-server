import axios from "../utils/axios";
import {
    message
} from 'antd';

class FileService{
    upload=(file, client_id)=>new Promise((resolve, reject)=>{
        let fd=new FormData();
        fd.append("client_id", client_id || '');
        fd.append('file', file);
        axios.post("uploadFile", fd).then(res=>{
            resolve(res);
        }).catch(e=>{
            message.error(e.message);
            reject(false);
        }).finally(()=>{
        })
    })
}

export default new FileService();