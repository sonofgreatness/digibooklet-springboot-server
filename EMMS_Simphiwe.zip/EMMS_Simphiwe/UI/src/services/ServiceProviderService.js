/* eslint-disable import/no-anonymous-default-export */
import axios from "../utils/axios";

class ServiceProviderService {
    list(params) {
        return axios.get("serviceProviders", { params });
    }
    all(params) {
        return axios.get("serviceProviders/ALL", { params });
    }
    save(data) {
        return axios.post("saveServiceProvider", data);
    }
    delete(id) {
        return axios.post("deleteServiceProvider", { id });
    }
}

export default new ServiceProviderService();