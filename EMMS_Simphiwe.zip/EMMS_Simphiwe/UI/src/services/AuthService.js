import axios from "../utils/axios";

class AuthService{
    login(data){
        return axios.post("login", data);
    }
}

export default new AuthService();