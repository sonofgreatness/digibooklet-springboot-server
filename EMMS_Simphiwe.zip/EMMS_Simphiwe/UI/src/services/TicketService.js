import axios from "../utils/axios";

class TicketService{
    lists(params, getAssignedToUsers){
        return axios.get("tickets/"+(getAssignedToUsers || ''), {params});
    }
    save(data){
        return axios.post("saveTicket", data);
    }
    detail(id){
        return axios.get(`ticketDetail/${id}`);
    }
    comments(id){
        return axios.get(`ticketComments/${id}`);
    }
    assign(data){
        return axios.post("assignTicket", data);
    }
    addComment(data){
        return axios.post("ticketAddComment", data);
    }
    changeStatus(data){
        return axios.post("ticketStatusChange", data);
    }
    markAsRepairInScope(id){
        return axios.post(`markAsRepairInScope`, {id});
    }
    markAsRepairNotInScope(id){
        return axios.post(`markAsRepairNotInScope`, {id});
    }
    uploadCommentPhoto(data){
        return axios.post("uploadTicketCommentPhoto", data);
    }
}

export default new TicketService();