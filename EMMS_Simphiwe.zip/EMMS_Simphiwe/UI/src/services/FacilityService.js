import axios from "../utils/axios";

class FacilityService{
    list(params){
        return axios.get("clients", {params});
    }
    all(params){
        return axios.get("clients/ALL", {params});
    }
    save(data){
        return axios.post("saveClient", data);
    }
    delete(id){
        return axios.post("deleteClient", {id});
    }

    listStationPoint(params){
        return axios.get("stationPoints", {params});
    }
    allStationPoints(params){
        return axios.get("stationPoints/ALL", {params});
    }
    saveStationPoint(data){
        return axios.post("saveStationPoint", data);
    }
    deleteStationPoint(id){
        return axios.post("deleteStationPoint", {id});
    }
    allAssetCats(){
        return axios.post("allAssetCats", {});
    }

    saveConfig(data){
        return axios.post("saveConfig", data);
    }
}

export default new FacilityService();