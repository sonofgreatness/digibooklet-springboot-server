<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');
if (!function_exists('wh_log')) {
	    function wh_log($message) {
		            $filepath = APPPATH . 'logs/log-' . date('Y-m-d') . '.php';
			            $message = date('Y-m-d H:i:s') . ' --> ' . $message . "\n";
			            file_put_contents($filepath, $message, FILE_APPEND);				        }
}
?>
