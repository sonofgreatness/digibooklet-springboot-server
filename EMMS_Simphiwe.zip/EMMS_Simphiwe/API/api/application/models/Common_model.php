<?php 
class Common_model extends CI_Model {
    function admin_email(){
        return $this->db->select("email")->get_where("user_master", ['role_id'=>1])->row()->email;
    }
    
    function smtp_dtl(){
        return $this->db->limit(1)->get_where("master_smtp", ['status'=>1])->row_array();
    }

    function send_email_old($to, $subject, $message, $attachments=[]){
        if(ENVIRONMENT=='development'){
            //return TRUE;
        }
        
        if(is_array($to) && isset($to['to'])){
            $cc=$to['cc'];
            $to=$to['to'];
        }

        $fromname="ELMIS";
        $fromemail="elmis@eswatinimedicalstores.org";
        $replyto="noreply@eswatinimedicalstores.org";
        
        $smtpdtl=[
            'host'=>"smtp.office365.com", 
            'user'=>"elmis@eswatinimedicalstores.org",
            'pass'=>"Notifications@123",
            'port'=>"587",
        ];
        
        $this->load->library('email');
        $this->email->clear();
        
        $config['charset'] = 'utf-8';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';
        
        $config['protocol']   = "smtp";
        $config['smtp_host']  = $smtpdtl['host'];
        $config['smtp_user']  = $smtpdtl['user'];
        $config['smtp_pass']  = $smtpdtl['pass'];
        $config['smtp_port']  = $smtpdtl['port'];
        $config['_auth_smtp'] = TRUE;
        $config['newline']    = "\r\n";
        $config['crlf']       = "\r\n";

        $config['smtp_crypto'] = 'tls';
        
        $this->email->initialize($config);
    
        $this->email->from($fromemail, $fromname);
        $this->email->to($to);
        if($cc){
            $this->email->cc($cc);
        }
    
        $this->email->reply_to($replyto, $fromname);
        
        $this->email->subject($subject);
        $this->email->message($message);
        
        if($attachments and is_array($attachments)){
            foreach($attachments as $f){
                $this->email->attach($f);
            }
        }
    
        $res=$this->email->send();
        $res=$this->email->print_debugger();

        if(strpos($res, 'Unable')===FALSE && strpos($res, 'Failed')===FALSE){
            return true;
        }
        return $res;
    }

    function send_email($to, $subject, $message, $attachments=[], $smtp=TRUE, $smtpdtl=[], $reply_to=""){
        return true;
        if(ENVIRONMENT=='development'){
            //return TRUE;
            $to="sat.web1989@gmail.com";
        }
        if(stristr(SMTP_HOST, 'phpmail')){
            $smtp=FALSE;
        }
    
        if(is_array($to) && isset($to['to'])){
            $cc=$to['cc'];
            $to=$to['to'];
        }

        $fromname=SMTP_SENDER_NAME;
        $fromemail=SMTP_SENDER_EMAIL;
        $replyto=SMTP_REPLYTO;
        
        if(!$smtpdtl){
            $smtpdtl=[
                'host'=>SMTP_HOST, 
                'user'=>SMTP_USER,
                'pass'=>SMTP_PASS,
                'port'=>SMTP_PORT,
            ];
        }
        
        $this->load->library('email');
        $this->email->clear();
        
        $config['charset'] = 'utf-8';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';
        
        if($smtp){
            $config['protocol']   = "smtp";
            $config['smtp_host']  = $smtpdtl['host'];
            $config['smtp_user']  = $smtpdtl['user'];
            $config['smtp_pass']  = $smtpdtl['pass'];
            $config['smtp_port']  = $smtpdtl['port'];
            $config['_auth_smtp'] = TRUE;
            $config['newline']    = "\r\n";
            $config['crlf']       = "\r\n";

            if(stristr(SMTP_HOST, 'office365') || stristr(SMTP_HOST, 'amazonaws')){
                $config['smtp_crypto'] = 'tls';
            }

            $fromname=SMTP_SENDER_NAME;
            $fromemail=SMTP_SENDER_EMAIL;
            $replyto=SMTP_REPLYTO;
        }
        if($reply_to){
            $replyto=$reply_to;
        }
        
        $this->email->initialize($config);
    
        $this->email->from($fromemail, $fromname);
        $this->email->to($to);
        if($cc){
            $this->email->cc($cc);
        }
    
        $this->email->reply_to($replyto, $fromname);
        
        $this->email->subject($subject);
        $this->email->message($message);
        
        if($attachments && is_array($attachments)){
            foreach($attachments as $f){
                $this->email->attach($f);
            }
        }

        //pr($config)
    
        $res=$this->email->send();
        $res=$this->email->print_debugger();
        //echo $res;

        if(strpos($res, 'Unable')===FALSE && strpos($res, 'Failed')===FALSE){
            return true;
        }
        return true;
    }

    function userDetail($id=''){
        if(!$id){
            $id=USER_ID;
        }
        $f="u.id, u.fname, u.lname, u.name, u.email, u.mobile, u.type, u.status, u.role_id, u.client_id, c.is_national, c.status client_status";
        $dtl=$this->db->select($f)
        ->from("users u")
        ->join("clients c", "c.id=u.client_id", "left")
        ->where('u.id', $id)
        ->get()->row_array();

        if(!$dtl){
            return FALSE;
        }
        $dtl['status']=(int)$dtl['status'];
        $dtl['is_national']=$dtl['is_national']?1:0;
        $dtl['is_client_admin']=$dtl['role_id']==2?1:0;
        $dtl['is_admin']=$dtl['role_id']==1?1:0;
        $dtl['client_status']=(int)$dtl['client_status'];
        if($dtl['client_id']){
            $dtl['is_active']=($dtl['status'] && $dtl['client_status'])?1:0;
        }else{
            $dtl['is_active']=$dtl['status'];
        }

        return $dtl;
    }


    /** Notifications */
    function assetManagersIds(){
        return [5,17,24];
    }

    function sendStockRequestNoti($items, $station_point, $ticket_no, $to_national=false, $req_ids=[]){
        $udtl=$this->userDetail();
        $subject="Stock request by ".$udtl['name']." for ".$station_point;
        if($ticket_no){
            $subject.=" - Job Card #".$ticket_no;
        }
        $to_users=$this->db->select("id, name, email")->where_in("role_id", $this->assetManagersIds())->get_where("users", ['client_id'=>CLIENT_ID])->result_array();
        if($to_national){
            $national_fac=$this->db->select("id, name, email")->get_where("users", ['role_id'=>2])->row_array();
            $to_users[]=$national_fac;
        }

        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_request", ['items'=>$items, 'udtl'=>$udtl, 'station_point'=>$station_point, 'ticket_no'=>$ticket_no], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockRequest',
            'type_ids'=>$req_ids?implode(",", $req_ids):null
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockRequestCancelledNoti($items, $station_point, $ticket_no, $created_by, $req_ids=[]){
        $udtl=$this->userDetail();
        $udtl1=$this->userDetail($created_by);
        $subject="Stock request cancelled by ".$udtl['name']." for ".$station_point;
        if($ticket_no){
            $subject.=" - Job Card #".$ticket_no;
        }
        $to_users=$this->db->select("id, name, email")->where_in("role_id", [2])->get_where("users", ['client_id'=>CLIENT_ID])->result_array();
        $to_users[]=$this->db->select("id, name, email")->get_where("users", ['id'=>$created_by])->row_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_request_cancelled", ['items'=>$items, 'udtl'=>$udtl, 'udtl1'=>$udtl1, 'station_point'=>$station_point, 'ticket_no'=>$ticket_no], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockRequest',
            'type_ids'=>$req_ids?implode(",", $req_ids):null
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockRequestIssueNoti($items, $station_point, $ticket_no, $created_by, $req_ids=[]){
        $udtl=$this->userDetail();
        $udtl1=$this->userDetail($created_by);
        $subject="Stock issued by ".$udtl['name']." for ".$station_point;
        if($ticket_no){
            $subject.=" - Job Card #".$ticket_no;
        }
        $to_users=$this->db->select("id, name, email")->where_in("role_id", [2])->get_where("users", ['client_id'=>CLIENT_ID])->result_array();
        $to_users[]=$this->db->select("id, name, email")->get_where("users", ['id'=>$created_by])->row_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_issued", ['items'=>$items, 'udtl'=>$udtl, 'udtl1'=>$udtl1, 'station_point'=>$station_point, 'ticket_no'=>$ticket_no], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockRequest',
            'type_ids'=>$req_ids?implode(",", $req_ids):null
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockTransferApprovalNoti($items, $from_client_id, $to_client_id, $transfer_id){
        $this->load->model("client_model", "client");
        $from_client=$this->client->detail($from_client_id);
        $to_client=$this->client->detail($to_client_id);

        $roles=$this->db->select("id")->where("FIND_IN_SET('91', app_modules)", NULL, FALSE)->get_where("roles", ['client_id'=>$from_client_id])->result_array();
        $role_ids=[2,5,17,24];
        foreach($roles as $r){
            $role_ids[]=$r['id'];
        }
        $to_users=$this->db->select("id, name, email")->where_in("role_id", $role_ids)->get_where("users", ['client_id'=>$from_client_id])->result_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $subject="Stock Transfer Approval";
        $msg=$this->load->view("email/stock_transfer_approval", ['items'=>$items, 'from_client'=>$from_client, 'to_client'=>$to_client], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockTransfer',
            'type_ids'=>$transfer_id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockTransferredNoti($items, $from_client_id, $to_client_id, $is_approved=false, $transfer_id){
        if(!$is_approved){
            $this->sendStockTransferApprovalNoti($items, $from_client_id, $to_client_id, $transfer_id);
            return;
        }

        $this->load->model("client_model", "client");
        $from_client=$this->client->detail($from_client_id);
        $to_client=$this->client->detail($to_client_id);

        $subject="Stock transferred by ".$from_client['business_name']." to ".$to_client['business_name'];
        $to_users=$this->db->select("id, name, email")->where_in("role_id", [2,5,17,24])->get_where("users", ['client_id'=>$to_client_id])->result_array();
        $to_users[]=$this->db->select("id, name, email")->where_in("role_id", [2])->get_where("users", ['client_id'=>$from_client_id])->row_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_transferred", ['items'=>$items, 'from_client'=>$from_client, 'to_client'=>$to_client], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockTransfer',
            'type_ids'=>$transfer_id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockReceivedNoti($items, $from_client_id, $to_client_id, $transfer_id){
        $this->load->model("client_model", "client");
        $from_client=$this->client->detail($from_client_id);
        $to_client=$this->client->detail($to_client_id);

        $subject="Stock received by ".$to_client['business_name']." from ".$from_client['business_name'];
        
        $to_users=$this->db->select("id, name, email")->where_in("role_id", [2,5,17,24])->get_where("users", ['client_id'=>$from_client_id])->result_array();
        $to_users[]=$this->db->select("id, name, email")->where_in("role_id", [2])->get_where("users", ['client_id'=>$to_client_id])->row_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_received", ['items'=>$items, 'from_client'=>$from_client, 'to_client'=>$to_client], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockReceive',
            'type_ids'=>$transfer_id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendStockReceiveCancelledNoti($items, $from_client_id, $to_client_id, $transfer_id){
        $this->load->model("client_model", "client");
        $from_client=$this->client->detail($from_client_id);
        $to_client=$this->client->detail($to_client_id);

        $subject="Stock receiving cancelled by ".$to_client['business_name'].". Transferred from ".$from_client['business_name'];
        
        $to_users=$this->db->select("id, name, email")->where_in("role_id", [2,5,17,24])->get_where("users", ['client_id'=>$from_client_id])->result_array();
        $to_users[]=$this->db->select("id, name, email")->where_in("role_id", [2])->get_where("users", ['client_id'=>$to_client_id])->row_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/stock_receive_cancelled", ['items'=>$items, 'from_client'=>$from_client, 'to_client'=>$to_client], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'StockReceive',
            'type_ids'=>$transfer_id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendTicketAssignedNoti($id, $user_id){
        $udtl=$this->userDetail();
        $udtl1=$this->userDetail($user_id);
        $dtl=$this->db->get_where("tickets", ['id'=>$id])->row_array();
        $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$dtl['station_id']])->row("name");
        $subject="Job Card (#{$dtl['ticket_no']}) assigned to you by ".$udtl['name']." for ".$station_point;
        $to_users=$this->db->select("id, name, email")->get_where("users", ['id'=>$user_id])->result_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/ticket_assigned", ['dtl'=>$dtl, 'udtl'=>$udtl, 'udtl1'=>$udtl1, 'station_point'=>$station_point], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'Ticket',
            'type_ids'=>$id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendTicketCompletedNoti($id){
        $udtl=$this->userDetail();
        $dtl=$this->db->get_where("tickets", ['id'=>$id])->row_array();
        $udtl1=$this->userDetail($dtl['created_by']);
        $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$dtl['station_id']])->row("name");
        $subject="Job Card (#{$dtl['ticket_no']}) completed by ".$udtl['name']." for ".$station_point;
        $to_users=$this->db->select("id, name, email")->get_where("users", ['id'=>$dtl['created_by']])->result_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/ticket_completed", ['dtl'=>$dtl, 'udtl'=>$udtl, 'udtl1'=>$udtl1, 'station_point'=>$station_point], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'Ticket',
            'type_ids'=>$id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }

    function sendTicketClosedNoti($id){
        $udtl=$this->userDetail();
        $dtl=$this->db->get_where("tickets", ['id'=>$id])->row_array();
        $udtl1=$this->userDetail($dtl['created_by']);
        $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$dtl['station_id']])->row("name");
        $subject="Job Card (#{$dtl['ticket_no']}) closed by ".$udtl['name']." for ".$station_point;
        $to_users=$this->db->select("id, name, email")->get_where("users", ['id'=>$dtl['created_by']])->result_array();
        $to_user_ids=[];
        foreach($to_users as $u){
            $to_user_ids[]=$u['id'];
        }
        $to_user_ids=implode(",", $to_user_ids);

        $msg=$this->load->view("email/ticket_closed", ['dtl'=>$dtl, 'udtl'=>$udtl, 'udtl1'=>$udtl1, 'station_point'=>$station_point], true);

        $msg1=explode("<!--Content-->", $msg);
        $msg1=explode("<!--ContentEnd-->", $msg1[1]);
        $data=[
            'subject'=>$subject,
            'msg'=>trim(compressHtml($msg1[0])),
            'to_user_ids'=>$to_user_ids,
            'created'=>currentDT(),
            'type'=>'Ticket',
            'type_ids'=>$id
        ];
        $this->db->insert("notifications", $data);

        foreach($to_users as $u){
            $this->send_email($u['email'], $subject, $msg);
        }
    }
}

//End of file