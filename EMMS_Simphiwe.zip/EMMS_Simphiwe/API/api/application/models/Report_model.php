<?php
class Report_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }

    function stockTransactions($all=false){
        $qs=trimArray($this->input->get());

        if(IS_NATIONAL_CLIENT){
            if($qs['client_id']){
                $this->db->where("a.client_id", $qs['client_id']);
            }else{
                $this->db->where("a.client_id", CLIENT_ID);
            }
        }else{
            $this->db->where("a.client_id", CLIENT_ID);
        }

        if($qs['k']){
            $this->db->group_start();
                $this->db->like("i.name", $qs['k']);
            $this->db->group_end();
        }
        if($qs['action_id']){
            $this->db->where("t.action_id", $qs['action_id']);
        }
        if($qs['item_id']){
            $this->db->where("a.item_id", $qs['item_id']);
        }
        if($qs['from_date']){
            $this->db->where("t.txn_date>=", toDate($qs['from_date'], '', 'Y-m-d'));
        }
        if($qs['to_date']){
            $this->db->where("t.txn_date<=", toDate($qs['to_date'], '', 'Y-m-d 23:59:59'));
        }
        

        $f="t.id, t.stock_before, t.qty, t.stock_after, t.txn_date, t.created, sa.name action,
            c.business_name client, a.serial_no, i.name item, md.name model, i.asset_cat_id, i.asset_sub_cat_id, 
            ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacture,
            u1.name created_by_name, r1.title created_by_role";
        $this->db->select($f)
        ->from("stock_transactions t")
        ->join("mm_stock_actions sa", "sa.id=t.action_id")
        ->join("assets a", "a.id=t.asset_id")
        ->join("clients c", "c.id=a.client_id")
        ->join("items i", "i.id=a.item_id")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("users u1", "u1.id=t.created_by")
        ->join("roles r1", "r1.id=u1.role_id")
        ->order_by("t.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['item_full_name']=$r['item'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }

            $r['stock_before']=(float)$r['stock_before'];
            $r['qty']=(float)$r['qty'];
            $r['stock_after']=(float)$r['stock_after'];

            $r['created_by_user']=$r['created_by_name'].' ['.$r['created_by_role'].']';
        }
        return $rs;
    }
}

// EOF