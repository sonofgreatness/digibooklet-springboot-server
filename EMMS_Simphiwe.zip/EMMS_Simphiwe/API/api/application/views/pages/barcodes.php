<!DOCTYPE HTML>
<html>
<head>
    <title>.</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="<?php echo URL.'assets/style.css?'.time()?>" />
</head>

<body>
	<div>
        <?php foreach($result as $r):?>
            <div class="bbox">
                <?php if($r['title']):?>
                    <div class="pb2"><?php echo $r['title']?></div>
                <?php endif;?>
                <div style="height:30px"><img src="<?php echo barcode_image_data($r['barcode']?$r['barcode']:$r['code'])?>" /></div>
                <div class="pt2"><?php echo $r['code']?></div>
            </div>
        <?php endforeach;?>
	</div>

    <?php if($_GET['print']):?>
        <script type="text/javascript">
            window.print();
        </script>
    <?php endif;?>
</body>
</html>