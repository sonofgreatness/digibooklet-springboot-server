<?php
class MY_Security extends CI_Security {
    function __construct() {
        parent::__construct();
    }
    
	public function csrf_set_cookie()
	{
		$expire = time() + $this->_csrf_expire;
		$secure_cookie = FALSE;//(bool) config_item('cookie_secure');

		if ($secure_cookie && ! is_https())
		{
			return FALSE;
		}

		setcookie(
			$this->_csrf_cookie_name,
			$this->_csrf_hash,
			$expire,
			config_item('cookie_path'),
			config_item('cookie_domain'),
			$secure_cookie,
			FALSE
		);
		log_message('info', 'CSRF cookie sent');

		return $this;
	}
}

/** End of file **/