<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] 	= 'common/error404';
$route['404_override'] 			= 'common/error404';

/** Apis */
$route['login'] 		                            = 'auth/login';
$route['uploadFile'] 		                        = 'file/upload';

$route['modules']                                   = 'user/modules';
$route['roles']                                     = 'user/roles';
$route['roles/(:any)']                              = 'user/roles/$1';
$route['saveRole']                                  = 'user/saveRole';
$route['saveRoleForAllClients']                     = 'user/saveRoleForAllClients';


$route['deleteRole']                                = 'user/deleteRole';
$route['users']                                     = 'user/users';
$route['users/(:any)']                              = 'user/users/$1';
$route['saveUser']                                  = 'user/saveUser';
$route['deleteUser']                                = 'user/deleteUser';

$route['clients'] 	                                = 'client/lists';
$route['clients/(:any)'] 	                        = 'client/lists/$1';
$route['saveClient'] 	                            = 'client/save';
$route['deleteClient'] 	                            = 'client/delete';

$route['stationPoints']                             = 'client/stationPointLists';
$route['stationPoints/(:any)']                      = 'client/stationPointLists/$1';
$route['saveStationPoint']                          = 'client/saveStationPoint';
$route['deleteStationPoint']                        = 'client/deleteStationPoint';
$route['saveConfig']                                = 'client/saveConfig';

$route['assetCats']                                 = 'asset/cats';
$route['assetCats/(:any)']                          = 'asset/cats/$1';
$route['assetCatSave']                              = 'asset/saveCat';
$route['assetCatDelete']                            = 'asset/deleteCat';

$route['assetSubCats']                              = 'asset/assetSubCats';
$route['assetSubCats/(:any)']                       = 'asset/assetSubCats/$1';
$route['assetSubCatSave']                           = 'asset/assetSubCatSave';
$route['assetSubCatDelete']                         = 'asset/assetSubCatDelete';
$route['infrastuctureSubCats']                      = 'asset/infrastuctureSubCats';

$route['uoms']                                      = 'asset/uoms';
$route['uoms/(:any)']                               = 'asset/uoms/$1';
$route['saveUom']                                   = 'asset/saveUom';
$route['deleteUom']                                 = 'asset/deleteUom';

$route['allFunctionalStatus']                       = 'asset/allFunctionalStatus';
$route['assets']                                    = 'asset/lists';
$route['assets/(:any)']                             = 'asset/lists/$1';
$route['saveAsset']                                 = 'asset/save';
$route['deleteAsset']                               = 'asset/delete';

$route['items']                                     = 'asset/items';
$route['items/(:any)']                              = 'asset/items/$1';
$route['saveItem']                                  = 'asset/saveItem';
$route['deleteItem']                                = 'asset/deleteItem';

$route['manufacturers']                             = 'manufacturer/lists';
$route['manufacturers/(:any)']                      = 'manufacturer/lists/$1';
$route['saveManufacturer']                          = 'manufacturer/save';
$route['deleteManufacturer']                        = 'manufacturer/delete';

$route['serviceProviders']                          = 'service_provider/lists';
$route['serviceProviders/(:any)']                   = 'service_provider/lists/$1';
$route['saveServiceProvider']                       = 'service_provider/save';
$route['deleteServiceProvider']                     = 'service_provider/delete';

$route['vendors']                                   = 'vendor/lists';
$route['vendors/(:any)']                            = 'vendor/lists/$1';
$route['saveVendor']                                = 'vendor/save';
$route['deleteVendor']                              = 'vendor/delete';

$route['countries']                                 = 'country/all';

$route['models']                                    = 'asset/models';
$route['models/(:any)']                             = 'asset/models/$1';
$route['saveModel']                                 = 'asset/saveModel';
$route['deleteModel']                               = 'asset/deleteModel';

$route['transferAsset']                             = 'transfer/transferAsset';
$route['transferOuts']                              = 'transfer/transferOuts';
$route['transferIns']                               = 'transfer/transferIns';
$route['receiveTransfer']                           = 'transfer/receiveTransfer';
$route['cancelTransfer']                            = 'transfer/cancelTransfer';
$route['approveTransfer']                           = 'transfer/approveTransfer';

$route['tickets']                                   = 'ticket/lists';
$route['tickets/(:any)']                            = 'ticket/lists/$1';
$route['saveTicket']                                = 'ticket/save';
$route['ticketDetail/(:any)']                       = 'ticket/detail/$1';
$route['ticketComments/(:any)']                     = 'ticket/comments/$1';
$route['assignTicket']                              = 'ticket/assign';
$route['ticketAddComment']                          = 'ticket/addComment';
$route['ticketStatusChange']                        = 'ticket/changeStatus';
$route['markAsRepairInScope']                       = 'ticket/markAsRepairInScope';
$route['markAsRepairNotInScope']                    = 'ticket/markAsRepairNotInScope';
$route['uploadTicketCommentPhoto']                  = 'ticket/uploadCommentPhoto';

$route['stockRequests']                             = 'stock_request/lists';
$route['stockRequests/(:any)']                      = 'stock_request/lists/$1';
$route['saveStockRequest']                          = 'stock_request/save';
$route['cancelStockRequest']                        = 'stock_request/cancel';
$route['issueStockRequest']                         = 'stock_request/issue';
$route['ticketStockRequests/(:any)']                = 'stock_request/ticketStockRequests/$1';

$route['stockTransactionsReport']                   = 'report/stockTransactions';
$route['stockTransactionsReport/(:any)']            = 'report/stockTransactions/$1';

$route['notifications']                             = 'notifications/all';
$route['notificationRead']                          = 'notifications/read';


$route['translate_uri_dashes'] = FALSE;