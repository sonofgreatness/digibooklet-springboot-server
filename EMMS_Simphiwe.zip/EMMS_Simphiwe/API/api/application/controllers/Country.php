<?php
class Country extends MY_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model("country_model", "country");
    }

    function all(){
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->country->all();
        jsonData($res);
    }
}

//EOF