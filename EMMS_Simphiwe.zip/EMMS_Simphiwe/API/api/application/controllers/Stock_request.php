<?php
class Stock_request extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("Stock_request_model", "sr");
        $this->load->model("asset_model", "asset");
    }

    function lists($all=''){
        $this->checkAccess(['view_stock_requests', 'view_stock_requests_self']);
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->sr->lists($all==='ALL', $this->isAccess('view_stock_requests'));
        jsonData($res);
    }

    function ticketStockRequests($ticket_id=0){
        //$this->checkAccess("ticket_actions");
        $ticket_id=(int)$ticket_id;
        
        $res=['code'=>SCODE, 'message'=>''];
        if($ticket_id){
            $res['result']=$this->sr->lists(true, true, $ticket_id);
        }else{
            $res['result']=['data'=>[]];
        }
        jsonData($res);
    }

    function save(){
        $this->checkAccess('add_stock_request');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        try{
            if(!$post['station_id']){
                throw new Exception("Station point required");
            }
            if(!$post['items'] || !is_array($post['items'])){
                throw new Exception("Items required");
            }
            if(!count($post['items'])){
                throw new Exception("Items required");
            }

            $data=[
                'station_id'=>$post['station_id'],
                'items'=>[]
            ];
            foreach($post['items'] as &$r){
                if(!$r['id']){
                    throw new Exception("Item ID required");
                }
                if(!$r['qty']){
                    throw new Exception("Quantity required for all added items");
                }
                if(!is_numeric($r['qty'])){
                    throw new Exception("Quantity must be numeric");
                }
                $r['qty']=(float)$r['qty'];
                if($r['qty']<1){
                    throw new Exception("Quantity must be greater than Zero(0)");
                }

                $r['item_dtl']=$this->asset->itemDetail($r['id']);

                $data['items'][]=['id'=>$r['id'], 'qty'=>$r['qty']];
            }

            if($post['request_to']==='National'){
                if($this->isAccess('add_stock_request_external')){
                    $data['to_client_id']=1;
                }
            }

            if($req_ids=$this->sr->save($data, $post['ticket_id'])){
                $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$post['station_id']])->row("name");
                $ticket_no="";
                if($post['ticket_id']){
                    $ticket_no=$this->db->select("ticket_no")->get_where("tickets", ['id'=>$post['ticket_id']])->row("ticket_no");
                }
                $this->common->sendStockRequestNoti($post['items'], $station_point, $ticket_no, $post['request_to']==='National', $req_ids);

                $res['code']=SCODE;
                $res['message']='Stock request created successfully';
            }
        }catch(Exception $e){
            $res['message']=$e->getMessage();
        }

        jsonData($res);
    }

    function cancel(){
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        try{
            if(!$post['id']){
                throw new Exception("Request ID required");
            }
            $dtl=$this->sr->detail($post['id']);
            if(!$dtl){
                throw new Exception("Invalid data!");
            }
            if(!$dtl['cancel_allowed']){
                $this->checkAccess('issue_stock');
            }
            if($dtl['status']==='Issued'){
                throw new Exception("This request has been already issued!");
            }
            if($dtl['status']==='Cancelled'){
                throw new Exception("This request has been already cancelled!");
            }
            
            
            if($this->sr->cancel($dtl)){
                $res['result']=$this->sr->detail($post['id']);

                $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$res['result']['station_id']])->row("name");
                $ticket_no="";
                if($post['ticket_id']){
                    $ticket_no=$this->db->select("ticket_no")->get_where("tickets", ['id'=>$res['result']['ticket_id']])->row("ticket_no");
                }

                $items=[
                    [
                        'cat'=>$res['result']['cat'],
                        'subcat'=>$res['result']['subcat'],
                        'item_full_name'=>$res['result']['item_full_name'],
                        'qty'=>$res['result']['qty'],
                    ]
                ];
                $this->common->sendStockRequestCancelledNoti($items, $station_point, $ticket_no, $res['result']['created_by'], [$post['id']]);

                $res['code']=SCODE;
                $res['message']='Stock request cancelled successfully';
            }
        }catch(Exception $e){
            $res['message']=$e->getMessage();
        }

        jsonData($res);
    }

    function issue(){
        $this->checkAccess('issue_stock');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        try{
            if(!$post['id']){
                throw new Exception("Request ID required");
            }
            $dtl=$this->sr->detail($post['id']);
            if(!$dtl){
                throw new Exception("Invalid data!");
            }
            if($dtl['status']==='Issued'){
                throw new Exception("This request has been already issued!");
            }
            if($dtl['status']==='Cancelled'){
                throw new Exception("This request has been already cancelled!");
            }
            if($dtl['to_client_id']!==CLIENT_ID){
                throw new Exception("This request is not sent to you!");
            }

            $adtl=$this->asset->detail(0, $dtl['item_id']);
            if(!$adtl){
                $adtl=['stock'=>0];
            }
            if($adtl['stock']<$dtl['qty']){
                throw new Exception("Only {$adtl['stock']} QTY is available and requested QTY is {$dtl['qty']}!");
            }
            
            if($this->sr->issue($dtl, $adtl)){
                $res['result']=$this->sr->detail($post['id']);

                $station_point=$this->db->select("name")->get_where("station_points", ['id'=>$res['result']['station_id']])->row("name");
                $ticket_no="";
                if($post['ticket_id']){
                    $ticket_no=$this->db->select("ticket_no")->get_where("tickets", ['id'=>$res['result']['ticket_id']])->row("ticket_no");
                }

                $items=[
                    [
                        'cat'=>$res['result']['cat'],
                        'subcat'=>$res['result']['subcat'],
                        'item_full_name'=>$res['result']['item_full_name'],
                        'qty'=>$res['result']['qty'],
                    ]
                ];
                $this->common->sendStockRequestIssueNoti($items, $station_point, $ticket_no, $res['result']['created_by'], [$post['id']]);

                $res['code']=SCODE;
                $res['message']='Stock issued successfully';
            }
        }catch(Exception $e){
            $res['message']=$e->getMessage();
        }

        jsonData($res);
    }
}

// EOF