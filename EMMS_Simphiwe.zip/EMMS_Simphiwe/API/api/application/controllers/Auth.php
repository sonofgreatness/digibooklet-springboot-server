<?php
class Auth extends MY_Controller {
    function __construct() {
        parent::__construct();
		$this->load->model("auth_model", "auth");
    }

	function login(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', "required", $this->req);
        $this->form_validation->set_rules('password', 'Password', "required", $this->req);

		if(@$this->form_validation->run() == FALSE){
			$res['errors']=$this->form_validation->get_errors();
			$res['message']=reset($res['errors']);
		}else{
            $data=filterValue($post, ['username', 'password']);
			if($dtl=$this->auth->login($data)){
                $dtl=$this->common->userDetail($dtl['id']);
                if(!$dtl['is_active']){
                    $res['message']='Your acount is not active';
                }else{
                    $d=['id'=>$dtl['id'], 'role_id'=>$dtl['role_id'], 'expiry'=>strtotime("+24 hours")];
                    $res['token']=$this->encryption->encrypt(serialize($d));
                    $res['name']=$dtl['name'];
                    $res['modules']=$this->auth->modules($dtl['id']);
                    
                    $res['role_id']=$dtl['role_id'];
                    $res['type']=$dtl['type'];
                    $res['is_national']=$dtl['is_national'];
                    $res['is_client_admin']=$dtl['is_client_admin'];
                    $res['is_admin']=$dtl['is_admin'];
                    
                    $res['code']=SCODE;
                    $res['message']='';
                }
			}else{
                $res['code']=UACODE;
                $res['message']="Invalid login credentials!";
            }
		}
		jsonData($res);
    }
}

//EOF