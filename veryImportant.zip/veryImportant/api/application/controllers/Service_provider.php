<?php

class Service_provider extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("service_provider_model", "service_provider");
    }

    function lists($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->service_provider->lists($all==='ALL');
        jsonData($res);
    }

    function save(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', "required", $this->req);
        $this->form_validation->set_rules('email', 'Email', "required|valid_email", $this->req);
        $this->form_validation->set_rules('address', 'Address', "required", $this->req);
        $this->form_validation->set_rules('country_id', 'Country', "required", $this->req);
        $this->form_validation->set_rules('phone1', 'Phone 1', "required|integer|max_length[10]", $this->req);
        $this->form_validation->set_rules('phone2', 'Phone 2', "integer|max_length[10]", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                $data=filterValue($post, ['id', 'name','email', 'address', 'street', 'town', 'city', 'country_id', 'phone1', 'phone2', 'status']);
                $service_provider_id=$this->service_provider->save($data);
                if($service_provider_id){
                    $res['code']=SCODE;
                    $res['message']='Service provider '.($id?'updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function delete(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->service_provider->delete($id)){
			$res['code']=SCODE;
            $res['message']="Service provider deleted successfully";
        }
		jsonData($res);
    }
}

// EOF