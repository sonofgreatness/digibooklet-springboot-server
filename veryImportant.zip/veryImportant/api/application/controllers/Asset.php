<?php
class Asset extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("asset_model", "asset");
    }

    function cats($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->cats($all==='ALL');
        jsonData($res);
    }

    function saveCat(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'category name', "required", $this->req);
        $this->form_validation->set_rules('type', 'Item type', "required", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                $data=filterValue($post, ['id', 'name', 'type', 'status']);
                $asset_cat_id=$this->asset->saveCat($data);
                if($asset_cat_id){
                    $res['code']=SCODE;
                    $res['message']='Asset '.($id?' category updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function deleteCat(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->deleteCat($id)){
			$res['code']=SCODE;
            $res['message']="Asset category deleted successfully";
        }
		jsonData($res);
    }

    function assetSubCats($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->assetSubCats($all==='ALL');
        jsonData($res);
    }

    function assetSubCatSave(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Sub category name', "required", $this->req);
        $this->form_validation->set_rules('cat_id', 'Asset category', "required", ['required'=>'Select a %s']);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                $data=filterValue($post, ['id', 'name', 'cat_id', 'status']);
                $asset_cat_id=$this->asset->assetSubCatSave($data);
                if($asset_cat_id){
                    $res['code']=SCODE;
                    $res['message']='Asset '.($id?' sub category updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function assetSubCatDelete(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->assetSubCatDelete($id)){
			$res['code']=SCODE;
            $res['message']="Asset sub category deleted successfully";
        }
		jsonData($res);
    }

    function infrastuctureSubCats(){
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->infrastuctureSubCats();
        jsonData($res);
    }

    function items($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->items($all==='ALL');
        jsonData($res);
    }

    function saveItem(){
        $this->checkAccess('manage_cmasters');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $cattype="";
        $subcats=0;
        if($post['asset_cat_id']){
            $cattype=$this->db->select("type")->get_where("assets_cats", ['id'=>$post['asset_cat_id']])->row("type");
            $subcats=(int)$this->db->select("count(1) n")->get_where("assets_sub_cats", ['cat_id'=>$post['asset_cat_id'], 'status'=>1])->row("n");
        }

        $this->load->library('form_validation');
        $this->form_validation->set_rules('asset_cat_id', 'Asset category', "required", $this->req);
        if($subcats){
            $this->form_validation->set_rules('asset_sub_cat_id', 'Asset sub category', "required", $this->req);
        }
        $this->form_validation->set_rules('name', 'Item Name', "required", $this->req);
        $this->form_validation->set_rules('description', 'Description', "required", $this->req);
        if($cattype==='Med/NonMed'){
            $this->form_validation->set_rules('manufacturer_id', 'Manufacturer', "required", $this->req);
            $this->form_validation->set_rules('model_id', 'Model', "required", ['required'=> 'Select a %s']);
            $this->form_validation->set_rules('service_period', 'Service period', "required|integer", $this->req);
            $this->form_validation->set_rules('service_period_type', 'Service period type', "required", $this->req);
        }
        $this->form_validation->set_rules('uom_id', 'UoM', "required", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try {
            if (@$this->form_validation->run() == FALSE) {
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            } else {
                $data=filterValue($post, ['id', 'name', 'model_id', 'description', 'asset_cat_id', 'asset_sub_cat_id', 'manufacturer_id', 'service_provider_id', 'vendor_id', 'service_period', 'service_period_type', 'uom_id', 'status']);
                if(!$data['asset_sub_cat_id']){
                    $data['asset_sub_cat_id']=null;
                }
                if(!$data['manufacturer_id']){
                    $data['manufacturer_id']=null;
                }
                if(!$data['service_provider_id']){
                    $data['service_provider_id']=null;
                }
                if(!$data['vendor_id']){
                    $data['vendor_id']=null;
                }
                if(!$data['model_id']){
                    $data['model_id']=null;
                }

                if($this->asset->saveItem($data)){
                    $res['code'] = SCODE;
                    $res['message'] = 'Item ' . ($id ? 'updated' : 'added') . ' successfully';
                }
            }
        } catch (Exception $e) {
            $res['message'] = $e->getMessage();
        }
        jsonData($res);
    }

    function deleteItem(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->deleteItem($id)){
			$res['code']=SCODE;
            $res['message']="Item deleted successfully";
        }
		jsonData($res);
    }

    function uoms($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->uoms($all==='ALL');
        jsonData($res);
    }

    function saveUom(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', "required", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                $data=filterValue($post, ['id', 'name', 'status']);
                $asset_cat_id=$this->asset->saveUom($data);
                if($asset_cat_id){
                    $res['code']=SCODE;
                    $res['message']='UOM '.($id?' category updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function deleteUom(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->deleteUom($id)){
			$res['code']=SCODE;
            $res['message']="UOM category deleted successfully";
        }
		jsonData($res);
    }

    function models($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_cmasters');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->models($all==='ALL');
        jsonData($res);
    }

    function saveModel(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', "required", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                $data=filterValue($post, ['id', 'name', 'status']);
                $asset_cat_id=$this->asset->saveModel($data);
                if($asset_cat_id){
                    $res['code']=SCODE;
                    $res['message']='Model '.($id?' category updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function deleteModel(){
        $this->checkAccess('manage_cmasters');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->deleteModel($id)){
			$res['code']=SCODE;
            $res['message']="Model category deleted successfully";
        }
		jsonData($res);
    }

    function allFunctionalStatus(){
        $res=['code'=>SCODE, 'message'=>''];
        $res['data']=$this->asset->allFunctionalStatus();
        jsonData($res);
    }

    function lists($all=''){
        if($all!=='ALL'){
            $this->checkAccess('view_asset');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->asset->lists($all==='ALL');
        jsonData($res);
    }

    function save(){
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);
        if(!$id){
            $this->checkAccess('add_asset');
        }else{
            $this->checkAccess('edit_asset');
        }

        if($id){
            $dtl=$this->db->get_where("assets", ['id'=>$id])->row_array();
            $client_id=$dtl['client_id'];
        }else{
            $client_id=$post['client_id'];
        }

        $cattype="";
        if($post['item_id']){
            $cat_id=$this->db->select("asset_cat_id")->get_where("items", ['id'=>$post['item_id']])->row("asset_cat_id");
            $cattype=$this->db->select("type")->get_where("assets_cats", ['id'=>$cat_id])->row("type");
            if($cattype!='Med/NonMed'){
                /* if($this->db->get_where("assets", ['item_id'=>$post['item_id'], 'client_id'=>$client_id])->row_array()){
                    $res['message']="This item is already added!";
                    jsonData($res);
                } */
            }
        }

        $this->load->library('form_validation');
        if(!$id){
            if(IS_NATIONAL_CLIENT){
                $this->form_validation->set_rules('client_id', 'Facility', "required", $this->req);
            }else{
                $post['client_id']=CLIENT_ID;
            }
            $this->form_validation->set_rules('item_id', 'Item', "required", $this->req);
        }

        if($cattype==='Med/NonMed'){
            //$this->form_validation->set_rules('station_point_ids[]', 'Station point', "required", $this->req);
            $this->form_validation->set_rules('serial_no', 'Serial number', "required|is_unique[assets.serial_no.client_id='$client_id' AND id!='$id']", $this->req);
            $this->form_validation->set_rules('procurement_date', 'Procurement date', "required", $this->req);
            //$this->form_validation->set_rules('installation_date', 'Installation date', "required", $this->req);
            $this->form_validation->set_rules('functional_status', 'Functional status', "required", $this->req);
            $post['qty']=1;
        }else{
            if(!$id){
                $this->form_validation->set_rules('qty', 'Quantity', "required|numeric", $this->req);
            }
            unset($post['station_point_ids']);
        }

        $this->form_validation->set_rules('cost', 'Cost', "numeric", $this->req);

        try {
            if (@$this->form_validation->run() == FALSE) {
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            } else {
                if(!$id && (float)$post['qty']<=0){
                    throw new Exception("Quantity must be greater than zero(0)");
                }
                /* if(!is_array($post['station_point_ids']) || count($post['station_point_ids'])<=0){
                    throw new Exception("Station point required");
                } */

                if($cattype==='Med/NonMed'){
                    $post['procurement_date']=toDateFormat($post['procurement_date']);
                    $post['installation_date']=$post['installation_date']?toDateFormat($post['installation_date']):null;
                }else{
                    unset($post['installation_date'], $post['procurement_date'], $post['functional_status']);
                }
                $f=['id', 'item_id', 'client_id', 'station_point_ids', 'serial_no', 'installation_date', 'procurement_date', 'functional_status', 'qty', 'cost'];
                $data=filterValue($post, $f);
                if($id){
                    unset($data['item_id'], $data['client_id'], $data['qty']);
                }else{
                    $data['added_by_client_id']=CLIENT_ID;
                }
                $data['isdonated']=intval($post['isdonated'])?1:0;
                if($this->asset->save($data, $cattype)){
                    $res['code']=SCODE;
                    $res['message']=$cattype.' Asset '.($id?'updated':'added').' successfully';
                }
            }
        } catch (Exception $e) {
            $res['message'] = $e->getMessage();
        }
        jsonData($res);
    }

    function delete(){
        $this->checkAccess('delete_asset');
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->asset->delete($id)){
			$res['code']=SCODE;
            $res['message']="Asset deleted successfully";
        }
		jsonData($res);
    }
}

// EOF