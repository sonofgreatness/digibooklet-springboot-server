<?php
class Transfer_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }

    function transferInOuts($all=false, $inout='Out'){
        $qs=trimArray($this->input->get());
        $client_id=CLIENT_ID;

        if($qs['ids']){
            $this->db->where_in("st.id", explode(",", $qs['ids']));
        }

        if(IS_NATIONAL_CLIENT){
            if($qs['client_id']){
                $client_id=$qs['client_id'];
            }
        }

        if($inout==='Out'){
            $this->db->where("a.client_id", $client_id);
            if(strlen($qs['is_approved'])){
                $this->db->where("st.is_approved", $qs['is_approved']);
            }
        }else{
            $this->db->where(["st.transfer_to"=>$client_id, "st.is_approved"=>1]);
        }

        if($qs['cat_type']){
            $this->db->where("ac.type", $qs['cat_type']);
        }
        
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("i.name", $qs['k']);
            $this->db->group_end();
        }
        if($qs['item_id']){
            $this->db->where("i.id", $qs['item_id']);
        }
        if($qs['status']){
            $this->db->where("st.status", $qs['status']);
        }
        if($qs['from_date']){
            $this->db->where("st.transfer_date>=", toDate($qs['from_date'], '', 'Y-m-d'));
        }
        if($qs['to_date']){
            $this->db->where("st.transfer_date<=", toDate($qs['to_date'], '', 'Y-m-d 23:59:59'));
        }
        

        $f="st.id, st.qty, st.transfer_date, st.status trstatus, st.asset_id, st.is_approved, st.approved_on, st.reason, u1.name approved_by_name,
            a.item_id, a.code asset_code, a.serial_no, c.business_name transfer_from_name, c1.business_name transfer_to_name, i.name item, md.name model, 
            i.asset_cat_id, i.asset_sub_cat_id, ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacture";
        $this->db->select($f)
        ->from("stock_transfers st")
        ->join("assets a", "a.id=st.asset_id")
        ->join("clients c", "c.id=a.client_id")
        ->join("clients c1", "c1.id=st.transfer_to")
        ->join("items i", "i.id=a.item_id")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("users u1", "u1.id=st.approved_by", "LEFT")
        ->order_by("st.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['is_approved']=(int)$r['is_approved'];
        }
        return $rs;
    }

    function transferAsset($assets, $client_id, $is_approved, $reason=''){
        $reason=$reason?$reason:'';
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
        $transfer_id='';
		try{
            foreach($assets as $r){
                $d=[
                    'asset_id'=>$r['id'],
                    'transfer_to'=>$client_id,
                    'transfer_date'=>currentDT(),
                    'qty'=>$r['qty'],
                    'created'=>currentDT(),
                    'created_by'=>USER_ID,
                    'reason'=>$reason
                ];
                if($is_approved){
                    $d['is_approved']=1;
                    $d['approved_by']=USER_ID;
                    $d['approved_on']=currentDT();
                    $d['status']='Dispatched';
                }
                $transfer_id=$this->dba->save("stock_transfers", $d);

                if($is_approved){
                    $d=[
                        'asset_id'=>$r['id'],
                        'transfer_id'=>$transfer_id,
                        'action_id'=>3,
                        'qty'=>$r['qty']*-1,
                        'txn_date'=>currentDT(),
                        'created'=>currentDT(),
                        'created_by'=>USER_ID
                    ];
                    $this->db->insert("stock_transactions", $d);
                }
            }
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $transfer_id;
        }
    }

    function receiveTransfer($dtl){
        $transfer_id=$dtl['id'];

        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $adtl=$this->db->get_where("assets", ['id'=>$dtl['asset_id']])->row_array();
            $cat_id=$this->db->select("asset_cat_id")->get_where("items", ['id'=>$adtl['item_id']])->row("asset_cat_id");
            $cattype=$this->db->select("type")->get_where("assets_cats", ['id'=>$cat_id])->row("type");

            $asset_id=0;
            if($cattype!=='Med/NonMed'){
                $asset_id=$this->db->get_where("assets", ['item_id'=>$adtl['item_id'], 'client_id'=>CLIENT_ID])->row("id");
            }

            if(!$asset_id){
                $data=[
                    'client_id'=>CLIENT_ID,
                    'item_id'=>$adtl['item_id'],
                    'code'=>$adtl['code'],
                    'serial_no'=>$adtl['serial_no'],
                    'cost'=>$adtl['cost'],
                    'functional_status'=>$cattype!=='Med/NonMed'?NULL:1,
                    'added_by_client_id'=>CLIENT_ID
                ];

                $asset_id=$this->dba->save("assets", $data);
            }

            $d=[
                'asset_id'=>$asset_id,
                'transfer_id'=>$transfer_id,
                'action_id'=>2,
                'qty'=>$dtl['qty'],
                'txn_date'=>currentDT(),
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->dba->save("stock_transactions", $d);


            $d=['id'=>$transfer_id, 'status'=>'Received', 'action_on'=>currentDT(), 'action_by'=>USER_ID];
            $this->dba->save("stock_transfers", $d);

		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function cancelTransfer($dtl, $adtl){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            if($dtl['is_approved']){
                $d=[
                    'asset_id'=>$adtl['id'],
                    'transfer_id'=>$dtl['id'],
                    'action_id'=>9,
                    'qty'=>$dtl['qty'],
                    'txn_date'=>currentDT(),
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->dba->save("stock_transactions", $d);
            }


            $d=['id'=>$dtl['id'], 'status'=>'Cancelled', 'action_on'=>currentDT(), 'action_by'=>USER_ID];
            $this->dba->save("stock_transfers", $d);

		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function approveTransfer($dtl, $adtl){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'id'=>$dtl['id'],
                'is_approved'=>1,
                'approved_by'=>USER_ID,
                'approved_on'=>currentDT(),
                'status'=>'Dispatched'
            ];
            $this->dba->save("stock_transfers", $d);

            $d=[
                'asset_id'=>$adtl['id'],
                'transfer_id'=>$dtl['id'],
                'action_id'=>3,
                'qty'=>$dtl['qty']*-1,
                'txn_date'=>currentDT(),
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("stock_transactions", $d);

		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }
}

// EOF