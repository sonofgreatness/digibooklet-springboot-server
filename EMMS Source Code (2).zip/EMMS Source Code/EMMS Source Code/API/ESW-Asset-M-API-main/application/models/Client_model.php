<?php 
class Client_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function lists($all=false){
        $qs=trimArray($this->input->get());
        if(CLIENT_ID && $all && $qs['include_me']!=='Y'){
            $this->db->where("c.id!=", CLIENT_ID);
        }
        if(strlen($qs['status'])){
            $this->db->where("c.status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("c.business_name", $qs['k'])->or_like("c.site_code", $qs['k'])->or_like("c.fac_code", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("c.*, f.file_name logo, u.id user_id, u.name, u.email, u.mobile, u.username")
        ->from("clients c")
        ->join("users u", "u.client_id=c.id AND u.role_id=2")
        ->join("files f", "f.id=c.logo_file_id", "LEFT")
        ->order_by("c.id", "ASC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
            $r['is_national']=(int)$r['is_national'];
            $r['is_me']=(int)$r['id']===(int)CLIENT_ID?1:0;
            $r['logo_url']=$r['logo']?UP_URL.'files/'.$r['logo']:'';
            if(!$all){
                $r['station_points_count']=(int)$this->db->select("count(1) n")->get_where("clients_station_points", ['client_id'=>$r['id']])->row("n");
            }

            unset($r['logo_file_id']);
        }
        return $rs;
    }

    function save($data, $udata){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $client_id=$this->dba->save("clients", $data);
            if(!$udata['id']){
                $udata['client_id']=$client_id;
            }
            $this->dba->save("users", $udata);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $client_id;
        }
    }

    function detail($id=CLIENT_ID){
        $dtl=$this->db->select("c.*, f.file_name logo")
        ->from("clients c")
        ->join("files f", "f.id=c.logo_file_id", "LEFT")
        ->where("c.id", $id)
        ->get()
        ->row_array();

        $dtl['status']=(int)$dtl['status'];
        $dtl['logo_url']=$dtl['logo']?UP_URL.'files/'.$dtl['logo']:'';
        return $dtl;
    }

    function delete($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("clients", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function stationPointLists($all=false){
        $qs=trimArray($this->input->get());
        $client_id=(int)$qs['client_id'];
        if($client_id){
            $this->db->join("clients_station_points cp", "cp.station_id=sp.id");
            $this->db->where("cp.client_id", $client_id);
        }
        if(strlen($qs['status'])){
            $this->db->where("sp.status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("sp.name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("sp.id, sp.name, sp.status, sp.asset_cat_ids")
        ->from("station_points sp")
        ->order_by("name");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
            $r['client_ids']=[];
            $r['is_my']=0;
            $client_ids=$this->db->select("client_id")->get_where("clients_station_points", ['station_id'=>$r['id']])->result_array();
            foreach($client_ids as $c){
                $r['client_ids'][]=$c['client_id'];
                if((int)$c['client_id']===(int)CLIENT_ID){
                    $r['is_my']=1;
                }
            }
        }
        return $rs;
    }

    function saveStationPoint($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $station_point_id=$this->dba->save("station_points", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $station_point_id;
        }
    }

    function deleteStationPoint($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("station_points", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }
}

//End of file