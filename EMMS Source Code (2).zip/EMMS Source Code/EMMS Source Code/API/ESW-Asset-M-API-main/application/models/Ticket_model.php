<?php
class Ticket_model extends CI_Model{
    function __construct() {
        parent::__construct();
    }

    function lists($all=false, $isAllAccess=false){
        $qs=trimArray($this->input->get());
        if($qs['ids']){
            $this->db->where_in("t.id", explode(",", $qs['ids']));
        }

        if(IS_NATIONAL_CLIENT){
            if($qs['client_id']){
                $this->db->where("t.client_id", $qs['client_id']);
            }else{
                $this->db->where("t.client_id", CLIENT_ID);
            }
        }else{
            $this->db->where("t.client_id", CLIENT_ID);
        }

        if(!IS_CLIENT_ADMIN && !$isAllAccess && !$qs['created_by'] && !$qs['assigned_to']){
            $this->db->group_start();
                $this->db->where("t.created_by", USER_ID)->or_where("t.assigned_to", USER_ID);
            $this->db->group_end();
        }

        if($qs['type']){
            $this->db->where("t.type", $qs['type']);
        }

        if($qs['status_id']){
            $this->db->where("t.status_id", $qs['status_id']);
        }

        if($qs['created_by']){
            $this->db->where("t.created_by", $qs['created_by']);
        }
        if($qs['assigned_to']){
            $this->db->where("t.assigned_to", $qs['assigned_to']);
        }

        if($qs['from_date']){
            $this->db->where("t.created>=", toDate($qs['from_date'], '', 'Y-m-d'));
        }
        if($qs['to_date']){
            $this->db->where("t.created<=", toDate($qs['to_date'], '', 'Y-m-d 23:59:59'));
        }

        if($qs['k']){
            $this->db->group_start();
                $this->db->like("t.ticket_no", $qs['k']);
            $this->db->group_end();
        }
        if($qs['item_id']){
            $this->db->where("i.id", $qs['item_id']);
        }
        
        $f="t.*, a.serial_no, ts.name status_name, sp.name station_point, c.business_name client, 
            u.name created_by_name, r.title created_by_role, u1.name assigned_to_name, r1.title assigned_to_role, 
            i.name item, ac.name cat, m.name manufacturer, md.name model, sc1.name infrastucture_type";
        $this->db->select($f)
        ->from("tickets t")
        ->join("clients c", "c.id=t.client_id")
        ->join("mm_ticket_status ts", "ts.id=t.status_id")
        ->join("station_points sp", "sp.id=t.station_id")
        ->join("users u", "u.id=t.created_by")
        ->join("roles r", "r.id=u.role_id")
        ->join("users u1", "u1.id=t.assigned_to", "LEFT")
        ->join("roles r1", "r1.id=u1.role_id", "LEFT")
        ->join("assets a", "a.id=t.asset_id", "LEFT")
        ->join("items i", "i.id=a.item_id", "LEFT")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("assets_sub_cats sc1", "sc1.id=t.asset_sub_cat_id", "LEFT")
        ->order_by("t.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status_id']=(int)$r['status_id'];
            $r['item_full_name']=$r['item'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }

            $r['edit_allowed']=1;
            if($r['client_id']!=CLIENT_ID || $r['status_id']>1){
                $r['edit_allowed']=0;
            }
        }
        return $rs;
    }

    function save($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $id=$this->dba->save("tickets", $data);
            if(!$data['id']){
                $ticket_no='JC-'.zeroFormatNo($id, 3); 
                $this->dba->save("tickets", ['id'=>$id, 'ticket_no'=>$ticket_no]);
            }
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function detail($id){
        $f="t.*, a.serial_no, ts.name status_name, sp.name station_point, c.business_name client, 
            u.name created_by_name, r.title created_by_role, u1.name assigned_to_name, r1.title assigned_to_role, 
            i.name item, ac.name cat, m.name manufacturer, md.name model, sc1.name infrastucture_type";

        $rs=$this->db->select($f)
        ->from("tickets t")
        ->join("clients c", "c.id=t.client_id")
        ->join("mm_ticket_status ts", "ts.id=t.status_id")
        ->join("station_points sp", "sp.id=t.station_id")
        ->join("users u", "u.id=t.created_by")
        ->join("roles r", "r.id=u.role_id")
        ->join("users u1", "u1.id=t.assigned_to", "LEFT")
        ->join("roles r1", "r1.id=u1.role_id", "LEFT")
        ->join("assets a", "a.id=t.asset_id", "LEFT")
        ->join("items i", "i.id=a.item_id", "LEFT")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("assets_sub_cats sc1", "sc1.id=t.asset_sub_cat_id", "LEFT")
        ->where("t.id", $id)
        ->get()
        ->row_array();
        
        if($rs){
            $rs['status_id']=(int)$rs['status_id'];
            $rs['item_full_name']=$rs['item'];
            if($rs['model']){
                $rs['item_full_name'].=' - '.$rs['model'];
            }
            if($rs['manufacturer']){
                $rs['item_full_name'].=' - '.$rs['manufacturer'];
            }

            $rs['assignedto_change_allowed']=1;
            if($rs['client_id']!=CLIENT_ID){
                $rs['assignedto_change_allowed']=0;
            }

            $rs['is_assigned_to_me']=$rs['assigned_to']===USER_ID?1:0;

            $rs['comments']=$this->comments($id);
        }else{
            $rs=(Object)[];
        }
        return $rs;
    }

    function assignedUsers(){
        $rs=$this->db->select("u.id, u.name, r.title role, u.client_id")
        ->from("tickets t")
        ->join("users u", "u.id=t.assigned_to")
        ->join("roles r", "r.id=u.role_id")
        ->group_by("t.assigned_to")
        ->order_by("u.name")
        ->get()
        ->result_array();
        return $rs;
    }

    function comments($ticket_id){
        $f="tc.id, tc.type, tc.comment, tc.is_system_comment, tc.created, f.file_name, u.name created_by_name";
        $rs=$this->db->select($f)
        ->from("ticket_comments tc")
        ->join("users u", "tc.created_by=u.id")
        ->join("files f", "tc.file_id=f.id", "LEFT")
        ->where("tc.ticket_id", $ticket_id)
        ->order_by("tc.id")
        ->get()
        ->result_array();

        foreach($rs as &$r){
            $r['is_system_comment']=(int)$r['is_system_comment'];
            $r['image_url']=$r['file_name']?(UP_URL.'files/'.$r['file_name']):'';
        }

        return $rs;
    }

    function assign($id, $user_id){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $data=[
                'id'=>$id,
                'assigned_to'=>$user_id
            ];
            $this->dba->save("tickets", $data);

            $uname=$this->db->select("name")->get_where("users", ['id'=>$user_id])->row("name");
            $d=[
                'ticket_id'=>$id,
                'comment'=>"Job card assigned to $uname",
                'is_system_comment'=>1,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function addComment($id, $comment){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'ticket_id'=>$id,
                'comment'=>$comment,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function changeStatus($id, $status_id){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $data=[
                'id'=>$id,
                'status_id'=>$status_id
            ];
            $this->dba->save("tickets", $data);

            $statusname=$this->db->select("name")->get_where("mm_ticket_status", ['id'=>$status_id])->row("name");
            $d=[
                'ticket_id'=>$id,
                'comment'=>"Job card status changed to: $statusname",
                'is_system_comment'=>1,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function markAsRepairInScope($id){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'ticket_id'=>$id,
                'comment'=>"Repair In Scope",
                'is_system_comment'=>1,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function markAsRepairNotInScope($id){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'ticket_id'=>$id,
                'comment'=>"Repair Not In Scope",
                'is_system_comment'=>1,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function uploadCommentPhoto($id, $file_id){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'ticket_id'=>$id,
                'comment'=>"PhotoUploaded",
                'file_id'=>$file_id,
                'type'=>'Image',
                'is_system_comment'=>1,
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("ticket_comments", $d);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }
}

// EOF