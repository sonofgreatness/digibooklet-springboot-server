<?php
class Cron extends CI_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("cron_model", "cron");
        $this->load->model("common_model", "common");

        $smtp=$this->common->smtp_dtl();
        define('SMTP_HOST',                 $smtp['host']);
        define('SMTP_USER',                 $smtp['user_name']);
        define('SMTP_PASS',                 $smtp['password']);
        define('SMTP_PORT',                 $smtp['port']);
        define('SMTP_SENDER_NAME',          $smtp['sender_name']);
        define('SMTP_SENDER_EMAIL',         $smtp['sender_email']);
        define('SMTP_REPLYTO',              $smtp['reply_to']);
    }

    function serviceNotification(){
        $this->cron->serviceNotification();
    }
}

// EOF