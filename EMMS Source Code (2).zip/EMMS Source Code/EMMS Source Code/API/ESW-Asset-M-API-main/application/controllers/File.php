<?php
class File extends MY_Controller {
    function __construct() {
        parent::__construct();
    }

    function upload(){
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $client_id=(int)$this->input->post("client_id");

        $dir=UP_PATH.'files/';
        if(!is_dir($dir)){
            mkdir($dir, 0777, true);
        }

        
        $this->load->library('upload');
        $config=[
            'upload_path'=>$dir, 
            'allowed_types'=>'gif|jpg|jpeg|png|pdf|doc|xls|ppt|docx|xlsx|pptx|mp4|webp|mkv|avi|mov', 
            'max_size'=>'1024000',
            'max_filename'=>80,
            'file_ext_tolower'=>true,
            'file_name'=>USER_ID.time()
        ];
        $this->upload->initialize($config);
        if($this->upload->do_upload('file')){
            $data['file_name']=$this->upload->data('file_name');
            $data['file_ext']=$this->upload->data('file_ext');
            $data['file_size']=$this->upload->data('file_size');
            $data['is_image']=$this->upload->data('is_image');
            $data['is_pdf']=$post['file_ext']==='.pdf'?1:0;

            $data['client_id']=$client_id?$client_id:CLIENT_ID;
            if($id=$this->dba->save("files", $data)){
                $res['file']=$data;
                $res['code']=SCODE;
                $res['message']='';
                $res['file_id']=(int)$id;
                $res['file_url']=UP_URL.'files/'.$data['file_name'];
            }
        }else{
            $res['message']=strip_tags($this->upload->display_errors());
            $res['file']=$_FILES;
        }

        jsonData($res);
    }
}

//EOF