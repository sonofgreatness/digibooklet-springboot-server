<?php
class Transfer extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("transfer_model", "transfer");
        $this->load->model("asset_model", "asset");
    }

    function transferAsset(){
        $this->checkAccess('transfer_asset');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $isApproveTransferAccess=$this->isAccess('approve_transfer_asset');

        if(!$post['transfer_to']){
            $res['message']="Facility (Transfer To) required!";
            jsonData($res);
        }

        if(!$post['asset_ids'] || !is_array($post['asset_ids']) || count($post['asset_ids'])<=0){
            $res['message']="You have not selected any asset item!";
            jsonData($res);
        }

        foreach($post['asset_ids'] as &$r){
            $dtl=$this->db->get_where("assets", ['id'=>$r['id']])->row_array();
            if(!$dtl){
                $res['message']="Invalid request data!";
                jsonData($res);
            }
            if($dtl['client_id']!==CLIENT_ID && !IS_NATIONAL_CLIENT){
                $res['message']="You can transfer only your assets!";
                jsonData($res);
            }

            if(!$r['qty']){
                $res['message']="Quantity required!";
                jsonData($res);
            }
            if(!is_numeric($r['qty'])){
                $res['message']="Quantity must be numeric!";
                jsonData($res);
            }

            $r['qty']=(float)$r['qty'];

            if($r['qty']<=0){
                $res['message']="Quantity must be greater than Zero(0)!";
                jsonData($res);
            }

            if($r['qty']>(float)$dtl['stock']){
                $res['message']="Quantity can not be greater than available stock!";
                jsonData($res);
            }

            $item_dtl=$this->asset->itemDetail($dtl['item_id']);
            $r['cat']=$item_dtl['cat'];
            $r['subcat']=$item_dtl['subcat'];
            $r['item_full_name']=$item_dtl['item_full_name'];
        }

        if($post['approve']==='1' && !$isApproveTransferAccess){
            $res['message']="You don't have right to approve transfer!";
            jsonData($res);
        }

        if($transfer_id=$this->transfer->transferAsset($post['asset_ids'], $post['transfer_to'], $post['approve']==='1', $post['reason'])){
            $this->common->sendStockTransferredNoti($post['asset_ids'], $dtl['client_id'], $post['transfer_to'], $post['approve']==='1', $transfer_id);

            $res['code']=SCODE;
            $res['message']='Stock transferred successfully';
        }

        jsonData($res);
    }

    function transferOuts($all=''){
        $this->checkAccess('view_transfer_out');
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->transfer->transferInOuts($all==='ALL', 'Out');
        jsonData($res);
    }

    function transferIns($all=''){
        $this->checkAccess('view_transfer_in');
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->transfer->transferInOuts($all==='ALL', 'In');
        jsonData($res);
    }

    function receiveTransfer(){
        $this->checkAccess('receive_stock');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        if(!$post['transfer_id']){
            $res['message']="Transfer ID required!";
            jsonData($res);
        }

        $dtl=$this->db->get_where("stock_transfers", ['id'=>$post['transfer_id']])->row_array();
        if(!$dtl){
            $res['message']="Invalid data!";
            jsonData($res);
        }
        if($dtl['transfer_to']!==CLIENT_ID){
            //$res['message']="Invalid data!";
            //jsonData($res);
        }
        if($dtl['status']!=='Dispatched'){
            $res['message']="This transfer is already {$dtl['status']}!";
            jsonData($res);
        }

        if($this->transfer->receiveTransfer($dtl)){
            $adtl=$this->db->get_where("assets", ['id'=>$dtl['asset_id']])->row_array();
            $idtl=$this->asset->itemDetail($adtl['item_id']);
            $items=[
                [
                    'cat'=>$idtl['cat'],
                    'subcat'=>$idtl['subcat'],
                    'item_full_name'=>$idtl['item_full_name'],
                    'qty'=>$dtl['qty'],
                ]
            ];
            $this->common->sendStockReceivedNoti($items, $adtl['client_id'], $dtl['transfer_to'], $post['transfer_id']);

            $res['code']=SCODE;
            $res['message']='Stock received successfully';
        }

        jsonData($res);
    }

    function cancelTransfer(){
        //$this->checkAccess('receive_stock');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        if(!$post['transfer_id']){
            $res['message']="Transfer ID required!";
            jsonData($res);
        }

        $dtl=$this->db->get_where("stock_transfers", ['id'=>$post['transfer_id']])->row_array();
        if(!$dtl){
            $res['message']="Invalid data!";
            jsonData($res);
        }
        $adtl=$this->db->get_where("assets", ['id'=>$dtl['asset_id']])->row_array();

        if($dtl['transfer_to']!==CLIENT_ID && $adtl['client_id']!==CLIENT_ID && !IS_NATIONAL_CLIENT){
            $res['message']="This entity does not belog to you!";
            jsonData($res);
        }
        if($dtl['status']==='Received' || $dtl['status']==='Cancelled'){
            $res['message']="This transfer is already {$dtl['status']}!";
            jsonData($res);
        }

        if($this->transfer->cancelTransfer($dtl, $adtl)){
            $idtl=$this->asset->itemDetail($adtl['item_id']);
            $items=[
                [
                    'cat'=>$idtl['cat'],
                    'subcat'=>$idtl['subcat'],
                    'item_full_name'=>$idtl['item_full_name'],
                    'qty'=>$dtl['qty'],
                ]
            ];
            $this->common->sendStockReceiveCancelledNoti($items, $adtl['client_id'], $dtl['transfer_to'], $post['transfer_id']);

            $res['code']=SCODE;
            $res['message']='Stock transfer cancelled successfully';
        }

        jsonData($res);
    }

    function approveTransfer(){
        $this->checkAccess('approve_transfer_asset');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());

        if(!$post['transfer_id']){
            $res['message']="Transfer ID required!";
            jsonData($res);
        }

        $dtl=$this->db->get_where("stock_transfers", ['id'=>$post['transfer_id']])->row_array();
        if(!$dtl){
            $res['message']="Invalid data!";
            jsonData($res);
        }
        $adtl=$this->db->get_where("assets", ['id'=>$dtl['asset_id']])->row_array();

        if($adtl['client_id']!==CLIENT_ID && !IS_NATIONAL_CLIENT){
            $res['message']="This entity does not belog to you!";
            jsonData($res);
        }
        if($dtl['status']==='Received' || $dtl['status']==='Cancelled'){
            $res['message']="This transfer is already {$dtl['status']}!";
            jsonData($res);
        }

        if($this->transfer->approveTransfer($dtl, $adtl)){
            $idtl=$this->asset->itemDetail($adtl['item_id']);
            $items=[
                [
                    'cat'=>$idtl['cat'],
                    'subcat'=>$idtl['subcat'],
                    'item_full_name'=>$idtl['item_full_name'],
                    'qty'=>$dtl['qty'],
                ]
            ];
            $this->common->sendStockTransferredNoti($items, $adtl['client_id'], $dtl['transfer_to'], true, $post['transfer_id']);

            $res['code']=SCODE;
            $res['message']='Stock transfer approved successfully';
        }

        jsonData($res);
    }
}

// EOF