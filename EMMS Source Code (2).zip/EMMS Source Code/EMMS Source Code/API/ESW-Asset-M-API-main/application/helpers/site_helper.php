<?php
define('PROTOCOL',          is_https()?'https://':'http://');
define('URL', 				str_replace('http://', PROTOCOL, base_url()));
define('UP_URL', 			URL.'uploads/');
define('UP_PATH', 			FCPATH.'uploads'.DIRECTORY_SEPARATOR);

//EOF