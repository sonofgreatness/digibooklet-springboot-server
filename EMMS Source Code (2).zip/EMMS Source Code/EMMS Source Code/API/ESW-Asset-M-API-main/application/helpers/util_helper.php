<?php
/** Functions **/
function jsonData($res, $die=true){
	header('Content-Type: application/json');
	$res=$res?$res:array();
	http_response_code($res['code']);
    echo json_encode($res, JSON_PARTIAL_OUTPUT_ON_ERROR);
    if($die){
        die;
    }
}

function fno($a){
	return floatval($a.'');
}

function createPdf($html_data, $filename="", $action='D', $page_type="A4") {
    error_reporting(0);
	ini_set('memory_limit', '1024M');
	set_time_limit(0);
	require_once 'mpdf/mpdf.php';
	$mypdf = new mPDF('utf-8', $page_type);
	$mypdf->packTableData = true;
	$mypdf->WriteHTML($html_data);
	$mypdf->Output($filename.".pdf", $action);
}

function pr($data) {
	echo '<pre>';print_r($data);echo '</pre>';
}

function h($data) {
	return html_escape($data);
}

function compressHtml($buffer) {
     $search = array(
        '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
        '/[^\S ]+\</s',     // strip whitespaces before tags, except space
        '/(\s)+/s',         // shorten multiple whitespace sequences
        '/<!--(.|\s)*?-->/' // Remove HTML comments
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );
    $buffer = preg_replace($search, $replace, $buffer);
    return $buffer;
}

function encryptPassword($txt) {
	return hash_hmac('sha256', $txt, SALT_KEY);
}

function md5enc($str, $extraSalt=''){
    return md5($str.SALT_KEY.$extraSalt);
}

function zeroFormatNo($no, $n=5){
	return str_pad($no, $n, '0', STR_PAD_LEFT);
}

function calcAge($birth_date){
    $dt2=date('Y-m-d');
    $datetime1 = new DateTime($birth_date);
    $datetime2 = new DateTime($dt2);
    $interval = $datetime1->diff($datetime2);
    $y = $interval->format('%y');
    $m = $interval->format('%m');
    $d = $interval->format('%d');

    $age = '';
    if ($y)
        $age .= "$y Year" . ($y > 1 ? 's ' : ' ');
    if ($m)
        $age .= "$m Month" . ($m > 1 ? 's' : '');

    if(!$age){
        $age="0 Month";
    }
    return [$y, $m, $d, $age];
}

function numToWordsKwd($n){
	/** Invented and written by Satyendra :) **/
	$n=trim($n);
	if(!strlen($n)){
		return;
	}
	if($n===0 or $n==='0'){
		return 'Zero';
	}
	
	$n=explode(".", $n);
	$numbers=array();
	$numbers[]=intval($n[0]);
	$point=isset($n[1])?intval(substr($n[1].'00', 0,3)):0;
	if($point){
		$numbers[]=$point;
	}
	$words=array('0' => '', '1' => 'one', '2' => 'two', '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six', '7' => 'seven', '8' => 'eight', '9' => 'nine', '10' => 'ten', '11' => 'eleven', '12' => 'twelve', '13' => 'thirteen', '14' => 'fourteen', '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen', '18' => 'eighteen', '19' => 'nineteen', '20' => 'twenty', '30' => 'thirty', '40' => 'forty', '50' => 'fifty','60' => 'sixty', '70' => 'seventy', '80' => 'eighty', '90' => 'ninety');
	
	$res=array();
	foreach($numbers as $number){
		$str1=array();
		$seg=array_chunk(array_reverse(str_split($number)), 3);
		$num_arr=array();
		foreach($seg as $r){
			$num_arr[]=implode('', array_reverse($r));
		}
		
		foreach($num_arr as $i=>$v){
			$num=intval($v);
			if($num<20){
				$str1[$i][]=$words[$num];
			}else{
				$d=1;
				while($num>0){
					if($d<=10){
						if($num%10){$str1[$i][]=$words[($num%10)*$d];}
					}else if($d==100){
						$str1[$i][]=$words[$num%10].' hundred';
					}
					$num=intval($num/10);
					$d=$d*10;
				}
			}
			$rev=array_reverse($str1[$i]);
			
			if(intval($v)>=20){
				$last2=intval(substr($number, -2, 2));
				if($last2<20 and $last2>10){
					unset($rev[count($rev)-1]);
					unset($rev[count($rev)-1]);
					$rev[]=$words[$last2];
				}
			}
			
			$str1[$i]=trim(implode(' ', $rev)).($i>1?' million':($i>0?' thousand':''));
		}
		$res[]=trim(implode(' ', array_reverse($str1)));
	}
	
	$rs=trim(ucfirst($res[0]));
	if(strlen($rs)){
		$rs=$rs.' KWD';
	}
	if(isset($res[1])){
		if(strlen($rs)){
			$rs=$rs.' and '.trim($res[1]).' FILS';
		}else{
			$rs=trim($res[1]).' FILS';
		}
	}
	return $rs;
}

function months($m=''){
    $m=(int)$m;
	$rs=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	if($m){
		return $rs[$m-1];
    }
    $res=[];
    foreach($rs as $k=>$v){
        $res[zero_format_no($k+1, 2)]=$v;
    }
	return $res;
}

function downloadCsv($data, $h, $keys, $filename='export'){
	$filename=$filename.".csv";
	header('Content-Type: application/csv; charset=UTF-8');
	header('Content-Disposition: attachment; filename="'.$filename.'";');
	$f=fopen('php://output', 'w');
	if($data){
		fputcsv($f, $h);
		foreach($data as $i=>$r){
			$res=[];
			foreach($keys as $k){
				$res[]=$r[$k];
			}
			fputcsv($f, $res);
		}
		fclose($f);
    }
    die;
}

function days(){
    return ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', "FRIDAY", 'SATURDAY'];
}

function barcodeImageData($code){
    include_once(FCPATH.'phpbarcode/BarcodeGenerator.php');
    include_once(FCPATH.'phpbarcode/BarcodeGeneratorPNG.php');
    $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
    return "data:image/png;base64,".base64_encode($generator->getBarcode($code, $generator::TYPE_CODE_128));
}

function encode($arg) {
	return base64_encode($arg);
}

function decode($arg) {
	return base64_decode($arg);
}

function trimArray($arr){
	if(!$arr) {return $arr;}	foreach($arr as &$v){ if(!is_array($v)){$v=trim($v);} }	return $arr;
}

function keyValArray($arr, $key, $val){
	$ar=array();
	if($arr and is_array($arr)){
		foreach($arr as $d){
			if($key and $d[$key]) {$ar[$d[$key]]=$d[$val];} else {$ar[]=$d[$val];}
		}
	}
	return $ar;
}

function groupArray($arr, $key){
	$result=array();
	foreach($arr as $data){
		$k = $data[$key];
		if(isset($result[$k])) {
			$result[$k][]=$data;
		}else{
			$result[$k]=array($data);
		}
	}
	return $result;
}

function makeGroupsArray($arr, $key1, $key2=''){
	$rs = array();
	foreach($arr as $data) {
		$k = $data[$key1];
		
		if(isset($rs[$k])) {
			$rs[$k]['list'][]=$data;
		}else{
			$rs[$k]['group'][$key1]=$data[$key1];
			if($key2)	{$rs[$k]['group'][$key2]=$data[$key2];}
			$rs[$k]['list']=array($data);
		}
	}
	return $rs;
}

function renameKey(&$array, $old_keys, $new_keys){
    if(!is_array($array)){
        return $array;
    }
    if(is_array($old_keys)){
		foreach($new_keys as $k => $new_key){
			if(isset($array[$old_keys[$k]])){
				$array[$new_key]=$array[$old_keys[$k]];
				unset($array[$old_keys[$k]]);
			}
		}
	}else{
		if(isset($array[$old_keys])){
			$array[$new_keys] = $array[$old_keys];
			unset($array[$old_keys]);
		}
	}
    return $array;
}

function filterValue($post, $keys){
	$data=array();
	foreach($post as $k=>$v){
		if(in_array($k, $keys)){
			$data[$k]=$v;
		}
	}
	return $data;
}

function shortString($string='', $len=0) {
	$string=str_replace(['&nbsp;'], [' '], strip_tags($string));	
	$tmp=substr($string,0,$len);	
	if(strlen($string)<=$len) {return $string;}	
	return trim($tmp).((strlen($string)<=$len)?'':'...');
}

function getExt($file_name='') {
	$fn=explode(".", $file_name);
	return end($fn);
}

function appendToFilename($fn='', $appendTxt='') {
	$fn=str_replace(" ", "-", $fn);
	$arr=explode(".", $fn);
	$ext=end($arr);
	$n=substr(str_replace(".".$ext,"",$fn), 0, 80);
	return $n.$appendTxt.".".$ext;
}

function toDate($timestamp=FALSE, $long=FALSE, $format=''){
	if($timestamp) {
		if(!is_numeric($timestamp) && isDateBlank($timestamp))	{return;}
		if(!is_numeric($timestamp)) {$timestamp=strtotime($timestamp);}
		if($format)					{return date($format, $timestamp);}
		
		if($long)	{return date('d M Y - h:i A',$timestamp);} else {return date('d M Y', $timestamp);}
	}	
}

function toDateFormat($T){
	if(!$T)	{return '';}
	if(!is_numeric($T) && isDateBlank($T)){return '';}
	if(!is_numeric($T)) {$T=strtotime($T);}
	return date('Y-m-d H:i:s', $T);
}

function isDateBlank($date){
	$date=trim($date);	if(!$date || $date=="" || $date=="0000-00-00 00:00:00" || $date=="0000-00-00")	{return TRUE;}
}

function isValidDate($d, $format="d M Y"){
	$d=trim($d);
	if(!$d){
		return FALSE;
	}
	$nd=toDate($d, FALSE, $format);
	if($nd==$d){
		return TRUE;
	}
	return FALSE;
}

function currentDT(){
	return date('Y-m-d H:i:s');
}

function replaceSpecialChars($arg, $repW='-'){
	return preg_replace('/[^a-zA-Z0-9_\-]/',$repW, $arg);
}

function replaceNonDigits($str){
	return preg_replace("/[^0-9]/", "", $str);
}

function replaceNull($arr) {
	if(!is_array($arr)){
		if(is_null($arr)){
			$arr='';
		}
	}else{
		foreach($arr as $k=>$v){
			if(is_null($v)){
				$arr[$k]='';
			}
		}
	}
	return $arr;
}

function encodeHtml($arg){
	return str_replace(array('<', '>'), array('&lt;', '&gt;'), $arg);
}

function encodeScript($arg){
    $r=['<script>', '</script>'];
    $r1=['&lt;script&gt;', '&lt;/script&gt;'];
	return str_replace($r, $r1, $arg);
}

function checkImageExt($filename){
	if(in_array(strtolower(getExt($filename)), array('jpg', 'jpeg', 'png', 'gif'))){
		return TRUE;
	}else{
		return FALSE;
	}
}

function checkDocExt($filename){
	if(in_array(strtolower(getExt($filename)), array('pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'))){
		return TRUE;
	}else{
		return FALSE;
	}
}

function extType($filename) {
	$ext=strtolower(getExt($filename));
	$type='';
	if($ext=='pdf')							{$type='PDF';}
	elseif($ext=='doc' or $ext=='docx')		{$type='WORD';}
	elseif($ext=='xls' or $ext=='xlsx')		{$type='EXCEL';}
	elseif($ext=='ppt' or $ext=='pptx')		{$type='POWER POINT';}
	elseif(checkImageExt($filename))		{$type='IMAGE';}
	return $type;
}

function delFile($file){
	if(file_exists($file)) {unlink($file);}
}

function renameExistFile($path, $file){
	$file=str_replace(' ', '-', $file);
	if(file_exists($path.$file)){
		$fn=str_replace(" ", "-", $file);
		$ext=end(explode(".", $fn));
		$n=str_replace(".".$ext,"",$fn);
		$file=$n.'-'.time().".".$ext;
	}
	return $file;
}

function xml2array($xml) { 
    return simplexml_load_string(file_get_contents($xml));
}

function isEmail($email) {
	return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function curl($url, $data=null) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, true); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$output = curl_exec($ch);
	//$info = curl_getinfo($ch);
	curl_close($ch);
	return $output;
}

function sendEmailSendGrid($to, $subject, $message, $fromname='', $fromemail=''){
	if(ENVIRONMENT=='development'){
		return TRUE;
	}
	$key="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";
	//$key=SendgridKey;
	if(!$fromname) 	{$fromname="Mudra Portal";}
	if(!$fromemail) {$fromemail="info@mudramittra.in";}
	
	require_once("sendgrid/sendgrid-php.php");
	
	$email = new \SendGrid\Mail\Mail(); 
	
	$email->setFrom($fromemail, $fromname);
	$email->setSubject($subject);
	$email->addTo($to);
	//$email->addCcs(array("sat.web1989@gmail.com"=>"Satyendra"));
	//$email->addContent("text/plain", "and easy to do anywhere, even with PHP");
	$email->addContent("text/html", $message);
	$sendgrid = new \SendGrid($key);
	try {
		$response = $sendgrid->send($email);
		return $response->statusCode()==202;
	} catch (Exception $e) {
		//echo 'Caught exception: '. $e->getMessage() ."\n";
	}
}

function sendEmail($to, $subject, $message, $attachments=[], $smtp=TRUE, $smtpdtl=[]){
	if(ENVIRONMENT=='development'){
		return TRUE;
	}
	if(!$smtpdtl){
		$smtpdtl=[
			'host'=>'ssl://smtp.gmail.com', 
			'user'=>'admissions@sharda.ac.in', 
			'pass'=>'SU@lp2015',
			'port'=>'465',
		];
	}
	
	$fromname="Lead Examine";
	$fromemail="business@leadexamine.com";
	
	$CI =& get_instance();
    $CI->load->library('email');
	$mail=$CI->email;
	
	$mail->clear();
	
	$config['charset'] = 'utf-8';
	$config['wordwrap'] = TRUE;
	$config['mailtype'] = 'html';
	
	if($smtp){
		$config['protocol']   = "smtp";
		$config['smtp_host']  = $smtpdtl['host'];
		$config['smtp_user']  = $smtpdtl['user'];
		$config['smtp_pass']  = $smtpdtl['pass'];
		$config['smtp_port']  = $smtpdtl['port'];
		$config['_auth_smtp'] = TRUE;
		$config['newline']    = "\r\n";
		$config['crlf']       = "\r\n";
	}
	
	$mail->initialize($config);

	$mail->from($fromemail, $fromname);
	$mail->to($to);
	$mail->reply_to('noreply@leadexamine.com', $fromname);
	
	$mail->subject($subject);
	$mail->message($message);
	
	if($attachments and is_array($attachments)){
		foreach($attachments as $f){
			$mail->attach($f);
		}
	}

	$res=$mail->send();
	//echo $mail->print_debugger();
	return $res;
}

function getWords($str){
	$words=array_unique(str_word_count($str, 1, '0123456789'));
	return $words;
}

function strForFulltext($k, $partsearch=FALSE, $allmatch=FALSE){
	$c=array('/\(/', '/\)/', '/@/');
	$r=array(':', ':', ':');
	
	$words=get_words($k);
	if($words){
		foreach($words as &$w){
			if($allmatch){
				$w='+'.$w;
			}
			if($partsearch and substr($k, 0, 1)!='"' and substr($k, -1, 1)!='"'){
				$w=$w.'*';
			}
		}
		if($allmatch or $partsearch){
			$k=implode(" ", $words);
		}
	}
	
	$k=rtrim($k, '-+()~');
	$k=rtrim($k, '><');
	$k=preg_replace($c, $r, $k);
	
	return $k;
}


//EOF