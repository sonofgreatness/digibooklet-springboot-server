<!DOCTYPE HTML>
<html>
<head>
    <title>Purchase Order</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <!-- <link rel="stylesheet" href="<?php //echo URL.'assets/google.fonts.css'?>" /> -->
    <link rel="stylesheet" href="<?php echo URL.'assets/style.css?'.time()?>" />
    <style>
        @page{margin: 30px 20px;}
    </style>
</head>

<body>
	<div class="font-times-roman">
        <table class="font-times-roman">
            <tbody>
                <tr>
                    <td width="48%">
                        <div class="fs14 bold" style="letter-spacing:-1px">CREATIVITY OF THE MODERN BUSINESS L.L.C.</div>
                        <div class="fs13 pt5 bold">SALE OF AMERICAN SPARE PARTS</div>
                    </td>
                    
                    <td class="text-center">
                        <img src="<?php echo $client['logo_url']?>" width="100" />
                    </td>

                    <td width="48%" class="text-right bold fs20 simplified-arabic-font">
                        <div>الإبداع الحديث للأعمال ش.م.م</div>
                        <div class="pt10">بيع قطع غيار السيا ا رت الأمريكية</div>
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="pt5 text-center fs12">
            CR.NO.- 1190289 PO Box: 661, Postal Code-121, Sultanate of Oman, GSM: +968 98988650 / 99706696, Tel / Vat No: <?php echo $client['vat_no']?>
            <div>
                E-mail: <a href="mailto:creativemodern2015@gmail.com">creativemodern2015@gmail.com</a>
            </div>
            <div class="bold fs16 pt10 underline">PURCHASE ORDER</div>
            <?php if($po_status===5):?>
                <div class="text-danger bold">Cancelled</div>
            <?php endif;?>
        </div>

        <div class="pt15">
            <table class="font-times-roman">
                <tbody>
                    <tr>
                        <td class="w130"><strong>Supplier Code</strong></td>
                        <td class="w10">:</td>
                        <td><?php echo $supplier['cr_no']?></td>
                        <td class="w70"><strong>PO No.</strong></td>
                        <td class="w10">:</td>
                        <td class="w100"><?php echo $po_no?></td>
                    </tr>
                    <tr>
                        <td><strong>Supplier Name</strong></td>
                        <td>:</td>
                        <td><?php echo $supplier['name']?></td>
                        <td><strong>PO Date</strong></td>
                        <td>:</td>
                        <td><?php echo $po_date?></td>
                    </tr>
                    <tr>
                        <td><strong>Supplier VAT No.</strong></td>
                        <td>:</td>
                        <td><?php echo $supplier['vat_no']?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="pt15 pl6 pr6">
            <div style="<?php echo $_GET['pdf']?'':'min-'?>height:520px">
                <table class="bdr-dark font-times-roman">
                    <tbody>
                        <tr>
                            <td class="w50"><strong>S.No.</strong></td>
                            <td><strong>Description</strong></td>
                            <td class="text-center w60"><strong>Quantity</strong></td>
                            <td class="text-center w60"><strong>Rate</strong></td>
                            <td class="text-center w60"><strong>VAT %</strong></td>
                            <td class="text-center w90"><strong>VAT Amount</strong></td>
                            <td class="text-center w80"><strong>Total Price</strong></td>
                        </tr>

                        <?php foreach($items as $i=>$r):?>
                            <tr class="td-h-bdr-none">
                                <td><?php echo $i+1?>.</td>
                                <td><?php echo h($r['item_name'])?></td>
                                <td class="text-right"><?php echo h($r['qty'])?></td>
                                <td class="text-right"><?php echo number_format($r['rate'], 3)?></td>
                                <td class="text-right"><?php echo $r['vat_percent']?>%</td>
                                <td class="text-right"><?php echo number_format($r['vat'], 3)?></td>
                                <td class="text-right"><?php echo number_format($r['net_amt'], 3)?></td>
                            </tr>
                        <?php endforeach;?>
                        <?php for($i=1; $i<=16-count($items); $i++):?>
                            <!-- <tr class="td-h-bdr-none">
                                <td>&nbsp;</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr> -->
                        <?php endfor;?>

                        <tr>
                            <td colspan="6"><strong>Total Amount Excluding VAT</strong></td>
                            <td class="text-right"><strong><?php echo number_format($amt, 3)?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="6"><strong>Total VAT Amount</strong></td>
                            <td class="text-right"><strong><?php echo number_format($vat, 3)?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="6"><strong>GRAND TOTAL</strong></td>
                            <td class="text-right"><strong><?php echo number_format($net_amt, 3)?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="7">
                                <strong>
                                    Amount in Words:
                                    <span class="uc"><?php echo num_to_words_omr($net_amt)?></span>
                                </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="pt15 pl6 pr8">
            <div class="bold">Note:</div>
            <div class="">
                <ol>
                    <li>It is mandatory to quote above P.O. N.O. and Date in all your delivery notes and invoices.</li>
                    <li>It is mandatory to mention Bank Account details on the invoice. Payment to supplier will be by direct bank transfer only.</li>
                    <li>This P.O is subject to CMB standard terms & conditions for the supply of goods/service.</li>
                    <li>Tax, custom duties and other similar taxes to be paid by the supplier.</li>
                    <li>VAT identification number (VATIN) of your company is mandatory to apply the VAT rules as per the Sultanate of Oman VAT regime.</li>
                </ol>
            </div>
        </div>

        <div class="pt15 pl6 pr8">
            For <span class="bold fs22">CMB</span>
        </div>

        <div class="pt40 pl6 pr8">
            <table>
                <tbody>
                    <tr>
                        <td width="45%" class="bdr-sig"></td>
                        <td class="text-center"></td>
                        <td width="45%" class="bdr-sig"></td>
                    </tr>
                </tbody>
            </table>
        </div>
	</div>

    <?php if($_GET['print']):?>
        <script type="text/javascript">
            window.print();
        </script>
    <?php endif;?>
</body>
</html>