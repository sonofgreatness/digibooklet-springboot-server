<html>
    <head>
        <title>Stock Issued</title>
        <style>
            .uc{text-transform: uppercase;}
            .email-body{font-family: Arial, Helvetica, sans-serif;  color: #333; font-size: 13px; line-height: 18px; margin: 0; padding: 0;}
            .email-body table							{width:100%; border-collapse:collapse;}
            .email-body table.bdr th, .email-body table.bdr	td		{border:1px solid #eee}
            .email-body table.bdr-dark th, .email-body table.bdr-dark	td		{border:1px solid #777}
            .email-body table th						{padding:3px 5px; font-size:13px; font-weight:bold; color:#000; background:#ccc}
            .email-body table td						{padding:3px 5px}
            .email-body table td						{background:#FFFFFF}
        </style>
    </head>

    <body class="email-body">
        <div style="width:100%; background:#f1f1f1; padding:20px 0">
            <div style="background:#fff; padding:10px; width:70%; margin:0 auto">
                <div>
                    <div style="margin:0 0 15px 0; padding:0 0 10px 0; border-bottom:1px solid #f1f1f1; font-size:18px">
                        ELMIS
                    </div>

                    <!--Content-->
                    <div>
                        <div>
                            <table class="bdr table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td>Action</td>
                                        <td><strong>Stock Issued</strong></td>
                                    </tr>
                                    <tr>
                                        <td>Issued By</td>
                                        <td><strong><?php echo $udtl['name']?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Station Point (Requested From)</td>
                                        <td><strong><?php echo $station_point?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Request By</td>
                                        <td><strong><?php echo $udtl1['name']?></strong></td>
                                    </tr>
                                    <?php if($ticket_no):?>
                                        <tr>
                                            <td>Job Card#</td>
                                            <td><strong><?php echo $ticket_no?></strong></td>
                                        </tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                        </div>

                        <div style="padding:15px 0 5px 0" class="uc">Issued Items:</div>
                        <div>
                            <table class="bdr table table-bordered table-sm">
                                <thead class="thead-light uc">
                                    <tr>
                                        <th style="text-align:left">Category</th>
                                        <th style="text-align:left">Item</th>
                                        <th style="text-align:right">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($items as $r):?>
                                        <tr>
                                            <td>
                                                <?php echo $r['cat']?>
                                                <?php if($r['subcat']):?>
                                                    &nbsp;(<?php echo $r['subcat']?>)
                                                <?php endif;?>
                                            </td>
                                            <td><?php echo $r['item_full_name']?></td>
                                            <td style="text-align:right"><?php echo $r['qty']?></td>
                                        </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!--ContentEnd-->
                </div>
            </div>
        </div>
    </body>
</html>