2024-07-28 14:57:16 --> Add Role, Client ID: 24 
                                                 Name\t: Dvokolwako Health Centre
2024-07-28 14:57:16 --> Add Role, Client ID: 25 
                                                 Name\t: Emkhuzweni Health Centre
2024-07-28 14:57:16 --> Add Role, Client ID: 26 
                                                 Name\t: Good Shepherd Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 27 
                                                 Name\t: Hlathikhulu Government Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 28 
                                                 Name\t: Lobamba Clinic
2024-07-28 14:57:16 --> Add Role, Client ID: 29 
                                                 Name\t: Lubombo Referral Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 30 
                                                 Name\t: Mankhayane Government Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 31 
                                                 Name\t: Manzini NCD referral Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 32 
                                                 Name\t: Matsanjeni Health Centre
2024-07-28 14:57:16 --> Add Role, Client ID: 33 
                                                 Name\t: Mbabane Government Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 34 
                                                 Name\t: National Psychiatric Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 35 
                                                 Name\t: Nhlangano Health Centre
2024-07-28 14:57:16 --> Add Role, Client ID: 36 
                                                 Name\t: Piggs Peak Government Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 37 
                                                 Name\t: Raleigh Fitkin Memorial Hospital
2024-07-28 14:57:16 --> Add Role, Client ID: 38 
                                                 Name\t: Sithobelweni Health Centre
2024-07-28 14:57:16 -->  saved a new  role from national client 
2024-07-28 15:04:19 --> Add Role, Client ID: 24 
                                    Name\t: Dvokolwako Health Centre
2024-07-28 15:04:19 -->  saved a new  role from national for facility Dvokolwako Health Centre
2024-07-28 15:04:19 --> Add Role, Client ID: 25 
                                    Name\t: Emkhuzweni Health Centre
2024-07-28 15:04:19 -->  saved a new  role from national for facility Emkhuzweni Health Centre
2024-07-28 15:04:19 --> Add Role, Client ID: 26 
                                    Name\t: Good Shepherd Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Good Shepherd Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 27 
                                    Name\t: Hlathikhulu Government Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Hlathikhulu Government Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 28 
                                    Name\t: Lobamba Clinic
2024-07-28 15:04:20 -->  saved a new  role from national for facility Lobamba Clinic
2024-07-28 15:04:20 --> Add Role, Client ID: 29 
                                    Name\t: Lubombo Referral Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Lubombo Referral Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 30 
                                    Name\t: Mankhayane Government Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Mankhayane Government Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 31 
                                    Name\t: Manzini NCD referral Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Manzini NCD referral Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 32 
                                    Name\t: Matsanjeni Health Centre
2024-07-28 15:04:20 -->  saved a new  role from national for facility Matsanjeni Health Centre
2024-07-28 15:04:20 --> Add Role, Client ID: 33 
                                    Name\t: Mbabane Government Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility Mbabane Government Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 34 
                                    Name\t: National Psychiatric Hospital
2024-07-28 15:04:20 -->  saved a new  role from national for facility National Psychiatric Hospital
2024-07-28 15:04:20 --> Add Role, Client ID: 35 
                                    Name\t: Nhlangano Health Centre
2024-07-28 15:04:20 -->  saved a new  role from national for facility Nhlangano Health Centre
2024-07-28 15:04:20 --> Add Role, Client ID: 36 
                                    Name\t: Piggs Peak Government Hospital
2024-07-28 15:04:21 -->  saved a new  role from national for facility Piggs Peak Government Hospital
2024-07-28 15:04:21 --> Add Role, Client ID: 37 
                                    Name\t: Raleigh Fitkin Memorial Hospital
2024-07-28 15:04:21 -->  saved a new  role from national for facility Raleigh Fitkin Memorial Hospital
2024-07-28 15:04:21 --> Add Role, Client ID: 38 
                                    Name\t: Sithobelweni Health Centre
2024-07-28 15:04:21 -->  saved a new  role from national for facility Sithobelweni Health Centre
2024-07-28 15:04:21 -->  saved a new  role from national for facility Sithobelweni Health Centre
