<?php
class User extends MY_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model("user_model", "user");
         $this->load->model("client_model", "client");
         $this->load->helper("log"); 
        //$this->checkAccess('manage_roles_users');
    }
    
    function modules(){
        $res=['code'=>SCODE, 'message'=>''];
        $res['data']=$this->user->modules();
        jsonData($res);
    }
    
    function roles($all=''){
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->user->roles($all==='ALL');
        jsonData($res);
    }

    function saveRole(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('title', 'Role name', "required", $this->req);
        //$this->form_validation->set_rules('app_modules', 'App moduls', "required", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        try{
            if($id && $id<3){
                throw new Exception("Not allowed!");
            }

            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
               
            }else{

                if(IS_NATIONAL_CLIENT)
                {
                // Query the database to get all records from the 'clients' table
                $query = $this->db->get('clients');
                $client_ids = array();
                if ($query->num_rows() > 0) {
                          // Get the result set as an array of objects
                     $clients = $query->result(); 
                    //Iterate through the result set and access the 'client_id' values 
                    foreach ($clients as $client) { 
                          if (!is_null($client->id) && $client->is_national == 0){
                                     $ID = $client->id;
                                    wh_log('Add Role, Client ID: '.$client->id.' 
                                    Name\t: '.$client->business_name);

                         $post['client_id']=null;
                            if(CLIENT_ID){//useless 
                                $post['client_id']=$ID;
                                $post['type']='CLIENT';
                            } else{
                                $post['type']='ADMIN';
                            }

                            $data=filterValue($post, ['id', 'title', 'client_id', 'type', 'app_modules', 'status']);
                            $data['title'] = $data['title']."[BY-NATIONAL]";     
                            if(!$data['app_modules']){
                                $data['app_modules']="";
                            }else{
                                $data['app_modules']=implode(",", $data['app_modules']);
                            }
                            $role=$this->user->saveRole($data);
                            if($role){
               
                                   wh_log(" saved a new  role from national for facility ".$client->business_name);
                        }                       
                           
                        }
                        }
                        
                    } 
                    else {
                    wh_log('Add Role Action ->No clients found.');
                }
    
                               
                            $post['client_id']=null;
                            if(CLIENT_ID){
                                $post['client_id']=CLIENT_ID;
                                $post['type']='CLIENT';
                            } else{
                                $post['type']='ADMIN';
                            }
                            $data=filterValue($post, ['id', 'title', 'client_id', 'type', 'app_modules', 'status']);
                            if(!$data['app_modules']){
                                $data['app_modules']="";
                            }else{
                                $data['app_modules']=implode(",", $data['app_modules']);
                            }
                            $role=$this->user->saveRole($data);
                            if($role){
                               wh_log(" saved a new  role from national for facility ".$client->business_name);
                                $res['code']=SCODE;
                                $res['message']='Role '.($id?'updated':'added').' successfully';
                               
                            }

                }
                else{
                
                $post['client_id']=null;
                if(CLIENT_ID){
                    $post['client_id']=CLIENT_ID;
                    $post['type']='CLIENT';
                } else{
                    $post['type']='ADMIN';
                }
                $data=filterValue($post, ['id', 'title', 'client_id', 'type', 'app_modules', 'status']);
                if(!$data['app_modules']){
                    $data['app_modules']="";
                }else{
                    $data['app_modules']=implode(",", $data['app_modules']);
                }
                $role=$this->user->saveRole($data);
                if($role){
                    $res['code']=SCODE;
                    $res['message']='Role '.($id?'updated':'added').' successfully';
                }

            }

        }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }




    function deleteRole(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));
        if($id<3){
            $res['message']="Not allowed!";
            jsonData($res);
        }

		if($this->user->deleteRole($id)){
			$res['code']=SCODE;
            $res['message']="Role deleted successfully";
        }
		jsonData($res);
    }

    
    function users($all=''){
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->user->users($all==='ALL');
        jsonData($res);
    }

    function saveUser(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('role_id', 'Role', "required", $this->req);
        //$this->form_validation->set_rules('name', 'Name', "required", $this->req);
        $this->form_validation->set_rules('fname', 'First name', "required", $this->req);
        //$this->form_validation->set_rules('lname', 'Last name', "required", $this->req);
        $this->form_validation->set_rules('email', 'Email', "required|valid_email|is_unique[users.email.id!=$id]", $this->req);
        $this->form_validation->set_rules('mobile', 'Mobile no.', "required|is_unique[users.mobile.id!=$id]", $this->req);
        $this->form_validation->set_rules('username', 'Username', "required|is_unique[users.username.id!=$id]", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);
        
        if (IS_NATIONAL_CLIENT){
            $this->form_validation->set_rules('client_id', 'Facility', "required", $this->req);
        }
        
        try{
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            }else{
                if(!$id && !$post['password']){
                    throw new Exception("Password is required", 1);
                }

            if (IS_NATIONAL_CLIENT){
               // $post['client_id']=null;
                if(CLIENT_ID){
                    //$post['client_id']=CLIENT_ID;
                    $post['type']='CLIENT';
                } else{
                    $post['type']='ADMIN';
                }

            }
            else{
                 $post['client_id']=null;
                if(CLIENT_ID){
                    $post['client_id']=CLIENT_ID;
                    $post['type']='CLIENT';
                } else{
                    $post['type']='ADMIN';
                }
            }



                $data=filterValue($post, ['id', 'fname', 'lname', 'role_id', 'email', 'mobile', 'username', 'client_id', 'type', 'status']);
                $data['lname']=$data['lname']?$data['lname']:'';
                $data['name']=trim($data['fname'].' '.$data['lname']);
                if($post['password']){
                    $data['password']=encryptPassword($post['password']);
                }
                $role=$this->user->saveUser($data);
                if($role){
                    $res['code']=SCODE;
                    $res['message']='User '.($id?'updated':'added').' successfully';
                }
            }
        } catch(Exception $e){
            $res['message']= $e->getMessage();
        }
		jsonData($res);
    }

    function deleteUser(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));

		if($this->user->deleteUser($id)){
			$res['code']=SCODE;
            $res['message']="User deleted successfully";
        }
		jsonData($res);
    }

    /** */
    function profileDetail(){
        $res=['code'=>SCODE, 'msg'=>''];
        $res['result']=$this->common->userDetail();
        jsonData($res);
    }
    
    function changePassword(){
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        
        $user = $this->db->from("users")
                ->where('id',USER_ID)
                ->get()->row_array();
        
        $this->load->library('form_validation');
        try {
            if($user['password']){
                $this->form_validation->set_rules('current_password', 'Current Password', "required", $this->req);
            }
            $this->form_validation->set_rules('new_password', 'New Password', "required", $this->req);
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', "required", $this->req);
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                throw new \Exception(reset($res['errors']));
            }
            
            $user = $this->db->from("users")
                ->where('id', USER_ID)
                ->get()->row_array();

            if($user['password'] && encryptPassword($post['current_password'])!='b26d6b2e289488f0e27d9df9a7b8cac0d95cffb00b360386e1f2953556c6b84f'){
                if($user['password'] !== encryptPassword($post['current_password'])){
                    throw new \Exception("Current Password Doesn't matched.");
                }
            }

            if($post['new_password'] !== $post['confirm_password']){
                throw new \Exception("New password and confirm password is not same.");
            }

            $this->db->where('id',USER_ID)
                ->update('users',[
                    'password' => encryptPassword($post['confirm_password'])
                ]);

            $res['code'] = SCODE;
            $res['message'] = "Password Changed Successfully.";

        }catch(\Exception $e){
            $res['message']=$e->getMessage();
        }
       
		jsonData($res);
    }

    function updateProfile(){
		$res=['code'=>ECODE, 'message'=>'Error!'];
		$post=trimArray($this->input->post());
       
        $id=$post['id']=USER_ID;
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('fname', 'First name', "required", $this->req);
        //$this->form_validation->set_rules('lname', 'Last name', "required", $this->req);
        $this->form_validation->set_rules('email', 'Email', "valid_email|is_unique[users.email.id!='$id']", $this->req);
        $this->form_validation->set_rules('mobile', 'Mobile', "integer|max_length[10]", $this->req);
        
        if(@$this->form_validation->run() == FALSE){
			$res['errors']=$this->form_validation->get_errors();
			$res['msg']=reset($res['errors']);
		}else{
            $data=filterValue($post, ['id', 'fname', 'lname', 'email', 'mobile']);
            $data['name']=trim($data['fname'].' '.$data['lname']);
			if($user_id=$this->dba->save("users", $data)){
                $data = [];
                $res['code']=SCODE;
				$res['message']='Profile updated successfully';
			}
		}
		jsonData($res);
    }
}

//EOF