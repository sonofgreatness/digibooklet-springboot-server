<?php
class Dashboard extends MY_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model("dashboard_model", "dashboard");
    }
}

//EOF