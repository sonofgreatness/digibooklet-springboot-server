<?php
class Client extends MY_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model("client_model", "client");
}

    function lists($all=''){
        if($all!=='ALL'){
            $this->checkAccess('manage_facilities');
        }
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->client->lists($all==='ALL');
        jsonData($res);
    }

    function save(){
        $this->checkAccess('manage_facilities');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=$post['id']=intval($post['id']);
        $user_id=$post['user_id']=intval($post['user_id']);
        /* if($id && CLIENT_ID){
            $dtl=$this->client->detail($id);
            if($dtl['is_national']){
                jsonData($res);
            }
        } */

        $this->load->library('form_validation');
        $this->form_validation->set_rules('site_code', 'Site code', "required|is_unique[clients.site_code.id!='$id']", $this->req);
        $this->form_validation->set_rules('fac_code', 'Facility code', "required|is_unique[clients.fac_code.id!='$id']", $this->req);
        $this->form_validation->set_rules('business_name', 'Facility/Site name', "required|is_unique[clients.business_name.id!='$id']", $this->req);
        $this->form_validation->set_rules('phone1', 'Facility phone', "required", $this->req);
        $this->form_validation->set_rules('address', 'Address', "required", $this->req);
        //$this->form_validation->set_rules('city', 'City', "required", $this->req);
        //$this->form_validation->set_rules('pincode', 'Pincode', "required", $this->req);

        $this->form_validation->set_rules('asset_cat_ids', 'Asset Category', "required", $this->req);

        
        $this->form_validation->set_rules('name', 'Admin name', "required", $this->req);
        $this->form_validation->set_rules('email', 'Admin email', "required|valid_email|is_unique[users.email.id!='$user_id']", $this->req);
        $this->form_validation->set_rules('mobile', 'Admin mobile', "required|integer|is_unique[users.mobile.id!='$user_id']", $this->req);
        $this->form_validation->set_rules('username', 'Admin username', "required|is_unique[users.username.id!='$user_id']", $this->req);
        
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);

        if(!$id){
            $this->form_validation->set_rules('password', 'Password', "required", $this->req);
        }

        try {
            if(@$this->form_validation->run() == FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            } else {
                $f=[
                    'id', 'is_national', 'site_code', 'fac_code', 'business_name', 'facility_owner', 'located_region', 'phone1', 'address', 'city', 'pincode', 'site_type', 
                    'latitude', 'longitude', 'asset_cat_ids', 'status'
                ];
                $data=filterValue($post, $f);
                if(!$data['id'] && CLIENT_ID){
                    $data['is_national']=0;
                }

                $udata=filterValue($post, ['name', 'email', 'mobile', 'username']);
                $udata['id']=$user_id;
                $udata['role_id']=2;
                $udata['type']='CLIENT';
                if ($post['password']) {
                    $udata['password'] = encryptPassword($post['password']);
                }

                if($this->client->save($data, $udata)){
                    $res['code'] = SCODE;
                    $res['message'] = 'Facility ' . ($id ? ' details updated' : 'added') . ' successfully';
                }
            }
        } catch (Exception $e) {
            $res['message'] = $e->getMessage();
        }
        jsonData($res);
    }

    function delete(){
        $this->checkAccess('manage_facilities');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $id=intval($this->input->post('id'));
        if(CLIENT_ID){
            $dtl=$this->client->detail($id);
            if($dtl['is_national']){
                jsonData($res);
            }
        }

        if ($this->client->delete($id)) {
            $res['code'] = SCODE;
            $res['message'] = "Client deleted successfully";
        }
        jsonData($res);
    }

    function saveConfig(){
        $this->checkAccess('manage_facilities');
        $res = ['code' => ECODE, 'message' => 'Error!'];
        $post = trimArray($this->input->post());
        $client_id = intval($post['clientId']);
        $data = $post['data'];
        $data = explode(',', $data);

        if (!$data[0]) {
            $data = [];
        }
        $data = array_map(function ($ele) use ($client_id) {
            return ['station_id' => $ele, 'client_id' => $client_id, 'created' => currentDT()];
        }, $data);

        if ($this->db->delete('clients_station_points', ['client_id' => $client_id])) {
            $res['code'] = SCODE;
            if ($data) {
                $res['message'] = "All configuration deleted but can not be saved new configuration";
            } else {
                $res['message'] = "Configuration is empty";
            }
        }

        if ($data) {
            if ($this->db->insert_batch('clients_station_points', $data)) {
                $res['code'] = SCODE;
                $res['message'] = "Configuration saved successfully";
            }
        }

        jsonData($res);
    }

    function stationPointLists($all=''){
        $res=['code'=> SCODE, 'message'=>''];
        $res['result']=$this->client->stationPointLists($all==='ALL');
        jsonData($res);
    }

    function saveStationPoint(){
        $res = ['code' => ECODE, 'message' => 'Error!'];
        $post = trimArray($this->input->post());
        $id = $post['id'] = intval($post['id']);

        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Station point name', "required|is_unique[station_points.name.id!='$id']", $this->req);
        $this->form_validation->set_rules('status', 'Status', "required", $this->req);
        //$this->form_validation->set_rules('asset_cat_ids', 'Asset Category', "required", $this->req);

        try {
            if (@$this->form_validation->run() == FALSE) {
                $res['errors'] = $this->form_validation->get_errors();
                $res['message'] = reset($res['errors']);
            } else {
                $data = filterValue($post, ['id', 'name', 'asset_cat_ids', 'status']);
                $station_point_id=$this->client->saveStationPoint($data);
                if ($station_point_id) {
                    $res['code'] = SCODE;
                    $res['message'] = 'Station point ' . ($id ? 'updated' : 'added') . ' successfully';
                }
            }
        } catch (Exception $e) {
            $res['message'] = $e->getMessage();
        }
        jsonData($res);
    }

    function deleteStationPoint(){
        $res = ['code' => ECODE, 'message' => 'Error!'];
        $id = intval($this->input->post('id'));

        if ($this->client->deleteStationPoint($id)) {
            $res['code'] = SCODE;
            $res['message'] = "Station point deleted successfully";
        }
        jsonData($res);
    }

    //Lobamba, Dvokolwako, Pigg's Peak
}

//EOF