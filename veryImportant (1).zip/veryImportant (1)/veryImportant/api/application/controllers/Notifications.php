<?php
class Notifications extends MY_Controller{
    function __construct() {
        parent::__construct();
    }

    function all($all=''){
        $res=['code'=>SCODE, 'message'=>''];
        $user_id=(int)USER_ID;
        $res['result']=$this->db->select("n.*, IF(nr.id IS NULL, 0, 1) isread")
        ->from("notifications n")
        ->join("notifications_read nr", "nr.notification_id=n.id AND nr.user_id='$user_id'", "LEFT")
        ->where("FIND_IN_SET('$user_id', to_user_ids)", NULL, FALSE)
        ->order_by("n.id", "DESC")
        ->limit(2000)
        ->get()
        ->result_array();

        foreach($res['result'] as &$r){
            $r['created']=toDate($r['created'], true);
            $r['isread']=(int)$r['isread'];
        }

        jsonData($res);
    }

    function read(){
        ignore_user_abort(true);
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        if(!$id){
            jsonData($res);
        }

        if(!$this->db->get_where("notifications_read", ['notification_id'=>$id, 'user_id'=>USER_ID])->row_array()){
            $data=[
                'notification_id'=>$id,
                'user_id'=>USER_ID,
                'created'=>currentDT(),
            ];
            $this->db->insert("notifications_read", $data);
        }

        $res['code']=SCODE;
        $res['message']='';
        jsonData($res);
    }
}

// EOF