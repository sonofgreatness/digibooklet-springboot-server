<?php
class MY_Controller extends CI_Controller {
    function __construct() {
		parent::__construct();
        //date_default_timezone_set('UTC');
        //date_default_timezone_set('Asia/Kolkata');
        date_default_timezone_set('Africa/Juba');
        
        $headers=getallheaders();
        if(strpos($headers['Content-Type'], 'application/json')!==FALSE){
            $data=json_decode(file_get_contents("php://input"), true);
            $_POST=$data?$data:[];
            unset($data);
        }
		
		$this->db->query("SET sql_mode=''");
		$this->load->model('common_model', 'common');

        $token=$this->input->get_request_header("authorization");
        if(!$token){
            $token=$_REQUEST['authorization'];
        }
        define('AUTH_TOKEN', 	    $token);

		$dtl=$this->loggedData();
        define('USER_ID', 			    $dtl['id']?$dtl['id']:'');
        define('USER_TYPE', 			$dtl['USER_TYPE']?$dtl['USER_TYPE']:'');
        define('ROLE_ID', 		        $dtl['role_id']?$dtl['role_id']:'');
        define('CLIENT_ID', 		    $dtl['client_id']?$dtl['client_id']:'');
        define('IS_NATIONAL_CLIENT', 	$dtl['is_national']);
        define('IS_CLIENT_ADMIN', 	    $dtl['is_client_admin']);
        define('IS_ADMIN', 	            $dtl['is_admin']);

        define('NO_OF_DEC', 		    2);

        $smtp=$this->common->smtp_dtl();
        define('SMTP_HOST',                 $smtp['host']);
        define('SMTP_USER',                 $smtp['user_name']);
        define('SMTP_PASS',                 $smtp['password']);
        define('SMTP_PORT',                 $smtp['port']);
        define('SMTP_SENDER_NAME',          $smtp['sender_name']);
        define('SMTP_SENDER_EMAIL',         $smtp['sender_email']);
        define('SMTP_REPLYTO',              $smtp['reply_to']);

        $this->req=array('required'=>'%s required', 'is_unique'=>'This %s is already used', 'numeric'=>'%s must be numeric', 'integer'=>'%s must be numeric');
	}
	
	function loggedData(){
        $res=['code'=>UACODE, 'message'=>'Invalid credentials!', 'loggedOut'=>1];
        $without_logins_ctr=[];
        $without_logins_fn=['error404', 'login', 'test'];
        $ctr=strtolower($this->uri->rsegments[1]);
        $fn=$this->uri->rsegments[2];

        if((!in_array(strtolower($ctr), $without_logins_ctr) && !in_array($fn, $without_logins_fn))){
            if(!AUTH_TOKEN){
                jsonData($res);
            }
            $dtl=$this->encryption->decrypt(AUTH_TOKEN);
            if(!$dtl){
                jsonData($res);
            }
            $dtl=unserialize($dtl);

            $dtl=$this->common->userDetail($dtl['id']);
            if(!$dtl){
                jsonData($res);
            }
            if(!$dtl['status']){
                $res['message']="Your account is not active!";
                jsonData($res);
            }
        }
		return $dtl?$dtl:[];
    }

	function imgExtCheck($v, $param='image'){
		if($_FILES[$param]['name'] && !check_image_ext($_FILES[$param]['name'])){
			$this->form_validation->set_message('img_ext_check', 'Please upload .jpg, .jpeg, .gif or .png file only');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	function validDate($v){
		if($v && !isValidDate($v)){
			$this->form_validation->set_message("valid_date", "Invalid date format (%s)!");
			return FALSE;
		}
		return TRUE;
	}

    function isAccess($module){
		if(IS_ADMIN){
			return TRUE;
		}
		$this->load->model('auth_model', 'auth');
		$modules=$this->auth->modules(USER_ID);
		if(!is_array($module)){
			$arg_modules[]=$module;
		}else{
			$arg_modules=$module;
		}

		foreach($arg_modules as $m){
			if(isset($modules[$m])){
				return TRUE;
			}
		}
		return FALSE;
	}

	function checkAccess($module){
		if(!$this->isAccess($module)){
			jsonData(array('code'=>ECODE, 'message'=>'You are not allowed to access this module'));
		}
	}
}

//EOF