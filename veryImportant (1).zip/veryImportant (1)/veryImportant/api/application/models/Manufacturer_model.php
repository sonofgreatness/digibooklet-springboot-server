<?php

class Manufacturer_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function lists($all=false){
        $qs=trimArray($this->input->get());
        if(strlen($qs['status'])){
            $this->db->where("m.status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("m.name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("m.id, m.name, m.email, m.address, m.street, m.town, m.city, m.phone1, m.phone2, m.status, m.country_id, c.title country, c.code country_code, c.isd_code")
        ->from("manufacturers m")
        ->join("master_countries c", "c.id=m.country_id", "LEFT")
        ->order_by("m.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
        }
        return $rs;
    }

    function save($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $manufacturer_id=$this->dba->save("manufacturers", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $manufacturer_id;
        }
    }

    function delete($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("manufacturers", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }
}

// EOF