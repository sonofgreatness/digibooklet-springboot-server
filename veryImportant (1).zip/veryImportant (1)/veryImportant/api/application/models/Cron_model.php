<?php
class Cron_model extends CI_Model{
    function __construct() {
        parent::__construct();
    }

    function serviceNotification(){
        //ini_set('display_errors', 1);
		//error_reporting(E_ALL & ~E_NOTICE);

        $f="s.client_id, s.code, s.serial_no, s.procurement_date, i.name, i.service_period, i.service_period_type";
        $rs=$this->db->select($f)
        ->from("assets s")
        ->join("items i", "i.id=s.item_id")
        ->where(['s.procurement_date!='=>null, 'i.service_period>'=>0])
        ->get()
        ->result_array();

        foreach($rs as $r){
            $data=['code'=>$r['code'], 'serial_no'=>$r['serial_no'], 'name'=>$r['name'], 'procurement_date'=>$r['procurement_date'], 'service_period'=>$r['service_period'], 'service_period_type'=>$r['service_period_type']];
            $msg=$this->load->view("email/service_required", $data, true);
            $msg1=explode("<!--Content-->", $msg);
            $msg1=explode("<!--ContentEnd-->", $msg1[1]);
            $noti=trim(compressHtml($msg1[0]));

            $to_users=$this->db->select("id, name, email")->where_in("role_id", $this->common->assetManagersIds())->get_where("users", ['client_id'=>$r['client_id']])->result_array();

            $to_user_ids=[];
            foreach($to_users as $u){
                $to_user_ids[]=$u['id'];
            }
            $to_user_ids=implode(",", $to_user_ids);

            $data=[
                'subject'=>"Service Required: {$r['name']} ({$r['serial_no']})",
                'msg'=>$noti,
                'to_user_ids'=>$to_user_ids,
                'created'=>currentDT()
            ];

            $h=(int)date('H');
            $d=(int)date('d');
            $sp=(int)$r['service_period'];

            switch($r['service_period_type']){
                case 'Days':
                    if($h===8 && $d%$sp===0){
                        $this->db->insert("notifications", $data);
                        foreach($to_users as $u){
                            $to=['to'=>$u['email'], 'cc'=>'sat.web1989@gmail.com'];
                            //$this->common->send_email($to, $data['subject'], $msg);
                        }
                    }
                break;

                case 'Hours':
                    if($d%$sp===0){
                        $this->db->insert("notifications", $data);
                        foreach($to_users as $u){
                            $to=['to'=>$u['email'], 'cc'=>'sat.web1989@gmail.com'];
                            //$this->common->send_email($to, $data['subject'], $msg);
                        }
                    }
                break;
            }
        }

        //$this->common->send_email("sat.web1989@gmail.com", "Cron test", date("Y-m-d H:i:s"));
    }
}

// EOF