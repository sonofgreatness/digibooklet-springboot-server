<html>
    <head>
        <title>Job Card Closed</title>
        <style>
            .uc{text-transform: uppercase;}
            .bold{font-weight:bold}
            .email-body{font-family: Arial, Helvetica, sans-serif;  color: #333; font-size: 13px; line-height: 18px; margin: 0; padding: 0;}
            .email-body table							{width:100%; border-collapse:collapse;}
            .email-body table.bdr th, .email-body table.bdr	td		{border:1px solid #eee}
            .email-body table.bdr-dark th, .email-body table.bdr-dark	td		{border:1px solid #777}
            .email-body table th						{padding:3px 5px; font-size:13px; font-weight:bold; color:#000; background:#ccc}
            .email-body table td						{padding:3px 5px}
            .email-body table td						{background:#FFFFFF}
        </style>
    </head>

    <body class="email-body">
        <div style="width:100%; background:#f1f1f1; padding:20px 0">
            <div style="background:#fff; padding:10px; width:70%; margin:0 auto">
                <div>
                    <div style="margin:0 0 15px 0; padding:0 0 10px 0; border-bottom:1px solid #f1f1f1; font-size:18px">
                        ELMIS
                    </div>

                    <!--Content-->
                    <div>
                        <div>
                            <table class="bdr table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td>Action</td>
                                        <td><strong>Job Card Closed</strong></td>
                                    </tr>
                                    <tr>
                                        <td>Job Card#</td>
                                        <td><strong><?php echo $dtl['ticket_no']?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Station Point</td>
                                        <td><strong><?php echo $station_point?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Closed By</td>
                                        <td><strong><?php echo $udtl['name']?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Created By</td>
                                        <td><strong><?php echo $udtl1['name']?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div style="padding:15px 0 5px 0" class="uc">Subject:</div>
                        <div class="bold">
                            <?php echo $dtl['subject']?>
                        </div>

                        <div style="padding:15px 0 5px 0" class="uc">Description:</div>
                        <div class="bold">
                            <?php echo $dtl['description']?>
                        </div>
                    </div>
                    <!--ContentEnd-->
                </div>
            </div>
        </div>
    </body>
</html>