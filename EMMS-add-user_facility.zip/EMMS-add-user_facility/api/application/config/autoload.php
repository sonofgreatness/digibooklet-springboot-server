<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$autoload['packages']=[];
$autoload['libraries']=['database', 'encryption'];
$autoload['drivers']=[];
$autoload['helper']=['url', 'form', 'file', 'util', 'site'];
$autoload['config']=[];
$autoload['language']=[];
$autoload['model']=['dba'];