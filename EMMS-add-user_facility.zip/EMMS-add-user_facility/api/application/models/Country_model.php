<?php 
class Country_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function all(){
        return $this->db->select("id, title, code, isd_code")->order_by("title")->get("master_countries")->result_array();
    }
}

//End of file