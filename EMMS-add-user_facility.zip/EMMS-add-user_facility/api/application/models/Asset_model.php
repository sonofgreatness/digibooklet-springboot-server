<?php
class Asset_model extends CI_Model{
    function __construct() {
        parent::__construct();
    }

    function cats($all=false){
        $qs=trimArray($this->input->get());
        if(strlen($qs['status'])){
            $this->db->where("status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("id, name, type, status")
        ->from("assets_cats")
        ->order_by("name", "ASC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
            $r['subcats']=$this->db->select("id, name, status")->get_where("assets_sub_cats", ['cat_id'=>$r['id'], 'status'=>1])->result_array();
        }
        return $rs;
    }

    function saveCat($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $asset_cat_id=$this->dba->save("assets_cats", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $asset_cat_id;
        }
    }

    function deleteCat($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("assets_cats", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function assetSubCats($all=false){
        $qs=trimArray($this->input->get());
        $this->db->where("cat_id", $qs['catId']);
        if(strlen($qs['status'])){
            $this->db->where("status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("id, name, status")
        ->from("assets_sub_cats")
        ->order_by("name", "ASC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
        }
        return $rs;
    }

    function assetSubCatSave($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $asset_cat_id=$this->dba->save("assets_sub_cats", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $asset_cat_id;
        }
    }

    function assetSubCatDelete($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("assets_sub_cats", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function infrastuctureSubCats(){
        $qs=trimArray($this->input->get());
        if($qs['status']){
            $this->db->where("sc.status", 1)->where("c.status", 1);
        }

        $rs=$this->db->select("sc.id, sc.name, sc.status, c.name cat")
        ->from("assets_sub_cats sc")
        ->join("assets_cats c", "c.id=sc.cat_id")
        ->where("c.type", "Infrastructure")
        ->order_by("sc.name", "ASC")
        ->get()
        ->result_array();

        foreach($rs as &$r){
            $r['status']=(int)$r['status'];
        }
        return $rs;
    }

    function items($all=false){
        $client_id=CLIENT_ID;
        $qs=trimArray($this->input->get());
        if(strlen($qs['status'])){
            $this->db->where("i.status", $qs['status']);
        }
        if($qs['cat_type']){
            $this->db->where("ac.type", $qs['cat_type']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("i.name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("i.*, ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacturer, sp.name service_provider, v.name vendor, um.name uom, md.name model")
        ->from("items i")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("service_providers sp", "sp.id=i.service_provider_id", "LEFT")
        ->join("vendors v", "v.id=i.vendor_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("uoms um", "um.id=i.uom_id")
        ->group_by("i.id")
        ->order_by("i.id", "DESC");

        if($qs['availableAssetsOnly']==='Y'){
            if($qs['transferType']){
                $client_id=intval($qs['client_id']?$qs['client_id']:CLIENT_ID);
                $this->db->join("assets a", "a.item_id=i.id");
                $this->db->join("stock_transfers st", "a.id=st.asset_id");
            }
            if($qs['transferType']==='IN'){
                $this->db->where(["st.transfer_to"=>$client_id, "st.is_approved"=>1]);
            }else if($qs['transferType']==='OUT'){
                $this->db->where("a.client_id", $client_id);
            }else{
                if(IS_NATIONAL_CLIENT){
                    if($qs['client_id']){
                        $client_id=intval($qs['client_id']);
                        $this->db->join("assets a", "a.item_id=i.id AND a.client_id='$client_id'");
                    }else{
                        $this->db->join("assets a", "a.item_id=i.id");
                    }
                }else{
                    $this->db->join("assets a", "a.item_id=i.id AND a.client_id='$client_id'");
                }
            }
        }else{
            $this->db->select("a.stock");
            $this->db->join("assets a", "a.item_id=i.id AND a.client_id='$client_id'", "LEFT");
        }

        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];

            $r['item_full_name']=$r['name'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }
        }
        return $rs;
    }

    function itemDetail($id){
        $client_id=CLIENT_ID;
        $rs=$this->db->select("i.*, ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacturer, um.name uom, md.name model, a.stock")
        ->from("items i")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("uoms um", "um.id=i.uom_id")
        ->join("assets a", "a.item_id=i.id AND a.client_id='$client_id'", "LEFT")
        ->where("i.id", $id)
        ->get()
        ->row_array();

        if($rs){
            $rs['item_full_name']=$rs['name'];
            if($rs['model']){
                $rs['item_full_name'].=' - '.$rs['model'];
            }
            if($rs['manufacturer']){
                $rs['item_full_name'].=' - '.$rs['manufacturer'];
            }
        }

        return $rs?$rs:[];
    }

    function saveItem($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $id=$this->dba->save("items", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $id;
        }
    }

    function deleteItem($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("items", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function uoms($all=false){
        $qs=trimArray($this->input->get());
        if(strlen($qs['status'])){
            $this->db->where("status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("id, name, status")
        ->from("uoms")
        ->order_by("name", "ASC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
        }
        return $rs;
    }

    function saveUom($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $asset_cat_id=$this->dba->save("uoms", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $asset_cat_id;
        }
    }

    function deleteUom($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("uoms", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function models($all=false){
        $qs=trimArray($this->input->get());
        if(strlen($qs['status'])){
            $this->db->where("status", $qs['status']);
        }
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("name", $qs['k']);
            $this->db->group_end();
        }
        $this->db->select("id, name, status")
        ->from("models")
        ->order_by("name", "ASC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
        }
        return $rs;
    }

    function saveModel($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $asset_cat_id=$this->dba->save("models", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $asset_cat_id;
        }
    }

    function deleteModel($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("models", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function allFunctionalStatus(){
        return $this->db->select('id, name')->get('mm_functional_status')->result_array();
    }

    function lists($all=false){
        $qs=trimArray($this->input->get());
        if(IS_NATIONAL_CLIENT){
            if($qs['my_only']==='Y'){
                $this->db->where("a.client_id", CLIENT_ID);
            }else if($qs['client_id']){
                $this->db->where("a.client_id", $qs['client_id']);
            }else{
                //$this->db->where("a.client_id", CLIENT_ID);
            }
        }else{
            $this->db->where("a.client_id", CLIENT_ID);
        }
        

        if(strlen($qs['status'])){
            $this->db->where("a.status", $qs['status']);
        }
        if(strlen($qs['isdonated'])){
            $this->db->where("a.isdonated", $qs['isdonated']);
        }
        if($qs['cat_type']){
            $this->db->where("ac.type", $qs['cat_type']);
            if($qs['cat_type']==='Med/NonMed'){
                $this->db->where("a.stock>", 0);
            }
        }

        if($qs['k']){
            $this->db->group_start();
                $this->db->like("a.code", $qs['k'])->or_like("i.name", $qs['k']);
            $this->db->group_end();
        }
        if($qs['item_id']){
            $this->db->where("i.id", $qs['item_id']);
        }
        if($qs['functional_status']){
            $this->db->where("fs.id", $qs['functional_status']);
        }

        if($qs['station_point_ids'] && is_array($qs['station_point_ids'])){
            $this->db->where_in("sp.station_id", $qs['station_point_ids']);
            $this->db->join("assets_station_points sp", "a.id=sp.asset_id");
            $this->db->group_by("a.id");
        }

        $f="a.*, c.business_name client, i.name item, md.name model, i.asset_cat_id, i.asset_sub_cat_id, um.name uom, ac.name cat, 
        ac.type cat_type, sc.name subcat, m.name manufacture, sp.name service_provider, v.name vendor, fs.name functional_status_name";
        $this->db->select($f)
        ->from("assets a")
        ->join("clients c", "c.id=a.client_id")
        ->join("items i", "i.id=a.item_id")
        ->join("uoms um", "um.id=i.uom_id")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("service_providers sp", "sp.id=i.service_provider_id", "LEFT")
        ->join("vendors v", "v.id=i.vendor_id", "LEFT")
        ->join("mm_functional_status fs", "fs.id=a.functional_status", "LEFT")
        ->order_by("a.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['installation_date']=toDate($r['installation_date']);
            $r['procurement_date']=toDate($r['procurement_date']);

            $r['station_points']=$this->db->select("sp.id, sp.asset_id, sp.station_id, p.name station_point")
            ->from("assets_station_points sp")
            ->join("station_points p", "sp.station_id=p.id")
            ->where(['sp.asset_id'=>$r['id']])
            ->order_by("sp.id")
            ->get()
            ->result_array();
            $r['station_point_ids']=[];
            foreach($r['station_points'] as $s){
                $r['station_point_ids'][]=$s['station_id'];
            }

            $r['item_full_name']=$r['item'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }

            $r['stock']=(int)$r['stock'];
            $r['isdonated']=(int)$r['isdonated'];
        }
        return $rs;
    }

    function save($data, $cattype){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            if($cattype!=='Med/NonMed' && !$data['id']){
                $data['id']=$this->db->get_where("assets", ['item_id'=>$data['item_id'], 'client_id'=>CLIENT_ID])->row("id");
            }
            $asset_id=$this->dba->save("assets", $data);
            if(!$data['id']){
                $faccode=$this->db->select("fac_code")->get_where("clients", ['id'=>$data['client_id']])->row("fac_code");
                $code=$faccode.zeroFormatNo($asset_id, 8);
                $this->db->update("assets", ['code'=>$code], ['id'=>$asset_id]);
            }

            $this->db->delete("assets_station_points", ['asset_id'=>$asset_id]);
            if($data['station_point_ids']){
                foreach($data['station_point_ids'] as $sid){
                    $this->db->insert("assets_station_points", ['asset_id'=>$asset_id, 'station_id'=>$sid, 'created'=>currentDT()]);
                }
            }

            if(!$data['id'] || ($cattype!=='Med/NonMed' && $data['qty'])){
                $d=[
                    'asset_id'=>$asset_id,
                    'action_id'=>1,
                    'qty'=>$data['qty'],
                    'txn_date'=>currentDT(),
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->dba->save("stock_transactions", $d);
            }
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $asset_id;
        }
    }

    function detail($id=0, $item_id=0, $client_id=CLIENT_ID){
        if(!$id){
            $id=$this->db->select("id")->get_where("assets", ['item_id'=>(int)$item_id, 'client_id'=>$client_id])->row("id");
        }
        $dtl=$this->db->get_where("assets", ['id'=>(int)$id])->row_array();
        if($dtl){
            $dtl['cost']=(float)$dtl['cost'];
            $dtl['stock']=(float)$dtl['stock'];
        }
        return $dtl;
    }

    function deleteAsset($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("assets", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }
}

// EOF