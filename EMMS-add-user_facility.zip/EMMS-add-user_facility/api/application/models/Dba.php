<?php 
class Dba extends CI_Model {
	function pagedRows($pageno=1, $pagesize=25, $page_limit=5, $total_records='', $debug=FALSE){
		$pageno=intval($pageno);
		if(!$pageno){
			$pageno=1;
        }
        $pagesize=intval($pagesize);
        if(!$pagesize){
            $pagesize=25;
        }
		$limit=intval($pagesize);
		$offset=$limit*($pageno-1);
		
		$res=array('data'=>array(), 'page'=>array());
        
        $q=$this->db->get_compiled_select();
        if(strlen($total_records)>0){
            $q=str_replace("SQL_CALC_FOUND_ROWS", "", $q);
        }
        $res['data']=$this->db->query($q."\nLIMIT $offset, $limit")->result_array();
		
		/** Count **/
		if(strlen($total_records)==0){
			if(strpos($q, 'SQL_CALC_FOUND_ROWS')!==FALSE){
				$total_records=$this->db->select("FOUND_ROWS() AS n")->get()->row()->n;
			}else{
                $qArr=explode("\n", $q);
                
				$qaLastIndex=count($qArr)-1;
				if(strpos($qArr[$qaLastIndex], 'ORDER BY')!==FALSE){
					unset($qArr[$qaLastIndex]);
				}
				if(strpos($q, 'GROUP BY')!==FALSE){
					$qArr[0]="SELECT 1";
					$cq="SELECT COUNT(1) n FROM (".implode("\n", $qArr).") tmp";
				}else{
					$qArr[0]="SELECT COUNT(1) n";
					$cq=implode("\n", $qArr);
				}
				$total_records=(int)$this->db->query($cq)->row()->n;
			}
		}else{
			$total_records=(int)$total_records;
		}
		/** \ **/
		
		if($debug){
			pr($q); pr($cq); die;
		}
		
		/** Page Object **/
		$total=count($res['data']);
		if($total) {
            $res['page']['cur_page']=intval($pageno);
            $res['page']['total_records']=intval($total_records);
            $res['page']['total']=intval($total);
            $res['page']['total_pages']=ceil((float)$total_records/(float)$pagesize);
            $res['page']['start']=$offset;
			
			$start=1;
			$end=$res['page']['total_pages'];
			if($end>$page_limit){
				$end=$page_limit;
			}
		
			$half=round($page_limit / 2);
			if ($res['page']['cur_page'] > $half and $res['page']['total_pages'] > $page_limit) {
				$start = $res['page']['cur_page'] - $half + 1;
				$end = $page_limit + $res['page']['cur_page'] - $half;
				if ($end > $res['page']['total_pages']) {
					$start = $res['page']['total_pages'] - $page_limit + 1;
					$end = $res['page']['total_pages'];
				}
			}
			
			$res['page']['page_start']=$start;
			$res['page']['page_end']=$end;
        }
		/** \ **/
		
		return $res;
	}
	
	function insert($tbl, $data, $filter=TRUE, $debug=FALSE){
		if($filter){
			$info=$this->filterData($tbl, $data);
			if(!$info){
				return;
			}
			$this->db->insert($tbl, $info);
		}else{
			$this->db->insert($tbl, $data);
		}
		
        if($debug){
            echo $this->db->last_query(); die;
        }
        return $this->db->insert_id();
    }
	
	function update($tbl, $data, $cond, $filter=TRUE, $debug=FALSE){
		$this->db->where($cond, NULL, FALSE);
		if($filter){
			$info=$this->filterData($tbl, $data);
			if(!$info){
				return;
			}
			$this->db->update($tbl, $info);
		}else{
			$this->db->update($tbl, $data);
		}
		
        if($debug){
             echo $this->db->last_query(); die;
        }
        return $this->db->affected_rows();
    }
	
	function filterData($tbl, $data){
        $sql = "DESCRIBE " . $tbl . ";";
        if($list = $this->db->query($sql)->result_array()){
            $fields = array();
            foreach($list as $record){
            	$fields[] = $record['Field'];
			}
            $cols=array_values(array_intersect($fields, array_keys($data)));
			$info=array();
			if($cols){
				foreach($cols as $i=>$f){
					$info[$f]=$data[$f];
				}
			}
			return $info;
        }
        return array();
    }

    function save($tbl="", $data, $pKey='id'){
		$id=intval($data[$pKey]);
		unset($data[$pKey]);
        if($id){
            if(!isset($data['updated'])) $data['updated']=currentDT();
            if(!isset($data['updated_by'])) $data['updated_by']=USER_ID;
            if(!isset($data['modified'])) $data['modified']=currentDT();
            if(!isset($data['modified_by'])) $data['modified_by']=USER_ID;
            if(!$this->dba->update($tbl, $data, "$pKey='$id'")){
				return;
			}
        }else{
            if(!isset($data['created'])) $data['created']=currentDT();
            if(!isset($data['modified'])) $data['modified']=currentDT();
			if(!isset($data['created_by'])) $data['created_by']=USER_ID;
            if(!isset($data['modified_by'])) $data['modified_by']=USER_ID;
            if(!isset($data['updated'])) $data['updated']=currentDT();
            if(!isset($data['updated_by'])) $data['updated_by']=USER_ID;
            $id=$this->dba->insert($tbl, $data);
        }
        return $id;
    }

    /** */
    function mysqli(){
        return new mysqli($this->db->hostname, $this->db->username, $this->db->password, $this->db->database);
    }
}

//End of file