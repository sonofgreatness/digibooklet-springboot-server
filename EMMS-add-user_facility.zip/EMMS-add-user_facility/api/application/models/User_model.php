<?php 
class User_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function modules(){
        if(CLIENT_ID){
            if(!IS_NATIONAL_CLIENT){
                $this->db->where_in("m.is_national", 0);
            }
        }
        return $this->db->select('m.id, m.name, m.key')
        ->from('modules m')
        ->join("modules_group g", "g.id=m.group_id")
        ->where(['m.status'=>1])
        ->where_in('m.type', ['BOTH', CLIENT_ID?'CLIENT':'ADMIN'])
        ->get()
        ->result_array();
    }

    function roles($all=false){
        $qs=trimArray($this->input->get());
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("title", $qs['k']);
            $this->db->group_end();
        }

        if(CLIENT_ID){
            $this->db->where("client_id", CLIENT_ID);
        }

        $this->db->select("*")
        ->from("roles")
        ->where(['id>'=>2, 'type'=>CLIENT_ID?'CLIENT':'ADMIN'])
        ->order_by("id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];
            $r['is_system_defined']=(int)$r['is_system_defined'];
            $r['app_modules']=explode(",", $r['app_modules']);
        }
        return $rs;
    }

    function saveRole($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $role_id=$this->dba->save("roles", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $role_id;
        }
    }

    function deleteRole($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("roles", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }

    function users($all=false, $client_id=CLIENT_ID){
        $qs=trimArray($this->input->get());
        if($qs['k']){
            $this->db->group_start();
                $this->db->like("u.name", $qs['k']);
            $this->db->group_end();
        }

        if($client_id){
            $this->db->where("u.client_id", $client_id);
        }

        if(!$all){
            $this->db->where(['u.role_id>'=>2]);
        }else{
            $this->db->where(['u.role_id>'=>1]);
        }

        $this->db->select("u.*, r.title role")
        ->from("users u")
        ->join("roles r", "r.id=u.role_id")
        ->where(['u.type'=>$client_id?'CLIENT':'ADMIN'])
        ->order_by("id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }

        foreach($rs['data'] as &$r){
            $r['status']=(int)$r['status'];

            unset($r['password']);
        }
        return $rs;
    }

    function saveUser($data){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $role_id=$this->dba->save("users", $data);
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $role_id;
        }
    }

    function deleteUser($id){
        $this->db->db_debug=FALSE;
        $this->db->delete("users", ['id'=>$id]);
        return $this->db->affected_rows()>0;
    }
}

//End of file