<?php
class Stock_request_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }

    function lists($all=false, $isAllAccess=false, $ticket_id=0){
        $qs=trimArray($this->input->get());

        if($ticket_id){
            $this->db->where("r.ticket_id", $ticket_id);
        }

        if($qs['ids']){
            $this->db->where_in("r.id", explode(",", $qs['ids']));
        }

        if(IS_NATIONAL_CLIENT){
            $this->db->where("r.to_client_id", CLIENT_ID);
            if($qs['client_id']){
                $this->db->where("r.client_id", $qs['client_id']);
            }
        }else{
            $this->db->where("r.client_id", CLIENT_ID);
            if($qs['request_to']==='National'){
                $this->db->where("r.to_client_id!=r.client_id", NULL, FALSE);
            }else{
                $this->db->where("r.to_client_id", CLIENT_ID);
            }
        }

        if(!$isAllAccess){
            $this->db->where("r.created_by", USER_ID);
        }

        if($qs['k']){
            $this->db->group_start();
                $this->db->like("i.name", $qs['k']);
            $this->db->group_end();
        }
        if($qs['station_id']){
            $this->db->where("r.station_id", $qs['station_id']);
        }
        if($qs['status']){
            $this->db->where("r.status", $qs['status']);
        }
        if($qs['from_date']){
            $this->db->where("r.created>=", toDate($qs['from_date'], '', 'Y-m-d'));
        }
        if($qs['to_date']){
            $this->db->where("r.created<=", toDate($qs['to_date'], '', 'Y-m-d 23:59:59'));
        }

        $f="r.id, r.to_client_id, r.client_id, r.ticket_id, t.ticket_no, r.item_id, r.qty, r.issued_qty, r.action_on, r.status, r.created, r.created_by, 
            c.business_name client, i.name item, md.name model, i.asset_cat_id, i.asset_sub_cat_id, 
            ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacture, sp.name station_point,
            u1.name created_by_name, r1.title created_by_role, u2.name action_by_name, r2.title action_by_role";
        $this->db->select($f)
        ->from("stock_requests r")
        ->join("clients c", "c.id=r.client_id")
        ->join("station_points sp", "sp.id=r.station_id")
        ->join("items i", "i.id=r.item_id")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("tickets t", "t.id=r.ticket_id", "LEFT")
        ->join("users u1", "u1.id=r.created_by")
        ->join("roles r1", "r1.id=u1.role_id")
        ->join("users u2", "u2.id=r.action_by", "LEFT")
        ->join("roles r2", "r2.id=u2.role_id", "LEFT")
        ->order_by("r.id", "DESC");
        if($all){
            $rs['data']=$this->db->get()->result_array();
        }else{
            $rs=$this->dba->pagedRows($qs['p'], $qs['ps']);
        }
        foreach($rs['data'] as &$r){
            $r['item_full_name']=$r['item'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }

            $r['qty']=(float)$r['qty'];
            $r['issued_qty']=(float)$r['issued_qty'];

            $r['cancel_allowed']=0;
            if($r['created_by']===USER_ID){
                $r['cancel_allowed']=1;
            }
        }
        return $rs;
    }

    function detail($id){
        $f="r.id, r.to_client_id, r.client_id, r.ticket_id, r.item_id, r.station_id, r.qty, r.issued_qty, r.action_on, r.status, r.created, r.created_by, 
            c.business_name client, i.name item, md.name model, i.asset_cat_id, i.asset_sub_cat_id, 
            ac.name cat, ac.type cat_type, sc.name subcat, m.name manufacture, 
            u1.name created_by_name, r1.title created_by_role, u2.name action_by_name, r2.title action_by_role";
        $r=$this->db->select($f)
        ->from("stock_requests r")
        ->join("clients c", "c.id=r.client_id")
        ->join("items i", "i.id=r.item_id")
        ->join("assets_cats ac", "ac.id=i.asset_cat_id")
        ->join("assets_sub_cats sc", "sc.id=i.asset_sub_cat_id", "LEFT")
        ->join("models md", "md.id=i.model_id", "LEFT")
        ->join("manufacturers m", "m.id=i.manufacturer_id", "LEFT")
        ->join("users u1", "u1.id=r.created_by")
        ->join("roles r1", "r1.id=u1.role_id")
        ->join("users u2", "u2.id=r.action_by", "LEFT")
        ->join("roles r2", "r2.id=u2.role_id", "LEFT")
        ->where("r.id", (int)$id)
        ->get()
        ->row_array();
        
        if($r){
            $r['item_full_name']=$r['item'];
            if($r['model']){
                $r['item_full_name'].=' - '.$r['model'];
            }
            if($r['manufacturer']){
                $r['item_full_name'].=' - '.$r['manufacturer'];
            }

            $r['qty']=(float)$r['qty'];
            $r['issued_qty']=(float)$r['issued_qty'];

            $r['cancel_allowed']=0;
            if($r['created_by']===USER_ID){
                $r['cancel_allowed']=1;
            }
        }
        return $r;
    }

    function save($data, $ticket_id=0){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
        $req_ids=[];
		try{
            $d=[
                'client_id'=>CLIENT_ID,
                'to_client_id'=>$data['to_client_id']?$data['to_client_id']:CLIENT_ID,
                'station_id'=>$data['station_id'],
                'ticket_id'=>$ticket_id?$ticket_id:null
            ];
            foreach($data['items'] as $r){
                $d['item_id']=$r['id'];
                $d['qty']=$r['qty'];
                $req_ids[]=$this->dba->save("stock_requests", $d);
            }

            if($ticket_id){
                $d=[
                    'id'=>$ticket_id,
                    'status_id'=>2,
                ];
                $this->dba->save("tickets", $d);

                $statusname=$this->db->select("name")->get_where("mm_ticket_status", ['id'=>2])->row("name");
                $d=[
                    'ticket_id'=>$ticket_id,
                    'comment'=>"Spare parts requested and status changed to: $statusname",
                    'is_system_comment'=>1,
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->db->insert("ticket_comments", $d);
            }
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return $req_ids;
        }
    }

    function cancel($dtl){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'id'=>$dtl['id'],
                'action_by'=>USER_ID,
                'action_on'=>currentDT(),
                'status'=>'Cancelled'
            ];
            $this->dba->save("stock_requests", $d);

            if($dtl['ticket_id']){
                $d=[
                    'ticket_id'=>$dtl['ticket_id'],
                    'comment'=>"Spare parts requested cancelled",
                    'is_system_comment'=>1,
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->db->insert("ticket_comments", $d);
            }

		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }

    function issue($dtl, $adtl){
        $err=FALSE;
		$this->db->trans_strict(FALSE);
        $this->db->trans_begin();
		try{
            $d=[
                'id'=>$dtl['id'],
                'action_by'=>USER_ID,
                'issued_qty'=>$dtl['qty'],
                'action_on'=>currentDT(),
                'status'=>'Issued'
            ];
            $this->dba->save("stock_requests", $d);

            $d=[
                'asset_id'=>$adtl['id'],
                'stok_req_id'=>$dtl['id'],
                'action_id'=>$dtl['to_client_id']!==$dtl['client_id']?11:7,
                'qty'=>$dtl['qty']*-1,
                'txn_date'=>currentDT(),
                'created'=>currentDT(),
                'created_by'=>USER_ID
            ];
            $this->db->insert("stock_transactions", $d);

            if($dtl['to_client_id']!==$dtl['client_id']){
                $asset_id=$this->db->get_where("assets", ['item_id'=>$dtl['item_id'], 'client_id'=>$dtl['client_id']])->row("id");
                if(!$asset_id){
                    $data=[
                        'client_id'=>$dtl['client_id'],
                        'item_id'=>$dtl['item_id'],
                        'added_by_client_id'=>CLIENT_ID
                    ];
                    $asset_id=$this->dba->save("assets", $data);
                }
                $d=[
                    'asset_id'=>$asset_id,
                    'stok_req_id'=>$dtl['id'],
                    'action_id'=>10,
                    'qty'=>$dtl['qty'],
                    'txn_date'=>currentDT(),
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->dba->save("stock_transactions", $d);
            }

            if($dtl['ticket_id']){
                $d=[
                    'id'=>$dtl['ticket_id'],
                    'status_id'=>3,
                ];
                $this->dba->save("tickets", $d);
                $statusname=$this->db->select("name")->get_where("mm_ticket_status", ['id'=>3])->row("name");

                $d=[
                    'ticket_id'=>$dtl['ticket_id'],
                    'comment'=>"Spare parts issued and status changed to: $statusname",
                    'is_system_comment'=>1,
                    'created'=>currentDT(),
                    'created_by'=>USER_ID
                ];
                $this->db->insert("ticket_comments", $d);
            }
            
		}catch(Exception $e) {
            $err=TRUE;
            $msg=$e->getMessage();
        }
		
		if($this->db->trans_status()===FALSE) {
            $err=TRUE;
        }
		if($err){
            $this->db->trans_rollback();
			return FALSE;
        }else{
            $this->db->trans_commit();
			return TRUE;
        }
    }
}

// EOF