<?php
class Report extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("report_model", "report");
    }

    function stockTransactions($all=''){
        $this->checkAccess("view_reports");
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->report->stockTransactions($all==='ALL');
        jsonData($res);
    }
}

// EOF