<?php
class Common extends MY_Controller {
    function __construct() {
        parent::__construct();
    }

    function error404(){
        http_response_code(404);
        $this->load->view('layouts/error404');
    }
	
	function downloadFile($url, $filename=""){
		$this->load->helper('download');
		$url=decode($url);
		force_download($filename, @file_get_contents($url));
	}
	
	function bkpDb(){
		ini_set('memory_limit', '2048M');
		set_time_limit(3000);
		$this->load->dbutil();
		$backup=$this->dbutil->backup(['format'=>'gzip', 'foreign_key_checks'=>FALSE]);
		$this->load->helper('download');
		$fname="db_backup_".date('Y-m-d-H:i:s').".sql.gz";
		force_download($fname, $backup);
    }

	function test(){
		//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
		//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

		//echo $this->common->send_email("sat.web1989@gmail.com", "Hi, Welcome to ELMIS", "Registration Completed");
		//echo $this->common->send_email("satyendrayadav1989@gmail.com", "Hi, Welcome to ELMIS", "Registration Completed");
	}
}

//EOF