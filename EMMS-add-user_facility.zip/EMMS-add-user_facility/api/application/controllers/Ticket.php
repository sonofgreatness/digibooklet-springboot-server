<?php
class Ticket extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model("ticket_model", "ticket");
    }

    function lists($flg=''){
        $this->checkAccess(['view_tickets', 'view_tickets_self']);
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->ticket->lists($flg==='ALL', $this->isAccess('view_tickets'));
        if($flg==='getAssignedToUsers'){
            $res['assigned_users']=$this->ticket->assignedUsers();
        }
        jsonData($res);
    }

    function save(){
        $this->checkAccess('add_ticket');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('type', 'Type', "required", $this->req);
        $this->form_validation->set_rules('station_id', 'Station point', "required", $this->req);
        if($post['type']==='Med/NonMed'){
            $this->form_validation->set_rules('asset_id', 'Asset', "required", $this->req);
            $post['asset_sub_cat_id']=NULL;
        }else{
            $this->form_validation->set_rules('asset_sub_cat_id', 'Infrastructure type', "required", $this->req);
            $post['asset_id']=NULL;
        }

        $this->form_validation->set_rules('subject', 'Subject', "required", $this->req);
        //$this->form_validation->set_rules('description', 'Description', "required", $this->req);

        try{
            if($id){
                $dtl=$this->db->select("status_id")->get_where("tickets", ['id'=>$id])->row_array();
                if((int)$dtl['status_id']>1){
                    throw new Exception("Only OPEN job card can be updated.");
                }
            }

            if(@$this->form_validation->run()==FALSE){
                $res['errors']=$this->form_validation->get_errors();
                $res['message']=reset($res['errors']);
            } else {
                $data=filterValue($post, ['id', 'type', 'station_id', 'asset_id', 'asset_sub_cat_id', 'subject', 'description']);
                if(!$data['id']){
                    $data['client_id']=CLIENT_ID;
                }
                if($this->ticket->save($data)){
                    $res['code']=SCODE;
                    $res['message']='Job card created successfully';
                }
            }
        } catch (Exception $e){
            $res['message']=$e->getMessage();
        }
        jsonData($res);
    }

    function detail($id=0){
        $this->checkAccess(['view_tickets', 'view_tickets_self']);
        $id=(int)$id;
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->ticket->detail($id);
        jsonData($res);
    }

    function comments($ticket_id=0){
        $ticket_id=(int)$ticket_id;
        $res=['code'=>SCODE, 'message'=>''];
        $res['result']=$this->ticket->comments($ticket_id);
        jsonData($res);
    }

    function assign(){
        $this->checkAccess('ticket_actions');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        $user_id=(int)$post['user_id'];
        if(!$id || !$user_id){
            jsonData($res);
        }

        if($this->ticket->assign($id, $user_id)){
            $this->common->sendTicketAssignedNoti($id, $user_id);

            $res['code']=SCODE;
            $res['message']='Job card assigned successfully';
        }
        jsonData($res);
    }

    function addComment(){
        //$this->checkAccess('ticket_actions');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        $comment=trim($post['comment']);
        if(!$comment){
            $res['message']="Comment required!";
            jsonData($res);
        }

        if($this->ticket->addComment($id, $comment)){
            $res['code']=SCODE;
            $res['message']='Comment added successfully';
        }
        jsonData($res);
    }

    function changeStatus(){
        //$this->checkAccess('ticket_actions');
        $this->checkAccess('ticket_status_change');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        $status_id=(int)$post['status_id'];
        if(!$id || !$status_id){
            jsonData($res);
        }

        if($this->ticket->changeStatus($id, $status_id)){
            if($status_id===4){
                $this->common->sendTicketCompletedNoti($id);
            }
            if($status_id===5){
                $this->common->sendTicketClosedNoti($id);
            }

            $res['code']=SCODE;
            $res['message']='Job card status changed successfully';
        }
        jsonData($res);
    }

    function markAsRepairNotInScope(){
        $this->checkAccess('ticket_actions');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];

        if($this->ticket->markAsRepairNotInScope($id)){
            $res['code']=SCODE;
            $res['message']='Job card marked as Repair Not In Scope';
        }
        jsonData($res);
    }

    function markAsRepairInScope(){
        $this->checkAccess('ticket_actions');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];

        if($this->ticket->markAsRepairInScope($id)){
            $res['code']=SCODE;
            $res['message']='Job card marked as Repair In Scope';
        }
        jsonData($res);
    }

    function uploadCommentPhoto(){
        $this->checkAccess('ticket_actions');
        $res=['code'=>ECODE, 'message'=>'Error!'];
        $post=trimArray($this->input->post());
        $id=(int)$post['id'];
        $file_id=(int)$post['file_id'];

        if($this->ticket->uploadCommentPhoto($id, $file_id)){
            $res['code']=SCODE;
            $res['message']='Photo uploaded successfully';
        }
        jsonData($res);
    }
}

// EOF