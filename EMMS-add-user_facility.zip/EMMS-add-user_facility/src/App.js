/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { BrowserRouter } from 'react-router-dom';
import Routes from "./Routes";
import { sdx } from "./sdx";
import './App.css';

function App() {
    const [state, changeState] = useState(false);
    sdx.changeState = () => {
        changeState(!state);
    }

    const init = () => {
    }

    useEffect(() => {
        init();
    }, []);

    return (
        <React.Fragment>
            <BrowserRouter basename={"/assets/web/build/"}>
                <Routes></Routes>
            </BrowserRouter>
        </React.Fragment>
    );
}

export default App;