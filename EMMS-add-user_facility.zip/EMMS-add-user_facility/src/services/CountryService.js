import axios from "../utils/axios";

class CountryService{
    all(){
        return axios.get("countries");
    }
}

export default new CountryService();