/* eslint-disable import/no-anonymous-default-export */
import axios from "../utils/axios";

class NotificationService {
    all() {
        return axios.get("notifications");
    }
    read(id) {
        return axios.post("notificationRead", { id });
    }
}

export default new NotificationService();