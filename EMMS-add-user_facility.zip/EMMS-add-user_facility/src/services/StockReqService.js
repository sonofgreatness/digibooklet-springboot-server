import axios from "../utils/axios";

class StockReqService{
    lists(params){
        return axios.get("stockRequests", {params});
    }
    ticketStockRequests(ticket_id){
        return axios.get(`ticketStockRequests/${ticket_id}`);
    }
    save(data){
        return axios.post("saveStockRequest", data);
    }
    cancel(id){
        return axios.post("cancelStockRequest", {id});
    }
    issue(id){
        return axios.post("issueStockRequest", {id});
    }
}

export default new StockReqService();