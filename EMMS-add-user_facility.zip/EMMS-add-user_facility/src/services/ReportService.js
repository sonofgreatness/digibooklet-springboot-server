import axios from "../utils/axios";

class ReportService{
    stockTransactions(params){
        return axios.get("stockTransactionsReport", {params});
    }
    stockTransactionsAll(params){
        return axios.get("stockTransactionsReport/ALL", {params});
    }
}

export default new ReportService();