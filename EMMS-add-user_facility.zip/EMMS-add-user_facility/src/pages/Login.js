/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect, useRef} from 'react';
import {useHistory} from "react-router-dom";
import Auth from "../services/AuthService";
import util from "../utils/util";
import {
    Input,
    Button,
    message
} from 'antd';
import {
    UserOutlined, 
    LockOutlined, 
    EyeInvisibleOutlined, 
    EyeTwoTone
} from '@ant-design/icons';

export default function Login(){
    const history=useHistory();
    const isMount=useRef(true);
    const [values, setValues]=useState({});
    const [loading, setLoading]=useState(false);

    const login=(e)=>{
        if(e)e.preventDefault();
        message.destroy();
        setLoading(true);
        Auth.login(values).then(({data})=>{
            util.setLoginInfoLocalStorage(data.token, data.name, data.modules, data.type, data.is_national, data.is_client_admin, data.is_admin);
            history.push('/dashboard');
        }).catch(e=>{
            message.error(e.message);
        }).finally(()=>{
            if(isMount){
                setLoading(false);
            }
        })
    }

    useEffect(()=>{
        return ()=>{isMount.current=false}
    }, []);

    return(
        <div className="login parent h-100 login-bg">
            <div className="logo mb-0">
                <img src="assets/img/elogo.png" width="150" alt="" className="rounded" />
                {/* <h2 className="m-0 font-green-sharp">ASSETS MANAGEMENT</h2> */}
            </div>
            <div className="content" style={{width:'420px'}}>
                <div className="">
                    <h4 className="text-center bold500 font-green uc" style1={{textShadow:'1px 1px #fff'}}>Eswatini Asset Management System</h4>
                    <form onSubmit={login} autoComplete="off" spellCheck="false">
                        <div className="form-group pt20">
                            <Input 
                                placeholder="Username" 
                                prefix={<UserOutlined className="site-form-item-icon" />} 
                                autoFocus
                                value={values.username || ''}
                                onChange={e=>setValues({...values, username:e.target.value})}
                            />
                        </div>
                    
                        <div className="form-group">
                            <Input.Password 
                                placeholder="Password" 
                                prefix={<LockOutlined className="site-form-item-icon" />} 
                                iconRender={visible => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
                                value={values.password || ''}
                                onChange={e=>setValues({...values, password:e.target.value})}
                            />
                        </div>
                    
                        <div className="form-actions">
                            <Button type="primary" block loading={loading} htmlType="submit">Login</Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}