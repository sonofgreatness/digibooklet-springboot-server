/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import FacilityService from "../services/FacilityService";
import { If, PositiveNumInput } from "../utils/Controls";
import { AntdPaging, AntdSelect, AntdTag, MultiChechBox } from "../utils/Antd";
import AssetService from '../services/AssetService';
import util from "../utils/util";
import {
    Input,
    Button,
    message,
    Modal,
    Checkbox,
    Tag,
    Card
} from 'antd';
import {
    ExclamationCircleOutlined,
} from '@ant-design/icons';
const { confirm } = Modal;

export default function Facilities() {
    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25 });
    const formRef = useRef();
    const configRef = useRef();
    const [stationPoints, setStationPoints] = useState([]);
    const [assetCats, setAssetCats] = useState([]);

    const list = (p, ps) => {
        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        util.showLoader();
        FacilityService.list(sdataRef.current).then(({ data }) => {
            setResult(data.result);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const deleteRecord = (id) => {
        message.destroy();
        confirm({
            title: 'Do you Want to delete this facility?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                FacilityService.delete(id).then(({ data }) => {
                    message.success(data.message || 'Deleted');
                    list();
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    useEffect(() => {
        list();
        FacilityService.allStationPoints({ status: 1 }).then(res => {
            setStationPoints(res.data.result.data.sort((a, b) => ('' + a.name).localeCompare(b.name)));
        })
        AssetService.allCats({ status: 1 }).then(res => setAssetCats(res.data.result.data))
        return () => { message.destroy() }
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Facilities</h2>
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="d-flex tbl-search-head">
                    <div className="my-auto">
                        <SearchForm dataRef={sdataRef} onSearch={list} />
                    </div>
                    <div className="ml-auto my-auto">
                        <Button type="primary" onClick={() => formRef.current.openForm()}><i className="fa fa-plus mr5"></i> Add</Button>
                    </div>
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-md table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid">
                                <tr>
                                    <th className="w20">SN</th>
                                    <th>Facility/Site</th>
                                    <th className="w300">Asset Category</th>
                                    <th className="w150">Admin Name</th>
                                    <th className="w60">Status</th>
                                    <th className="w60"></th>
                                    <th className="w70"></th>
                                </tr>
                            </thead>
                            <tbody className="table-text-top">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{result.page.start + i + 1}.</td>
                                        {/* <td>
                                            <If cond={v.logo_url}>
                                                <img src={v.logo_url} className="mw-100 mt3" alt="" />
                                            </If>
                                        </td> */}
                                        <td>
                                            {v.business_name}
                                            <div className="note-text pt3">
                                                <div className="d-flex">
                                                    <div className="w80">Site Code</div>
                                                    <div className="bold600 pl5">: {v.site_code}</div>
                                                </div>
                                                <div className="d-flex">
                                                    <div className="w80">Facility Code</div>
                                                    <div className="bold600 pl5">: {v.fac_code}</div>
                                                </div>
                                                <div className="d-flex">
                                                    <div className="w80">Facility Owner</div>
                                                    <div className="bold600 pl5">: {v.facility_owner || 'N/A'}</div>
                                                </div>
                                                <div className="d-flex">
                                                    <div className="w80">Site Type</div>
                                                    <div className="bold600 pl5">: {v.site_type || 'N/A'}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            {assetCats.map((r) => {
                                                if (v.asset_cat_ids?.split(',').includes(r.id)) {
                                                    let color = "magenta";
                                                    color = r.name === 'Medical' ? 'green' : (r.name === 'Non Medical' ? 'purple' : 'gold')
                                                    return <Tag key={r.id} color={color}>{r.name}</Tag>
                                                } else {
                                                    return null;
                                                }
                                            })}
                                        </td>
                                        <td>
                                            {v.name}
                                            <div className="note-text">({v.email})</div>
                                        </td>
                                        <td className="nowrap">
                                            {v.status ? (<AntdTag type="success">Active</AntdTag>) : (<AntdTag type="danger">Inactive</AntdTag>)}
                                        </td>
                                        <td className="text-center">
                                            {/* <Button.Group size="small">
                                                <Button type="primary" onClick={() => configRef.current.openForm(v.id, v.business_name)}>Station Points</Button>
                                            </Button.Group> */}
                                            <button type="button" className="btn btn-sm btn-primary nowrap" onClick={() => configRef.current.openForm(v.id, v.business_name)}>
                                                Station Points <span className="badge badge-warning">{v.station_points_count}</span>
                                            </button>
                                        </td>
                                        <td className="text-center">
                                            <Button.Group size="small">
                                                <Button type="default" onClick={() => formRef.current.openForm(v)}>
                                                    <i className="fa fa-edit"></i>
                                                </Button>
                                                <Button type="default" onClick={() => deleteRecord(v.id)} disabled={util.getUserType() !== 'ADMIN' && v.is_national * 1}>
                                                    <i className="fa fa-times-circle font-red"></i>
                                                </Button>
                                            </Button.Group>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>

            <AddForm
                ref={formRef}
                callback={list}
                pageno={sdataRef.current.p}
                assetCats={assetCats}
            />
            <ConfigForm
                ref={configRef}
                callback={list}
                pageno={sdataRef.current.p}
                stationPoints={stationPoints}
            />
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch } = props;
    let [data, setData] = useState({ ...dataRef.current });
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    useEffect(() => {
        dataRef.current = { ...data };
    }, [data]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                <div>
                    <Input placeholder="Search" allowClear value={data.k} onChange={e => handleChange(e.target.value, 'k')} />
                </div>
                <div>
                    <Button type="primary" icon={<i className="fa fa-search fs13"></i>} onClick={() => onSearch()}></Button>
                </div>
            </div>
        </form>
    )
}

const AddForm = forwardRef((props, ref) => {
    let { callback, pageno, assetCats } = props;
    const [showForm, setShowForm] = useState(false);
    let [data, setData] = useState({});
    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    const save = () => {
        message.destroy();
        util.showLoader();
        FacilityService.save(data).then(({ data }) => {
            message.success(data.message || 'Saved');
            callback(data.id ? pageno : 1);
            setShowForm(false);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }
    const closeForm = () => {
        setShowForm(false);
    }

    useImperativeHandle(ref, () => ({
        openForm(dtl) {
            setData(dtl ? { ...dtl } : { is_national: '0', status: '1' });
            setShowForm(true);
        }
    }));

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Add'} Facility`}
            visible={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={1000}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                {util.getUserType() === 'ADMIN' &&
                    <div className="row mingap">
                        <div className="col-md-3 form-group">
                            <label>Is National?</label>
                            <div>
                                <AntdSelect
                                    options={[{ value: '0', label: "No" }, { value: '1', label: "Yes" }]}
                                    value={data.is_national}
                                    onChange={v => { handleChange(v, 'is_national') }}
                                />
                            </div>
                        </div>
                    </div>
                }

                <div className="mb15">
                    <Card size="small" type="inner" title="Facility Detail">
                        <div className="">
                            <div className="row mingap">
                                <div className="col-md-3 form-group">
                                    <label className="req">Site Code</label>
                                    <Input value={data.site_code || ''} onChange={e => handleChange(e.target.value, 'site_code')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="req">Facility Code</label>
                                    <Input value={data.fac_code || ''} onChange={e => handleChange(e.target.value, 'fac_code')} />
                                </div>
                                <div className="col-md-6 form-group">
                                    <label className="req">Facility/Site Name</label>
                                    <Input value={data.business_name || ''} onChange={e => handleChange(e.target.value, 'business_name')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="">Facility Owner</label>
                                    <Input value={data.facility_owner || ''} onChange={e => handleChange(e.target.value, 'facility_owner')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="">Site Type</label>
                                    <Input value={data.site_type || ''} onChange={e => handleChange(e.target.value, 'site_type')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="req">Facility Phone</label>
                                    <Input value={data.phone1 || ''} onChange={e => handleChange(e.target.value, 'phone1')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="">Located In Region</label>
                                    <Input value={data.located_region || ''} onChange={e => handleChange(e.target.value, 'located_region')} />
                                </div>
                                <div className="col-md-12 form-group">
                                    <label className="req">Facility Address</label>
                                    <Input value={data.address || ''} onChange={e => handleChange(e.target.value, 'address')} />
                                </div>

                                <div className="col-md-3 form-group">
                                    <label className="">City</label>
                                    <Input value={data.city || ''} onChange={e => handleChange(e.target.value, 'city')} />
                                </div>
                                {/* <div className="col-md-3 form-group">
                                    <label className="req">State</label>
                                    <Input value={data.state || ''} onChange={e => handleChange(e.target.value, 'state')} />
                                </div> */}
                                <div className="col-md-3 form-group">
                                    <label className="">Pincode</label>
                                    <Input value={data.pincode || ''} onChange={e => handleChange(e.target.value, 'pincode')} />
                                </div>

                                <div className="col-md-3 form-group">
                                    <label className="">Latitude</label>
                                    <Input type="number" value={data.latitude || ''} onChange={e => handleChange(e.target.value, 'latitude')} />
                                </div>
                                <div className="col-md-3 form-group">
                                    <label className="">Longitude</label>
                                    <Input type="number" value={data.longitude || ''} onChange={e => handleChange(e.target.value, 'longitude')} />
                                </div>
                            </div>

                            <div>
                                <label className="req">Asset Category</label>
                                <div className="form-control">
                                    <MultiChechBox value={data.asset_cat_ids} options={assetCats} onChange={v => handleChange(v, 'asset_cat_ids')} />
                                </div>
                            </div>
                        </div>
                    </Card>
                </div>

                <div className="mb15">
                    <Card size="small" type="inner" title="Admin User Detail">
                        <div className="row mingap">
                            <div className="col-md-4 form-group">
                                <label className="req">Name</label>
                                <Input value={data.name || ''} onChange={e => handleChange(e.target.value, 'name')} />
                            </div>
                            <div className="col-md-4 form-group">
                                <label className="req">Email</label>
                                <Input value={data.email || ''} onChange={e => handleChange(e.target.value, 'email')} />
                            </div>
                            <div className="col-md-4 form-group">
                                <label className="req">Mobile</label>
                                <PositiveNumInput className="form-control" value={data.mobile || ''} onChange={v => handleChange(v, 'mobile')} type="int" maxLength="10" />
                            </div>
                            <div className="col-md-4 form-group">
                                <label className="req">
                                    Username
                                </label>
                                <Input value={data.username || ''} onChange={e => handleChange(e.target.value, 'username')} />
                            </div>
                            <div className="col-md-4 form-group">
                                <label className="">Password</label>
                                <Input value={data.password || ''} onChange={e => handleChange(e.target.value, 'password')} />
                            </div>
                        </div>
                    </Card>
                </div>

                <div className="row mingap">
                    <div className="col-md-3 form-group">
                        <label className="req">Status</label>
                        <div>
                            <AntdSelect
                                options={[{ value: '1', label: "Active" }, { value: '0', label: "Inactive" }]}
                                value={data.status}
                                onChange={v => { handleChange(v, 'status') }}
                            />
                        </div>
                    </div>
                </div>
            </form>
        </Modal>
    )
})

const ConfigForm = forwardRef((props, ref) => {
    let { stationPoints, callback, pageno } = props;
    const [clientDtl, setClientDtl] = useState({});
    const [showForm, setShowForm] = useState(false);
    const [data, setData] = useState([]);

    const save = () => {
        message.destroy();
        util.showLoader();
        FacilityService.saveConfig({ clientId: clientDtl.id, data: data.join() }).then(({ data }) => {
            message.success(data.message || 'Saved');
            setShowForm(false);
            callback(data.id ? pageno : 1);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const closeForm = () => {
        setShowForm(false);
    }

    useImperativeHandle(ref, () => ({
        openForm(id, name) {
            FacilityService.allStationPoints({ client_id: id }).then(res => {
                setData(res.data.result.data.map((v) => v.id));
            });
            setShowForm(true);
            setClientDtl({ id, name });
        }
    }));

    return (
        <Modal
            title={<div>Station Points - <span className="text-secondary">{clientDtl.name}</span></div>}
            open={showForm}
            okText="Save"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={1200}
            style={{ top: 20 }}
            bodyStyle={{ height: 'calc(100vh - 150px)' }}
        >
            <form onSubmit={e => { e.preventDefault(); save() }} autoComplete="off" spellCheck="false">
                <div className="form-group noselect">
                    <div className="row mingap">
                        {stationPoints.map((v, i) => (
                            <div key={i} className="col-md-3 mt5">
                                <div className="form-control">
                                    <Checkbox
                                        checked={data.includes(v.id)}
                                        onChange={e => {
                                            let dt = [...data];
                                            if (e.target.checked) {
                                                dt.push(v.id);
                                            } else {
                                                dt.splice(dt.indexOf(v.id), 1);
                                            }
                                            setData(dt);
                                        }}
                                    >
                                        {v.name}
                                    </Checkbox>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </form>
        </Modal >
    )
})