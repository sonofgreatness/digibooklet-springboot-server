/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import TransferService from "../../services/TransferService";
import AssetService from "../../services/AssetService";
import FacilityService from "../../services/FacilityService";
import { If } from "../../utils/Controls";
import { AntdPaging, AntdSelect, AntdTag, AntdDatepicker } from "../../utils/Antd";
import util from "../../utils/util";
import moment from "moment";
import {
    //Input,
    Button,
    message,
    Tabs,
    Modal,
    Menu,
    Dropdown
} from 'antd';
import {
    ExclamationCircleOutlined,
    MoreOutlined
} from '@ant-design/icons';
const { confirm } = Modal;


export default function TransferIn() {
    const [clients, setClients] = useState([]);
    const [tab, setTab] = useState('Med/NonMed');

    const onTabChange = (key) => {
        setTab(key);
    }

    useEffect(() => {
        FacilityService.all({ status: 1, include_me: 'Y' }).then(res => {
            let allClients = res.data.result.data.map(v => { return { id: v.id, name: v.business_name, is_national: v.is_national, is_me: v.is_me } });
            setClients(allClients);
        });
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Transfer In</h2>
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                <Tabs
                    activeKey={tab}
                    destroyInactiveTabPane
                    onChange={onTabChange}
                    items={[{ k: 'Med/NonMed', v: 'Med/NonMed Assets' }, { k: 'Infrastructure', v: 'Infrastructure' }].map(rw => ({
                        key: rw.k,
                        label: rw.v,
                        children: (
                            <List
                                clients={clients}
                                cat_type={rw.k}
                            />
                        )
                    }))}
                />
                {/* <Tabs activeKey={tab} onChange={onTabChange}>
                    {[{k:'Med/NonMed', v:'Med/NonMed Assets'}, {k:'Infrastructure', v:'Infrastructure'}].map(rw=>(
                        <TabsTabPane tab={rw.v} key={rw.k}>
                            {rw.k===tab && 
                                <List 
                                    clients={clients}
                                    items={items}
                                    cat_type={rw.k}
                                />
                            }
                        </TabsTabPane>
                    ))}
                </Tabs> */}
            </div>
        </div>
    )
}

function List(props) {
    const [result, setResult] = useState({ data: [], page: {} });
    const sdataRef = useRef({ p: 1, ps: 25 });
    const [clients, setClients] = useState([]);
    const modules = util.getModules();

    const list = (p, ps) => {
        const ids = new URLSearchParams(window.location.search).get('ids');
        sdataRef.current.p = p || 1;
        sdataRef.current.ps = ps || sdataRef.current.ps;
        sdataRef.current.cat_type = props.cat_type;
        sdataRef.current.ids = ids || '';
        util.showLoader();
        TransferService.transferIns(sdataRef.current).then(({ data }) => {
            setResult({ ...data.result });
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const receiveTransfer = (id, status) => {
        if (status !== 'Dispatched') {
            return;
        }
        message.destroy();
        confirm({
            title: 'Are you sure to receive this stock?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                TransferService.receiveTransfer(id).then(({ data }) => {
                    message.success(data.message || 'Deleted');
                    list(sdataRef.current.p);
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    const cancelTransfer = (id, status) => {
        if (status !== 'Dispatched') {
            return;
        }
        message.destroy();
        confirm({
            title: 'Are you sure to cancel this receiving?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                TransferService.cancelTransfer(id).then(({ data }) => {
                    message.success(data.message || 'Cancelled');
                    list(sdataRef.current.p);
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    useEffect(() => {
        setClients(props.clients);
    }, [props.clients]);

    useEffect(() => {
        list();

        return () => { message.destroy() }
    }, []);

    return (
        <div className="">
            <div className="">
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="d-flex tbl-search-head">
                    <div className="my-auto flex-grow-1">
                        <SearchForm dataRef={sdataRef} onSearch={list} clients={clients} cat_type={props.cat_type} />
                    </div>
                    <div className="ml-auto my-auto">
                    </div>
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm font-xs table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid">
                                <tr>
                                    <th className="w20">SN</th>
                                    <th className="w120">Transfer From</th>
                                    <th className="w80">Asset Code</th>
                                    <th>Item</th>
                                    <th className="w100">Model</th>
                                    {props.cat_type === 'Med/NonMed' &&
                                        <th className="w100">Serial No</th>
                                    }
                                    <th className="w100">Manufacturer</th>
                                    {props.cat_type !== 'Med/NonMed' &&
                                        <th className="w80 text-right">QTY</th>
                                    }

                                    <th className="w90">Transfer On</th>
                                    <th className="w60">Status</th>

                                    {modules['receive_stock'] === 1 && <th className="w30"></th>}
                                </tr>
                            </thead>
                            <tbody className="table-text-top font-sm">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{result.page.start + i + 1}.</td>
                                        <td>{v.transfer_from_name}</td>
                                        <td>{v.asset_code}</td>
                                        <td>
                                            <div className="uc bold600">{v.item}</div>
                                            <div className="pt3 note-text">
                                                <div className="d-flex"><div className="w80">Category</div> : <div className="bold600 pl5">{v.cat}</div></div>
                                                {v.subcat &&
                                                    <div className="d-flex"><div className="w80">Sub-Category</div> : <div className="bold600 pl5">{v.subcat}</div></div>
                                                }
                                            </div>
                                        </td>
                                        <td>{v.model}</td>
                                        {props.cat_type === 'Med/NonMed' &&
                                            <td>{v.serial_no}</td>
                                        }
                                        <td>{v.manufacture}</td>
                                        {props.cat_type !== 'Med/NonMed' &&
                                            <td className="text-right">{v.qty}</td>
                                        }

                                        <td>
                                            <div className="nowrap">{util.getDate(v.transfer_date, 'DD MMM YYYY')}</div>
                                        </td>

                                        <td className="nowrap">
                                            <AntdTag type={v.trstatus === 'Dispatched' ? 'info' : (v.trstatus === 'Received' ? 'success' : 'danger')}>{v.trstatus}</AntdTag>
                                        </td>

                                        {modules['receive_stock'] === 1 &&
                                            <td className="nowrap text-center">
                                                <Dropdown
                                                    trigger={['click']}
                                                    overlay={
                                                        <Menu>
                                                            <Menu.Item key="0" disabled={v.trstatus !== 'Dispatched'}>
                                                                <span onClick={() => receiveTransfer(v.id, v.trstatus)}>Receive</span>
                                                            </Menu.Item>
                                                            <Menu.Item key="1" disabled={v.trstatus !== 'Dispatched'}>
                                                                <span onClick={() => cancelTransfer(v.id, v.trstatus)}>Cancel Receiving</span>
                                                            </Menu.Item>
                                                        </Menu>
                                                    }
                                                >
                                                    <span className="ant-dropdown-link cpointer fs18" onClick={e => e.preventDefault()} style={{ lineHeight: '18px' }}>
                                                        <MoreOutlined />
                                                    </span>
                                                </Dropdown>

                                                {/* <Button.Group size="small">
                                                <Button type="primary" disabled={v.trstatus!=='Dispatched'} onClick={()=>receiveTransfer(v.id)}>Receive</Button>
                                                <Button type="danger">Cancel</Button>
                                            </Button.Group> */}
                                            </td>}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>
        </div>
    )
}

const SearchForm = (props) => {
    let { dataRef, onSearch, cat_type, clients } = props;
    let [data, setData] = useState({ ...dataRef.current });
    const [items, setItems] = useState([]);
    const isNational = util.isNational();

    const handleChange = (v, k) => {
        data[k] = v;
        setData({ ...data });
    }
    useEffect(() => {
        let prevClientId = dataRef.current.client_id;
        dataRef.current = { ...data };
        if (isNational) {
            if (prevClientId !== data.client_id) {
                onSearch();
            }
        }
    }, [data]);

    useEffect(() => {
        if (isNational) {
            let ob = clients.find(v => v.is_me);
            setData({ ...data, client_id: ob?.id });
        }
    }, [clients]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    useEffect(() => {
        AssetService.allItems({ status: 1, cat_type, client_id: data.client_id, availableAssetsOnly: 'Y', transferType: 'IN' }).then(res => {
            let allItems = [];
            allItems = res.data.result.data.map((v) => {
                if (v.cat_type === 'Med/NonMed') {
                    v.item_full_name = v.item_full_name + ' [' + v.cat + ']';
                } else {
                    v.item_full_name = v.item_full_name + ' [' + v.subcat + ']';
                }
                return v;
            });
            setItems(allItems);
        });
    }, [cat_type, data.client_id]);

    return (
        <form onSubmit={e => e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                {isNational === 1 &&
                    <div className="w150 mr5">
                        <div className="text-secondary fs11 mb2">Transfer To Facility</div>
                        <AntdSelect
                            placeholder="Facility"
                            showSearch
                            options={clients}
                            value={data.client_id}
                            onChange={v => handleChange(v, 'client_id')}
                        />
                    </div>
                }

                <div className="w150 mr5">
                    {/* <Input size="small" placeholder="Search" allowClear value={data.k} onChange={e => handleChange(e.target.value, 'k')} /> */}
                    <div className="text-secondary fs11 mb2">Status</div>
                    <AntdSelect
                        placeholder="Status (All)"
                        allowClear
                        showSearch
                        options={['Dispatched', 'Received', 'Cancelled']}
                        value={data.status}
                        onChange={v => handleChange(v, 'status')}
                    />
                </div>
                <div className="flex-grow-1 mr5">
                    <div className="text-secondary fs11 mb2">Item</div>
                    <AntdSelect
                        placeholder="Item (All)"
                        allowClear
                        showSearch
                        options={items.map(v => { return { id: v.id, name: v.item_full_name } })}
                        value={data.item_id}
                        onChange={v => handleChange(v, 'item_id')}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">From Date</div>
                    <AntdDatepicker
                        placeholder="From Date"
                        allowClear
                        value={data.from_date}
                        onChange={v => {
                            if (data.to_date && moment(v) > moment(data.to_date)) {
                                message.error("From date should be less than or equal to To Date");
                                v = null;
                            }
                            handleChange(v, 'from_date');
                        }}
                    />
                </div>

                <div className="w130 mr5">
                    <div className="text-secondary fs11 mb2">To Date</div>
                    <AntdDatepicker
                        placeholder="To Date"
                        allowClear
                        value={data.to_date}
                        onChange={v => {
                            if (data.from_date && moment(v) < moment(data.from_date)) {
                                message.error("To date should be greater than or equal to From Date");
                                v = null;
                            }
                            handleChange(v, 'to_date');
                        }}
                    />
                </div>

                <div className="pt15">
                    <Button className="mt4" type="primary" onClick={() => onSearch()}><i className="fa fa-search fs13"></i></Button>
                </div>
            </div>
        </form>
    )
}