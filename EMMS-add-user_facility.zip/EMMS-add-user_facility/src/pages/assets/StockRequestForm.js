/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect} from 'react';
import {AntdSelect} from "../../utils/Antd";
import util from "../../utils/util";
import AssetService from "../../services/AssetService";
import FacilityService from "../../services/FacilityService";
import StockReqService from '../../services/StockReqService';

import {
    Input,
    Button,
    message,
    Modal,
} from 'antd';

export default function StockRequestForm(props){
    const {refOb, ticket_id, callback}=props;
    const [isFormOpen, setFormOpen]=useState(false);
    const [items, setItems]=useState([]);
    const [stationPoints, setStationPoints]=useState([]);
    const [data, setData]=useState({items:[]});
    const modules=util.getModules();

    const handleChange=(v, k)=>{
        data[k]=v;
        setData({...data});
    }

    const closeForm=()=>{
        setFormOpen(false);
    }

    const addNewItem=(itemId)=>{
        let idtl=items.find(item=>item.id===itemId);
        if(!idtl){
            return;
        }
        setData({...data, items: [...data.items, {id:idtl.id, item:idtl.item_full_name, cat:idtl.cat, subcat:idtl.subcat, qty:1, stock:idtl.stock}]})
    }

    const isItemAdded=(itemId)=>{
        let idtl=data.items.find(item=>item.id===itemId);
        return idtl?true:false;
    }

    const save=()=>{
        message.destroy();
        util.showLoader();
        let fd={station_id:data.station_id, ticket_id:ticket_id || '', request_to:data.request_to || '', items:[]};
        data.items.forEach(v=>{
            fd.items.push({id:v.id, qty:v.qty*1});
        });

        StockReqService.save(fd).then(({data})=>{
            message.success(data.message || 'Saved');
            if(callback){
                callback();
            }
            setFormOpen(false);
        }).catch(e=>{
            message.error(e.message);
        }).finally(()=>{
            util.hideLoader();
        })
    }

    useEffect(()=>{
        AssetService.allItems({status:1, cat_type:'Infrastructure'}).then(res=>{
            let allItems=[];
            allItems=res.data.result.data.map((v)=>{
                v.item_full_name=v.item_full_name+' ['+v.subcat+']';
                return v;
            });
            setItems(allItems);
        });

        if(typeof props.stationPoints === "undefined"){
            FacilityService.allStationPoints({status:1}).then(res=>{
                setStationPoints([...res.data.result.data]);
            });
        }
    }, []);

    useEffect(()=>{
        if(props.stationPoints){
            setStationPoints(props.stationPoints);
        }
    }, [props.stationPoints])

    refOb.current={
        openForm:(station_id)=>{
            data.items=[];
            if(station_id){
                data.station_id=station_id;
            }else{
                data.station_id=null;
            }
            setData({...data, request_to:'Internal'});
            setFormOpen(true);
        }
    }

    return (
        <Modal
            title={`${data.id ? 'Edit' : 'Create'} Stock Request`}
            visible={isFormOpen}
            okText="Submit"
            onOk={save}
            onCancel={closeForm}
            destroyOnClose
            maskClosable={false}
            width={1100}
        >
            <form onSubmit={e=>{e.preventDefault(); save()}} autoComplete="off" spellCheck="false">
                {modules['add_stock_request_external']===1 &&
                    <div className="mb20">
                        <label className="req bold600">Request To</label>
                        <AntdSelect 
                            options={['Internal', 'National']} 
                            value={data.request_to} 
                            onChange={v=>handleChange(v, 'request_to')} 
                        />
                    </div>
                }

                <div className="mb20">
                    <label className="req bold600">Station Point</label>
                    <AntdSelect 
                        showSearch 
                        options={stationPoints.filter(v=>v.is_my)} 
                        value={data.station_id} 
                        onChange={v=>handleChange(v, 'station_id')} 
                    />
                </div>
                
                <div className="bold600 mb3">List of Requesting Items</div>
                <div>
                    <div className="table-responsive">
                        <table className="table table-bordered table-md table-striped table-hover m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                <tr>
                                    <th className="w20">SN</th>
                                    <th>Item</th>
                                    <th className="w100">Qty</th>
                                    <th className="w20"></th>
                                </tr>
                            </thead>

                            <tbody>
                                {data.items.map((v, i)=>(
                                    <tr key={i}>
                                        <td>{i+1}.</td>
                                        <td>
                                            {v.item}
                                            <div className="note-text">
                                                <div>{v.cat} - {v.subcat}</div>
                                                <div className="pt3">Current Stock: <strong>{v.stock}</strong></div>
                                            </div>
                                        </td>
                                        <td className="text-right">
                                            <Input 
                                                size="small" 
                                                placeholder="Qty" 
                                                value={v.qty} 
                                                onChange={e=>{
                                                    let n=e.target.value.trim();
                                                    if(n.length){
                                                        n=parseInt(util.nv(n));
                                                        if(n<1){
                                                            n=1;
                                                        }
                                                    }
                                                    v.qty=n;
                                                    setData({...data});
                                                }} 
                                            />
                                        </td>
                                        <td>
                                            <Button.Group size="small">
                                                <Button type="danger" onClick={()=>{data.items.splice(i, 1); setData({...data})}}>
                                                    <i className="fa fa-times-circle"></i>
                                                </Button>
                                            </Button.Group>
                                        </td>
                                    </tr>
                                ))}

                                <tr>
                                    <td></td>
                                    <td colSpan={3}>
                                        <AntdSelect 
                                            placeholder="Select Item To Add" 
                                            allowClear 
                                            showSearch 
                                            options={items.filter(v=>!isItemAdded(v.id)).map(v=>{return {id:v.id, name:v.item_full_name}})} 
                                            onChange={addNewItem}
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </form>
        </Modal>
    )
}