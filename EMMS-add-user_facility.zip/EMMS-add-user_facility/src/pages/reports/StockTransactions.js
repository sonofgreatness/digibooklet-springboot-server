/* eslint-disable react-hooks/exhaustive-deps */
import React, {useState, useEffect, useRef} from 'react';
import {saveAs} from 'file-saver';
import FacilityService from "../../services/FacilityService";
import AssetService from "../../services/AssetService";
import ReportService from "../../services/ReportService";
import {If} from "../../utils/Controls";
import {AntdPaging, AntdSelect, AntdDatepicker} from "../../utils/Antd";
import util from "../../utils/util";
import moment from "moment";

import {
    Button,
    message
} from 'antd';

export default function StockTransactions(){
    const [clients, setClients]=useState([]);
    const [result, setResult]=useState({data:[], page:{}});
    const sdataRef=useRef({p:1, ps:25});
    const isNational=util.isNational();
    //const modules=util.getModules();

    const list=(p, ps)=>{
        sdataRef.current.p=p || 1;
        sdataRef.current.ps=ps || sdataRef.current.ps;
        util.showLoader();
        ReportService.stockTransactions(sdataRef.current).then(({data})=>{
            setResult({...data.result});
        }).catch(e=>{
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const download=()=>{
        sdataRef.current.p=1;
        sdataRef.current.ps=0;
        util.showLoader();
        ReportService.stockTransactionsAll(sdataRef.current).then(({data})=>{
            let header={
                client:'FACILITY',
                cat:'CATEGORY',
                subcat:'SUB CATEGORY',
                serial_no:'SERIAL NUMBER',
                item_full_name:'ITEM NAME',
                action:'ACTION',
                stock_before:'BEFORE CHANGE',
                qty:'CHANGED QUANTITY',
                stock_after:'AFTER CHANGE',
                txn_date:'TXN DATE',
                created_by_user:'CREATED BY',
            };

            let blob=util.convertToCSVBlob(data.result.data, header);
            saveAs(blob, "stock-transaction.csv");

        }).catch(e=>{
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    useEffect(()=>{
        list();

        FacilityService.all({status:1, include_me:'Y'}).then(res=>{
            let allClients=res.data.result.data.map(v=>{return {id:v.id, name:v.business_name, is_national:v.is_national, is_me:v.is_me}});
            setClients(allClients);
        });

        return ()=>{message.destroy()}
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto">
                    <h2>Stock Transactions Report</h2>
                </div>
                <div className="my-auto ml-auto"></div>
            </div>

            <div className="page-pad">
                {result.data.length > 0 &&
                    <div className="text-secondary mb8">
                        Showing {result.page.start + 1} - {result.page.start + result.page.total} of {result.page.total_records} records.
                    </div>
                }

                <div className="d-flex tbl-search-head">
                    <div className="my-auto flex-grow-1 pr10">
                        <SearchForm 
                            dataRef={sdataRef} 
                            onSearch={list} 
                            clients={clients}
                            isNational={isNational}
                        />
                    </div>
                    <div className="ml-auto my-auto">
                        <button type="button" className="btn purple" onClick={download}>
                            <i className="fa fa-download"></i> Download
                        </button>
                    </div>
                </div>

                <If cond={result.data.length}>
                    <div className="table-responsive">
                        <table className="table table-bordered table-sm font-xs table-striped table-hover1 m-0">
                            <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                                <tr>
                                    <th className="w20">SN</th>
                                    {isNational===1 && <th className="w100">Facility</th>}
                                    <th className="w80">Category</th>
                                    <th className="w80">Sub Cat</th>
                                    <th className="w80">Serial No.</th>
                                    <th>Item</th>
                                    <th className="w100">Action</th>
                                    <th className="w80 text-center">Before Change</th>
                                    <th className="w80 text-center">Changed Qty</th>
                                    <th className="w80 text-center">After Change</th>
                                    <th className="w80">Txn Date</th>
                                    <th className="w100">Created By</th>
                                </tr>
                            </thead>
                            <tbody className="table-text-top font-sm">
                                {result.data.map((v, i) => (
                                    <tr key={i}>
                                        <td>{i+1}.</td>
                                        {isNational===1 && <td>{v.client}</td>}
                                        <td>{v.cat}</td>
                                        <td>{v.subcat}</td>
                                        <td>{v.serial_no}</td>
                                        <td>{v.item_full_name}</td>
                                        <td className="nowrap">{v.action}</td>
                                        <td className="text-right pr10">{v.stock_before}</td>
                                        <td className={"text-right pr10 "+(v.qty<0?'bg-warning':'bg-success font-white')}>{v.qty}</td>
                                        <td className="text-right pr10">{v.stock_after}</td>

                                        <td>{util.getDate(v.txn_date, 'DD MMM YYYY')}</td>
                                        <td title={v.created_by_role}>{v.created_by_name}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="d-flex tbl-foot-bx">
                        <AntdPaging
                            onChange={list}
                            total={result.page.total_records}
                            current={result.page.cur_page}
                            pageSize={sdataRef.current.ps}
                            showSizeChanger
                        />
                    </div>
                </If>
                <If cond={!result.data.length}>
                    <div className="no-rec">No record found</div>
                </If>
            </div>
        </div>
    )
}

const SearchForm=(props)=>{
    let {dataRef, onSearch, clients, isNational}=props;
    let [data, setData]=useState({...dataRef.current});
    const [items, setItems]=useState([]);
    const handleChange=(v, k)=>{
        data[k]=v;
        setData({ ...data });
    }
    useEffect(()=>{
        dataRef.current={...data};
    }, [data]);

    useEffect(()=>{
        let ob=clients.find(v=>v.is_me);
        setData({...data, client_id:ob?.id});
    }, [clients]);

    useEffect(() => {
        setData({ ...data, p: dataRef.current.p, ps: dataRef.current.ps });
    }, [dataRef.current.p, dataRef.current.ps]);

    useEffect(()=>{
        AssetService.allItems({status:1}).then(res=>{
            let allItems=[];
            allItems=res.data.result.data.map((v)=>{
                let item_full_name=v.item_full_name+' ['+(v.cat_type==='Infrastructure'?v.subcat:v.cat)+']';
                return {label:item_full_name, value:v.id};
            });
            setItems(allItems);
        });
    }, []);

    return (
        <form onSubmit={e=>e.preventDefault()} autoComplete="off" spellCheck="false">
            <div className="d-flex">
                {isNational===1 &&
                    <div className="w150 mr5">
                        <AntdSelect 
                            placeholder="Facility (All)" 
                            showSearch 
                            options={clients} 
                            value={data.client_id} 
                            onChange={v=>handleChange(v, 'client_id')} 
                        />
                    </div>
                }

                <div className="w200 mr5">
                    <AntdSelect 
                        placeholder="Action (All)"
                        allowClear
                        options={[
                            {id:1, title:'Added By National'},
                            {id:2, title:'Received From Facility'},
                            {id:3, title:'Transfer To Facility'},
                            {id:7, title:'Issued To Department'},
                            {id:9, title:'Transfer Cancelled'},
                        ]} 
                        value={data.action_id} 
                        onChange={v=>handleChange(v, 'action_id')} 
                    />
                </div>

                <div className="flex-grow-1 mr5">
                    <AntdSelect 
                        placeholder="Item (All)" 
                        allowClear 
                        showSearch 
                        sort
                        options={items} 
                        value={data.item_id} 
                        onChange={v=>handleChange(v, 'item_id')} 
                    />
                </div>

                <div className="w130 mr5">
                    <AntdDatepicker 
                        placeholder="From Date"
                        allowClear
                        value={data.from_date} 
                        onChange={v=>{
                            if(data.to_date && moment(v) > moment(data.to_date)) {
                                message.error("From date should be less than or equal to To Date");
                                v=null;
                            }
                            handleChange(v, 'from_date');
                        }} 
                    />
                </div>

                <div className="w130 mr5">
                    <AntdDatepicker 
                        placeholder="To Date"
                        allowClear
                        value={data.to_date} 
                        onChange={v=>{
                            if(data.from_date && moment(v) < moment(data.from_date)) {
                                message.error("To date should be greater than or equal to From Date");
                                v=null;
                            }
                            handleChange(v, 'to_date');
                        }}
                    />
                </div>

                <div>
                    <Button type="primary" icon={<i className="fa fa-search fs13"></i>} onClick={()=>onSearch()}></Button>
                </div>
            </div>
        </form>
    )
}