import React, { useState, useEffect } from 'react';
import UserService from '../../services/UserService';
import {
    message
} from 'antd';

//let $=window.$;

export default function Profile() {
    const fn = {};
    const [d, setData] = useState({
        passData: {},
        profileData: {},
    });

    fn.handlePasswordChange = (e) => {
        d.passData[e.target.name] = e.target.value;
        setData({ ...d });
    }

    fn.handleProfileChange = (e) => {
        d.profileData[e.target.name] = e.target.value;
        setData({ ...d });
    }

    fn.changePassword = (e) => {
        if (e) e.preventDefault();
        let fd = new FormData(e.target);
        UserService.changePassword(fd).then(res => {
            message.success("Password Changed");
            setData({ ...d, passData: {} });
        }).catch(e => {
            message.error(e.message);
        })
    }

    fn.updateProfile = (e) => {
        if (e) e.preventDefault();
        let fd = new FormData(e.target);
        UserService.updateProfile(fd).then(res => {
            message.success("Profile Updated");
        }).catch(e => {
            message.error(e.message);
        });
    }

    const init = () => {
        UserService.profileDetail().then(res => {
            let data = {
                fname: res.data.result.fname,
                lname: res.data.result.lname,
                name: res.data.result.name,
                email: res.data.result.email,
                mobile: res.data.result.mobile,
            };
            setData({ ...d, profileData: data });
        }).catch(e => {
            message.error(e.message);
        });
    }
    useEffect(() => {
        init();
        // eslint-disable-next-line
    }, []);

    return (
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto"><h2>Profile</h2></div>
                <div className="my-auto ml-auto">
                </div>
            </div>
            <div className="page-pad">
                <div className="card1 custom-card card-tabs mb15">
                    <div className="card-content">
                        <ul className="nav nav-pills uc">
                            <li className="nav-item">
                                <a className="nav-link active" href="#pills2" data-toggle="pill">Profile</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#pills1" data-toggle="pill">Change Password</a>
                            </li>
                        </ul>
                        <div className="tab-content">
                            <div className="tab-pane fade" id="pills1">
                                <div className="w500 mw-100">
                                    <form onSubmit={fn.changePassword} autoComplete="off" spellCheck="false">
                                        <div className="row mingap">
                                            <div className="form-group col-md-12">
                                                <label className="req">Current Password</label>
                                                <input type="password" className="form-control" name="current_password" value={d.passData.current_password || ''} onChange={fn.handlePasswordChange} />
                                            </div>
                                            <div className="form-group col-md-12">
                                                <label className="req">New Password</label>
                                                <input type="password" className="form-control" name="new_password" value={d.passData.new_password || ''} onChange={fn.handlePasswordChange} />
                                            </div>

                                            <div className="form-group col-md-12">
                                                <label className="req">Confirm Password</label>
                                                <input type="password" className="form-control" name="confirm_password" value={d.passData.confirm_password || ''} onChange={fn.handlePasswordChange} />
                                            </div>

                                            <div className="col-md-12">
                                                <button type="submit" className="btn btn-info">Change Password</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div className="tab-pane fade active show" id="pills2">
                                <div className="w500 mw-100">
                                    <form onSubmit={fn.updateProfile} autoComplete="off" spellCheck="false">
                                        <div className="row mingap">
                                            <div className="form-group col-md-12">
                                                <label className="req">First Name</label>
                                                <input type="text" className="form-control" name="fname" value={d.profileData.fname || ''} onChange={fn.handleProfileChange} />
                                            </div>
                                            <div className="form-group col-md-12">
                                                <label className="">Last Name</label>
                                                <input type="text" className="form-control" name="lname" value={d.profileData.lname || ''} onChange={fn.handleProfileChange} />
                                            </div>
                                            <div className="form-group col-md-12">
                                                <label className="">Email</label>
                                                <input type="text" className="form-control" name="email" value={d.profileData.email || ''} onChange={fn.handleProfileChange} />
                                            </div>
                                            <div className="form-group col-md-12">
                                                <label className="">Mobile</label>
                                                <input type="text" className="form-control" name="mobile" value={d.profileData.mobile || ''} onChange={fn.handleProfileChange} maxLength="10" />
                                            </div>

                                            <div className="col-md-12">
                                                <button type="submit" className="btn btn-info">Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}