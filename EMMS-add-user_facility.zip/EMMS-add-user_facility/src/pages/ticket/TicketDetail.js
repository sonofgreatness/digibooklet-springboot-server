/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from 'react';
import TicketService from "../../services/TicketService";
import FileService from "../../services/FileService";
import UserService from "../../services/UserService";
import StockReqService from "../../services/StockReqService";
import { AntdSelect } from "../../utils/Antd";
import { RawHTML } from "../../utils/Controls";
import util from "../../utils/util";
import StockRequestForm from '../assets/StockRequestForm';

import {
    Input,
    Button,
    message,
    Modal,
    Card,
    Divider,
    Tabs,
    Tag
} from 'antd';

import {
    ExclamationCircleOutlined,
} from '@ant-design/icons';
const { confirm } = Modal;
const $ = window.$;

export default function TicketDetail(props) {
    let { refOb, ticketStatusNames, callback, pageno, stockReqPageList, stockReqPageno } = props;
    if (!ticketStatusNames) {
        ticketStatusNames = [
            { id: 1, name: 'Open' },
            { id: 2, name: 'On Hold - Awaiting Spares' },
            { id: 3, name: 'On Hold - Spares Supplied' },
            { id: 4, name: 'Completed' },
            { id: 5, name: 'Closed' }
        ];
    }
    const [statusNames, setStatusNames] = useState(ticketStatusNames);

    const [dtl, setDtl] = useState({ comments: [] });
    const [comments, setComments] = useState([]);
    const [commnetText, setCommentText] = useState('');
    const [stationPoints, setStationPoints] = useState([]);
    const [items, setItems] = useState([]);
    const [users, setUsers] = useState([]);
    const [stockRequests, setStockRequests] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    const [tab, setTab] = useState("Actions");
    const boxHeight = useRef(0);
    const modules = util.getModules();
    const fileInput = useRef();
    const stockReqForm = useRef({});
    const isNational = util.isNational();

    const closeDetail = () => {
        if (stockReqPageList) {
            stockReqPageList(stockReqPageno);
        }
        setIsOpen(false);
    }

    const getComments = () => {
        TicketService.comments(dtl.id).then(({ data }) => {
            setComments(data.result);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
        })
    }

    const assignToChange = (user_id) => {
        util.showLoader();
        TicketService.assign({ id: dtl.id, user_id }).then(({ data }) => {
            getComments();
            message.success(data.message || 'Saved');
            setDtl({ ...dtl, assigned_to: user_id });

            if (callback) {
                callback(pageno);
            }
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const addComment = () => {
        util.showLoader();
        TicketService.addComment({ id: dtl.id, comment: commnetText }).then(({ data }) => {
            getComments();
            message.success(data.message || 'Saved');
            setCommentText("");
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const changeStatus = (status_id) => {
        util.showLoader();
        TicketService.changeStatus({ id: dtl.id, status_id }).then(({ data }) => {
            message.success(data.message || 'Saved');
            getComments();
            setDtl({ ...dtl, status_id });
            if (callback) {
                callback(pageno);
            }
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const markAsRepairInScope = () => {
        message.destroy();
        confirm({
            title: 'Are you sure to mark this job card as Repair In Scope?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            width: '600px',
            onOk() {
                util.showLoader();
                TicketService.markAsRepairInScope(dtl.id).then(({ data }) => {
                    getComments();
                    message.success(data.message || 'Marked');
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    const markAsRepairNotInScope = () => {
        message.destroy();
        confirm({
            title: 'Are you sure to mark this job card as Repair Not In Scope?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            width: '600px',
            onOk() {
                util.showLoader();
                TicketService.markAsRepairNotInScope(dtl.id).then(({ data }) => {
                    getComments();
                    message.success(data.message || 'Marked');
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    const uploadCommentPhoto = async (e) => {
        if (!util.checkImage(e.target)) {
            return;
        }

        util.showLoader();
        let resp;
        try {
            resp = await FileService.upload(e.target.files[0]);
        } catch (e) {
            util.hideLoader();
            return;
        }
        e.target.value = "";
        util.hideLoader();

        TicketService.uploadCommentPhoto({ id: dtl.id, file_id: resp.data.file_id }).then(({ data }) => {
            getComments();
            message.success(data.message || 'Uploaded');
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const getStockRequests = (id) => {
        util.showLoader();
        StockReqService.ticketStockRequests(id || dtl.id).then(({ data }) => {
            setStockRequests([...data.result.data]);
        }).catch(e => {
            message.error(e.message);
        }).finally(() => {
            util.hideLoader();
        })
    }

    const onTabChange = (k) => {
        setTab(k);
    }

    refOb.current = {
        openDetail: (id) => {
            util.showLoader();
            TicketService.detail(id).then(({ data }) => {
                let wh = $(window).height();
                let h = wh - 200;
                boxHeight.current = h;

                setDtl({ ...data.result });
                setComments(util.copyObj(data.result.comments));
                setIsOpen(true);
                getStockRequests(id);
            }).catch(e => {
                message.error(e.message);
            }).finally(() => {
                util.hideLoader();
            })
        }
    };

    useEffect(() => {
        if (typeof props.users === "undefined") {
            UserService.allUsers({ status: 1 }).then(res => {
                let allUsers = res.data.result.data.map(v => { return { id: v.id, name: v.name, role: v.role } });
                setUsers(allUsers.map(v => { return { id: v.id, name: (v.name + ' [' + v.role + ']') } }));
            });
        }
    }, []);

    useEffect(() => {
        if (props.users) {
            setUsers(props.users.map(v => { return { id: v.id, name: (v.name + ' [' + v.role + ']') } }));
        }
    }, [props.users]);

    useEffect(() => {
        setItems(props.items);
    }, [props.items]);

    useEffect(() => {
        ticketStatusNames[1].disabled = true;
        ticketStatusNames[2].disabled = true;
        if (dtl.is_assigned_to_me === 0) {
            ticketStatusNames[3].disabled = true;
        }
        setStatusNames([...ticketStatusNames]);
    }, [dtl]);

    useEffect(() => {
        if (props.stationPoints) {
            setStationPoints(props.stationPoints);
        }
    }, [props.stationPoints]);

    return (
        <div>
            <Modal
                title={<span> {isNational === 1 && <span className="font-purple">[{dtl.client}]</span>} <span className="text-secondary">Job Card:</span> {dtl.ticket_no}</span>}
                visible={isOpen}
                onCancel={closeDetail}
                destroyOnClose
                maskClosable={false}
                width={"85%"}
                style={{ top: 30 }}
                footer={
                    [
                        <Button type="default" key="1" onClick={closeDetail}>Close</Button>
                    ]
                }
            >
                <div className="cscroll pr10" style={{ height: boxHeight.current }}>
                    <div className="d-flex">
                        <div className="wper60">
                            <div className="fs22 bold600 mb3">{dtl.subject}</div>
                            <div className="text-secondary">Created on {util.getDate(dtl.created, 'DD MMM YYYY @ hh:mm A')} by {dtl.created_by_name}</div>
                            <div className="pt15">
                                {!!dtl.description &&
                                    <div>
                                        <div className="bold600 mb5">Description</div>
                                        <div>
                                            <RawHTML html={dtl.description} />
                                        </div>
                                    </div>
                                }
                                <Divider />

                                {dtl.assigned_to * 1 > 0 ? (
                                    <div>
                                        <Tabs
                                            activeKey={tab}
                                            destroyInactiveTabPane
                                            onChange={onTabChange}
                                            items={[
                                                {
                                                    key: "Actions",
                                                    label: "Actions",
                                                    children: (
                                                        <div>
                                                            <div className="mt-comments fs13 portlet-lgt">
                                                                {comments.map((v, i) => (
                                                                    <div className="mt-comment" key={i}>
                                                                        <div className="mt-comment-body pl-0">
                                                                            <div className="mt-comment-info">
                                                                                <span className="mt-comment-author mb2">
                                                                                    <span>{v.created_by_name}</span> on {util.getDate(v.created, 'DD MMM YYYY @ hh:mm A')}
                                                                                </span>
                                                                                <span className="mt-comment-date"></span>
                                                                            </div>
                                                                            <div className="mt-comment-text">
                                                                                {v.type === 'Text' ? (
                                                                                    <RawHTML html={v.comment} />
                                                                                ) : (
                                                                                    <div className="w200 p5">
                                                                                        <a target="blank" href={v.image_url}>
                                                                                            <img alt="" src={v.image_url} className="mw-100" />
                                                                                        </a>
                                                                                    </div>
                                                                                )}
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>

                                                            <div className="pt15">
                                                                <div className="p10 bg-light">
                                                                    <div className="mb5">
                                                                        <Input.TextArea
                                                                            placeholder="Leave your comment here..."
                                                                            value={commnetText}
                                                                            onChange={e => setCommentText(e.target.value)}
                                                                            allowClear
                                                                            rows="3"
                                                                            spellCheck="false"
                                                                        />
                                                                    </div>
                                                                    <Button type="primary" onClick={addComment}>Submit</Button>
                                                                </div>
                                                                {modules['ticket_actions'] === 1 &&
                                                                    <div className="d-flex pt15">
                                                                        {/* <div className="mr5">
                                                                <Button type="dashed"><i className="fa fa-comments mr5"></i> Comment</Button>
                                                            </div> */}
                                                                        <div className="mr5">
                                                                            <input type="file" className="d-none" ref={fileInput} onChange={uploadCommentPhoto} />
                                                                            <Button type="dashed" onClick={() => fileInput.current.click()}><i className="fa fa-upload mr5"></i> Upload Photo</Button>
                                                                        </div>
                                                                        <div className="mr5">
                                                                            <Button type="dashed" onClick={markAsRepairInScope}><i className="fa fa-check-circle mr5"></i> Repair In Scope</Button>
                                                                        </div>
                                                                        <div className="mr5">
                                                                            <Button type="dashed" onClick={markAsRepairNotInScope}><i className="fa fa-times-circle mr5"></i> Repair Not In Scope</Button>
                                                                        </div>
                                                                        <div className="mr5">
                                                                            <Button type="dashed" onClick={() => stockReqForm.current.openForm(dtl.station_id)}><i className="fa fa-tools mr5"></i> Require Spare Parts</Button>
                                                                        </div>
                                                                    </div>
                                                                }
                                                            </div>
                                                        </div>
                                                    ),
                                                },
                                                {
                                                    key: "StockRequests",
                                                    label: "Spare Parts Requests",
                                                    children: (
                                                        <div>
                                                            <TicketStockRequests
                                                                stockRequests={stockRequests}
                                                                getComments={getComments}
                                                                setDtl={setDtl}
                                                                dtl={dtl}
                                                                callback={callback}
                                                                pageno={pageno}
                                                            />

                                                            {modules['ticket_actions'] === 1 &&
                                                                <div className="pt10">
                                                                    <Button type="dashed" onClick={() => stockReqForm.current.openForm(dtl.station_id)}><i className="fa fa-plus mr5"></i> Request Spare Parts</Button>
                                                                </div>}
                                                        </div>
                                                    ),
                                                },
                                            ]}
                                        />
                                    </div>
                                ) : (
                                    <div className="p20 border bg-light text-center text-secondary">This job card is not assigned to anyone yet!</div>
                                )}
                            </div>
                        </div>

                        <div className="wper40 pl15">
                            <div className="mb10">
                                <div className="fs18 d-flex">
                                    <div className="my-auto">Status: </div>
                                    {modules['ticket_status_change'] === 1 ? (
                                        <div className="my-auto flex-grow-1 pl20 bold600">
                                            <AntdSelect
                                                options={statusNames}
                                                value={dtl.status_id}
                                                onChange={v => changeStatus(v)}
                                                disabled={!dtl.assigned_to * 1}
                                            />
                                        </div>
                                    ) : (
                                        <div className="my-auto uc bold600 pl20">{dtl.status_name}</div>
                                    )}

                                    {/* {modules['ticket_actions']===1 && dtl.status_change_allowed===1?(
                                        <div className="my-auto flex-grow-1 pl20 bold600">
                                            
                                        </div>
                                    ):(
                                        <div className="my-auto uc bold600 pl20">{dtl.status_name}</div>
                                    )} */}
                                </div>
                            </div>
                            <div>
                                <Card title="Details" size="small" type="inner" bodyStyle={{ padding: '3px' }}>
                                    <div>
                                        <div className="table-responsive">
                                            <table className="table table-bordered table-md m-0 font-md">
                                                <tbody className="table-text-vmid">
                                                    <tr>
                                                        <td className="w150 bg-light">Station Point</td>
                                                        <td className="bold600">{dtl.station_point}</td>
                                                    </tr>

                                                    {dtl.type === 'Med/NonMed' ? (
                                                        <>
                                                            <tr>
                                                                <td className="bg-light">Asset Item</td>
                                                                <td className="bold600">{dtl.item}</td>
                                                            </tr>
                                                            <tr>
                                                                <td className="bg-light">Model</td>
                                                                <td className="bold600">{dtl.model || 'N/A'}</td>
                                                            </tr>
                                                            <tr>
                                                                <td className="bg-light">Manufacturer</td>
                                                                <td className="bold600">{dtl.manufacturer || 'N/A'}</td>
                                                            </tr>
                                                            <tr>
                                                                <td className="bg-light">Serial No.</td>
                                                                <td className="bold600">{dtl.serial_no || 'N/A'}</td>
                                                            </tr>
                                                        </>
                                                    ) : (
                                                        <tr>
                                                            <td className="bg-light">Infrastucture Type</td>
                                                            <td className="bold600">{dtl.infrastucture_type}</td>
                                                        </tr>
                                                    )}

                                                    <tr>
                                                        <td className="bg-light">Assigned To</td>
                                                        <td className="bold600">
                                                            {(modules['ticket_actions'] === 1 && dtl.assignedto_change_allowed === 1) ? (
                                                                <AntdSelect
                                                                    placeholder="Select Assignee"
                                                                    showSearch
                                                                    options={users}
                                                                    value={dtl.assigned_to}
                                                                    onChange={v => assignToChange(v)}
                                                                />
                                                            ) : (
                                                                <span>{dtl.assigned_to_name || 'N/A'}</span>
                                                            )}
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </div>
                    </div>
                </div>
            </Modal>

            <StockRequestForm
                items={items}
                stationPoints={props.stationPoints ? stationPoints : undefined}
                ticket_id={dtl.id}
                refOb={stockReqForm}
                callback={() => {
                    getComments();
                    setDtl({ ...dtl, status_id: '2' });
                    getStockRequests();
                    if (callback) {
                        callback(pageno);
                    }
                }}
            />
        </div>
    )
}


function TicketStockRequests(props) {
    const { getComments, setDtl, dtl, callback, pageno } = props;
    const [stockRequests, setStockRequests] = useState([]);
    const modules = util.getModules();

    const cancelRequest = (rob) => {
        message.destroy();
        confirm({
            title: 'Are you sure to cancel this stock request?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                StockReqService.cancel(rob.id).then(({ data }) => {
                    message.success(data.message || 'Cancelled');
                    Object.assign(rob, data.result);
                    setStockRequests([...stockRequests]);
                    getComments();
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    const issueRequest = (rob) => {
        message.destroy();
        confirm({
            title: 'Are you sure to issue this stock?',
            icon: <ExclamationCircleOutlined />,
            content: '',
            okText: 'Yes',
            okType: 'danger',
            cancelText: 'No',
            onOk() {
                util.showLoader();
                StockReqService.issue(rob.id).then(({ data }) => {
                    message.success(data.message || 'Issued');
                    Object.assign(rob, data.result);
                    setStockRequests([...stockRequests]);
                    getComments();
                    setDtl({ ...dtl, status_id: '3' });
                    if (callback) {
                        callback(pageno);
                    }
                }).catch(e => {
                    message.error(e.message);
                }).finally(() => {
                    util.hideLoader();
                })
            },
            onCancel() {
            },
        })
    }

    useEffect(() => {
        setStockRequests(props.stockRequests);
    }, [props.stockRequests]);

    return (
        <div>
            {stockRequests.length > 0 ? (
                <div className="table-responsive">
                    <table className="table table-bordered table-sm font-sm table-striped table-hover m-0">
                        <thead className="thead-light text-uppercase table-text-vmid pad-y-md">
                            <tr>
                                <th className="w20">SN</th>
                                <th>Item</th>
                                <th className="w80 text-right pr10">Qty</th>
                                <th className="w80">Status</th>
                                <th className="w80 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody className="table-text-top font-md">
                            {stockRequests.map((v, i) => (
                                <tr key={i}>
                                    <td>{i + 1}.</td>
                                    <td>
                                        <div className="uc">{v.item_full_name} [{v.subcat}]</div>
                                        <div className="note-text pt2">
                                            <div>Requested by <span>{v.created_by_name} [{v.created_by_role}]</span> on <span>{util.getDate(v.created, 'DD MMM YYYY @ hh:mm A')}</span></div>

                                            {v.status !== 'Requested' &&
                                                <div className={v.status === 'Issued' ? 'font-green-jungle' : 'font-red'}>
                                                    {v.status === 'Issued' ? 'Issued' : 'Cancelled'} by <span>{v.action_by_name} [{v.action_by_role}]</span> on <span>{util.getDate(v.action_on, 'DD MMM YYYY @ hh:mm A')}</span>
                                                </div>
                                            }
                                        </div>
                                    </td>
                                    <td className="text-right pr10">{v.qty}</td>

                                    <td className="nowrap uc">
                                        <Tag color={v.status === 'Requested' ? 'blue' : (v.status === 'Issued' ? 'green' : 'red')}>
                                            {v.status}
                                        </Tag>
                                    </td>

                                    <td className="text-center">
                                        <Button.Group size="small">
                                            {modules['issue_stock'] === 1 &&
                                                <Button type="primary" onClick={() => { issueRequest(v) }} disabled={v.status !== 'Requested'}>
                                                    Issue
                                                </Button>}
                                            <Button type="danger" onClick={() => cancelRequest(v)} disabled={!(modules['issue_stock'] || v.cancel_allowed) || v.status !== 'Requested'}>
                                                Cancel
                                            </Button>
                                        </Button.Group>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <div className="no-rec">
                    No request found
                </div>
            )}
        </div>
    )
}