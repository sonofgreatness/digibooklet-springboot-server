import React, {useEffect} from 'react';
//import {useStateIfMounted} from "use-state-if-mounted";
import {Route, withRouter} from 'react-router-dom';
import Header from './tpl/Header';
import Leftnavs from './tpl/Leftnavs';
import util from "../../utils/util";
//let $=window.$;

function Default(props) {
    const {component:Component, ...rest} = props;

    /* const setPageContentHeight=()=>{
        let h=$(window).height()-50;
        $(".page-content-wrapper").css({'min-height':h+'px'});
    } */

    const init=async()=>{
        if(!util.isLogged()){
            props.history.push('/');
        }

        /* $(window).resize(()=>{
            setPageContentHeight();
        })
        setPageContentHeight(); */
    }

    useEffect(()=>{
        init();
        // eslint-disable-next-line
    }, []);

    return (
      <Route {...rest}  render={()=>{
            return(
                <>
                    <Header {...rest} />
                    <div className="page-container">
                        <div className="page-content-wrapper">
                            <Leftnavs {...rest} />

                            <Component {...rest}  />
                        </div>
                    </div>
                </>
            )
        }} />
    );
}

export default withRouter(Default);