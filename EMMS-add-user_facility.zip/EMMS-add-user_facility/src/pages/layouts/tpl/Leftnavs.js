import React, {useEffect} from 'react';
import {Link} from 'react-router-dom';
import util from '../../../utils/util';
let $=window.$;

export default function Leftnavs(){
    const setNavActive=(e)=>{
        $(".nav-item").removeClass("active");
        let li=$(e.target).closest("li");
        if (!li.hasClass("sidebar-mobile-offcanvas-toggler")){
            li.addClass("active");
            closeResponsiveSidebar();
        }
    }

    const closeResponsiveSidebar=(e)=>{
        if(e)e.preventDefault();
        $("body").removeClass("page-sidebar-mobile-offcanvas-open");
        $(".page-sidebar-cover").hide();
    }

    const init=()=>{
        let wh=$(window).height();
        let h=wh-0;
        $(".sidebarScrollDiv").css({height:h+'px'})
    }

    useEffect(()=>{
        init();
        $(window).off("resize");
        $(window).resize(()=>{
            init();
        })
        // eslint-disable-next-line
    }, []);

    const modules=util.getModules();


    return (
        <>
            <div className="page-sidebar-cover" onClick={closeResponsiveSidebar}></div>
            <div className="page-sidebar-wrapper d-print-none">
                <div className="page-sidebar navbar-collapse1 collapse1">
                    <div className="sidebarScrollDiv">
                        <ul className="page-sidebar-menu page-header-fixed" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" onClick={e => setNavActive(e)}>
                            <li className="sidebar-mobile-offcanvas-toggler d-lg-none">
                                <a href="/" className="responsive-toggler" onClick={closeResponsiveSidebar}>
                                    <i className="icon-logout"></i>
                                </a>
                            </li>

                            <li className="nav-item start">
                                {/* <Link to="/dashboard" className="nav-link"><i className="fa fa-home"></i> <span className="title">Dashboard</span></Link> */}
                                <Link to="/dashboard" className="nav-link"><i className="fa fa-bell"></i> <span className="title">Notifications</span></Link>
                            </li>

                            <li className="heading"><h3 className="uppercase">Modules</h3></li>

                            {modules['manage_roles_users']===1 && 
                                <li className="nav-item">
                                    <Link to="/roles" className="nav-link"><i className="fa fa-user"></i> <span className="title">Roles &amp; Users</span></Link>
                                </li>
                            }
                            {modules['manage_cmasters']===1 && 
                                <li className="nav-item">
                                    <Link to="/asset-cats" className="nav-link"><i className="fa fa-cog"></i> <span className="title">Masters</span></Link>
                                </li>
                            }
                            {modules['manage_facilities']===1 && 
                                <li className="nav-item">
                                    <Link to="/facilities" className="nav-link"><i className="fa fa-plus"></i> <span className="title">Facilities</span></Link>
                                </li>
                            }
                            
                            {modules['view_asset']===1 && 
                                <li className="nav-item">
                                    <Link to="/assets-list" className="nav-link"><i className="fa fa-circle"></i> <span className="title">Assets</span></Link>
                                </li>
                            }

                            {modules['view_transfer_out']===1 && 
                                <li className="nav-item">
                                    <Link to="/transfer-out" className="nav-link"><i className="fa fa-arrow-circle-right"></i> <span className="title">Transfer Out</span></Link>
                                </li>
                            }

                            {modules['view_transfer_in']===1 && 
                                <li className="nav-item">
                                    <Link to="/transfer-in" className="nav-link"><i className="fa fa-arrow-circle-left"></i> <span className="title">Transfer In</span></Link>
                                </li>
                            }

                            {(modules['view_stock_requests']===1 || modules['view_stock_requests_self']===1) && 
                                <li className="nav-item">
                                    <Link to="/stock-request" className="nav-link"><i className="fa fa-circle"></i> <span className="title">Stock Requests</span></Link>
                                </li>
                            }

                            {(modules['view_tickets']===1 || modules['view_tickets_self']===1) && 
                                <li className="nav-item">
                                    <Link to="/job-cards" className="nav-link"><i className="fa fa-tools"></i> <span className="title">Job Cards</span></Link>
                                </li>
                            }

                            {modules['view_reports']===1 && 
                                <>
                                    <li className="heading"><h3 className="uppercase">Reports</h3></li>
                                    <li className="nav-item">
                                        <Link to="/stock-transactions-report" className="nav-link"><i className="fa fa-chart-bar"></i> <span className="title">Stock Transactions</span></Link>
                                    </li>
                                </>
                            }
                        </ul>
                    </div>
                </div>
            </div>
        </>
    )
}