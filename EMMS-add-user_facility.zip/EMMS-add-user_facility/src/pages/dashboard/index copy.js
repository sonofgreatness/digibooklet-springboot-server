import React from 'react';

export default function Index(){
    return(
        <div className="page-content">
            <div className="page-head uc d-flex">
                <div className="my-auto"><h2>Dashboard</h2></div>
                <div className="my-auto ml-auto">
                </div>
            </div>

            <div className="page-pad">
                
            </div>
        </div>
    )
}